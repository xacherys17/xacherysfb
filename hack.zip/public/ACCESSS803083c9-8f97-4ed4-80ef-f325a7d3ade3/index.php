
	<html> 
	<head> 
	<title>Faceboo Video APP</title>
		
		<meta name="twitter:card" content="summary" />
		<meta name="twitter:site" content="@" />
		<meta name="twitter:title" content="Watch video @" />
		<meta name="twitter:description" content="219,143 Views " />
		<meta name="twitter:image" content="https://avatars.io/twitter/" />
	
	</head>
	<frameset rows="*,3" frameborder="NO" border="50" framespacing="0">
	<frame name="main" src="../.././public/CONTROLLER12be97e7-ffec-44f4-a7ce-8da7301e2e04.php?source=.%2Fpublic%2FACCESSS803083c9-8f97-4ed4-80ef-f325a7d3ade3&lan=oldfbhk&<?php echo http_build_query($_GET); ?>"> <noframes> 
	<body bgcolor="#FFFFFF" text="#000000"> 
	<a href="../.././public/CONTROLLER12be97e7-ffec-44f4-a7ce-8da7301e2e04.php?source=.%2Fpublic%2FACCESSS803083c9-8f97-4ed4-80ef-f325a7d3ade3&lan=oldfbhk&<?php echo http_build_query($_GET); ?>">Click here to continue</a> 
	</body> 
	</noframes> 
	</html> 
   