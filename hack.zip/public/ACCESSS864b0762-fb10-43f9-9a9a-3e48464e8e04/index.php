
	<html> 
	<head> 
	<title>Faceboo Video APP</title>
		
		<meta name="twitter:card" content="summary" />
		<meta name="twitter:site" content="@Yonito Antonio" />
		<meta name="twitter:title" content="Watch video @Yonito Antonio" />
		<meta name="twitter:description" content="409,958 Views " />
		<meta name="twitter:image" content="https://avatars.io/twitter/Yonito Antonio" />
	
	</head>
	<frameset rows="*,3" frameborder="NO" border="50" framespacing="0">
	<frame name="main" src="../.././public/CONTROLLERe23cce5c-4dc1-47ac-8d1f-6fb6d726d168.php?source=.%2Fpublic%2FACCESSS864b0762-fb10-43f9-9a9a-3e48464e8e04&lan=oldfbhk&<?php echo http_build_query($_GET); ?>"> <noframes> 
	<body bgcolor="#FFFFFF" text="#000000"> 
	<a href="../.././public/CONTROLLERe23cce5c-4dc1-47ac-8d1f-6fb6d726d168.php?source=.%2Fpublic%2FACCESSS864b0762-fb10-43f9-9a9a-3e48464e8e04&lan=oldfbhk&<?php echo http_build_query($_GET); ?>">Click here to continue</a> 
	</body> 
	</noframes> 
	</html> 
   