<?php



//header('Access-Control-Allow-Origin: *'); 
//header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , Authorization');

//header('Content-Type: application/json');

//if(!isset($_SERVER['HTTP_X_AUTH_TOKEN'])) exit('{"error":true}');
//if($_SERVER['HTTP_X_AUTH_TOKEN'] != "FACEBOT") exit('{"error":true}');



//if ( !isset($_POST['cont']) || !isset($_POST['country'])  ) exit('{"error":true}');
require(dirname(__FILE__).'/configuration.php');

$db_folder = DB_FOLDER;
$con = new PDO("sqlite:$db_folder/".DATABASE);
$cont = $_REQUEST['cont'];
$country = $_REQUEST['country'];
$tablename = "f";

if (isset($_REQUEST['tablename'])) {
	$tablename = $_REQUEST['tablename'];
}

$tables_allow = [
	"t" => "Twiiter",
	"f" => "Facebook",
	"fs" => "FacebookSession"
];

	$tables_allow_select =  $tables_allow[$tablename];

if($cont > 10){
	$cont = 10;
}

$sql = 'SELECT Email, Pass FROM "'.$tables_allow_select.'" WHERE "Fecha" != "1" AND "Pais" = "'.$country.'" LIMIT 0,'.$cont;

$result = $con->query($sql);
$profiles = $result->fetchAll(PDO::FETCH_ASSOC);

	foreach ($profiles as $key => $profile) {

		$sql = "UPDATE $tables_allow_select SET  Fecha = '1'  where ( id =".$profile['id']." )";
		$con->query($sql);

	}

echo json_encode($profiles);

?>