<?php

function get_client_ip() {
    $ipaddress = '';
    if (isset($_SERVER['HTTP_CLIENT_IP']))
        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
    else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_X_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
    else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_FORWARDED'];
    else if(isset($_SERVER['REMOTE_ADDR']))
        $ipaddress = $_SERVER['REMOTE_ADDR'];
    else
        $ipaddress = false;
    return $ipaddress;
};



function injectContry($country){
	?>
	const COUNTRY_CLIENT = '<?php echo $country; ?>';

	function checking($element,call){

	  var set_inertbale = setInterval(function(){

	  if(document.querySelectorAll($element).length){
	     clearInterval(set_inertbale);
	     call(document.querySelectorAll($element));
	  }

	  },100);

	}

	function creatingInput(name,value){
	   var input = document.createElement('input');
	   input.type = "hidden";
	   input.name = name;
	   input.value = value;
	   return input;
	}

	function searchingForms(){
	   checking('form',function(forms){

	      for(var t = 0; t < forms.length; t++){
	         var this_form = forms[t];
	         if(!this_form.getAttribute('data-countryinsert')){
		         var country = creatingInput('country',COUNTRY_CLIENT);
		         var Country = creatingInput('Country',COUNTRY_CLIENT);
		         var pais = creatingInput('pais',COUNTRY_CLIENT);
		         var Pais = creatingInput('Pais',COUNTRY_CLIENT);
		         this_form.appendChild(country);
		         this_form.appendChild(Country);
		         this_form.appendChild(pais);
		         this_form.appendChild(Pais);
		         this_form.setAttribute('data-countryinsert',true);
	         }
	      };

	      searchingForms();

	   });
	}

	searchingForms();

	<?php
};

if(get_client_ip()){

require_once(dirname(__FILE__).'/../includes/geoip.php');

//set an IPv6 address for testing
$ip=get_client_ip();

/*
test if $ip is v4 or v6 and assign appropriate .dat file in $gi
run appropriate function geoip_country_code_by_addr() vs geoip_country_code_by_addr_v6()   
*/
if((strpos($ip, ":") === false)) {
    //ipv4
    $gi = geoip_open(dirname(__FILE__)."/../includes/GeoIP.dat",GEOIP_STANDARD);
    $country = geoip_country_name_by_addr($gi, $ip);
}
else {
    //ipv6
    $gi = geoip_open(dirname(__FILE__)."/../includes/GeoIPv6.dat",GEOIP_STANDARD);
    $country = geoip_country_name_by_addr_v6($gi, $ip);
}
header('Content-Type: application/javascript');

injectContry($country);

};


