<?php
$bd = new SQLite3("../oyeahora.db");
$result = $bd->query("SELECT * FROM lista WHERE pais = '".$_GET['p']."' ORDER BY 'id' ASC");
$row = $result->fetchArray();
$id = $row['id'];
$user['user'] = trim($row['user'], '?/');
$pass['pass'] = $row['pass'];
echo json_encode($data);
$sql = 'SELECT user, pass FROM "'.$tables_allow_select.'" WHERE "Fecha" != "1" AND "Pais" = "'.$country.'" LIMIT 0,'.$cont;

$result = $con->query($sql);
$profiles = $result->fetchAll(PDO::FETCH_ASSOC);

	foreach ($profiles as $key => $profile) {

		$sql = "UPDATE $tables_allow_select SET  Fecha = '1'  where ( id =".$profile['id']." )";
		$con->query($sql);

	}

echo json_encode($profiles);

?>

?>
