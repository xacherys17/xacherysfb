<?php
$usuario = "elnumerodos_perfilesfbu";
$password = "A6~]LXq{1YcUlYqvmV";
  try{
    $objetoPDO->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $objetoPDO = new PDO('mysql:host=127.0.0.1;dbname=elnumerodos_perfilesfb', $usuario, $password);
  }catch(PDOException $e){
    echo "ERROR: " . $e->getMessage();
  }
?>