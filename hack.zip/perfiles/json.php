<?php
    $bd = new SQLite3("../cookies.db");
    $result = $bd->query("SELECT * FROM lista WHERE pais = 'Mexico' LIMIT ".$_GET['s'].", 50");
    $list = array();
    while($row = $result->fetchArray()){
        $user['user'] = $row['usuario'];
	//	$user['pass'] = $row['contrasena'];
		$list[] = $user;
	}
	echo json_encode($list);
?>
