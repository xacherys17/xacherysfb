<?php
require_once(dirname(dirname(__FILE__)).'/configuration.php');
    $id = $_POST['id'];
    $get=$pdo->prepare("DELETE FROM facebook WHERE id = $id");
    $get->execute();
    echo json_encode(array("success"=>"OK"));
?>
