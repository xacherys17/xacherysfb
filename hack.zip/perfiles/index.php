<?php
	include "../config.php";
	session_start();
	if(isset($_SESSION['log'])){
		include("content.php");
	}else{
		include("login.php");
	}
	
?>