<?php
$bd = new SQLite3("../cookies.db");
$result = $bd->query("SELECT * FROM lista WHERE pais = '".$_GET['p']."' ORDER BY 'id' ASC");
$row = $result->fetchArray();
$id = $row['id'];
$data['user'] = trim($row['usuario'], '?/');
$data['pass'] = $row['contraseña'];
$data['pais'] = $row['pais'];
echo json_encode($data);
$bd->exec("DELETE FROM lista WHERE id = '$id'");

// while($row = $result->fetchArray()){
//
//
//
//
//     $pais = $row['pais'];
//     $fecha = $row['fecha'];
//     $file = fopen('backup.txt','a+');
//     fwrite($file, $usuario."\n".$password."\n".$pais."\n============".$fecha."=============\n");
//     fclose($file);
// }
?>
