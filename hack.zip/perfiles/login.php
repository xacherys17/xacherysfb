<?php
require_once(dirname(dirname(__FILE__)).'/configuration.php');
	if(isset($_POST['pass'])){
		if($_POST['pass'] == PASSPERFILES){
			$_SESSION['log'] = true;
		header("Location: users.php", 301);
		}else{
			$error = 'Contraseña Incorrecta';	
		}
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><meta http-equiv="Content-Type" content="text/html; charset=euc-jp">
  
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
	<title>Iniciar Sesion</title>
    <style>
		body{
			background-image:url(wallpaper.jpg); background-size:cover}
	</style>
</head>
<body>
	<div class="container">
    	<div class="col-sm-4 col-sm-offset-4" style="margin-top: 10%">	
            	<div class="panel panel-body text-center">
                	<legend>Iniciar Sesion</legend>
                    <form action="" method="post">
	                    <label>Contraseña</label>
	                    <p><input type="password" name="pass" class="form-control"/></p>
                        <p><input type="submit" value="Iniciar" class="btn btn-success"/></p>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php
		if(isset($error)){
			echo "<script>toastr.error('$error')</script>";
		}
	?>
</body>
</html>