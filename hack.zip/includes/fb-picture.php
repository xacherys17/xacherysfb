<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.10&appId=437963963042621";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<style>
body{
	margin: 0;
	padding: 0;
	height: 100%;
}
.controller-1 {
    width: 48px;
    height: 48px;
    overflow: hidden;
    float: left;
}
.controller-2{
    margin: -68px -8px;
}


@media (max-width: 600px) {
  .facet_sidebar {
    display: none;
  }
}


</style>

<div class="controller-1">

	<div class="controller-2">
		
		<div class="fb-comments" data-mobile="false" data-href="https://developers.facebook.com/docs/plugins/comments#configurator" data-numposts="1"></div>

	</div>

</div>