
<!DOCTYPE html>
<html lang="es" id="responsive-news">
<head  prefix="og: http://ogp.me/ns#">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Noticias - BBC Mundo</title>
    <meta name="description" content="BBC Mundo le presenta una selección de contenidos y acontecimientos más importantes de la actualidad. Las últimas noticias e información en materia internacional, sobre América Latina, tecnología, ciencia, salud, economía. Fotos y videos.">

    <link rel="dns-prefetch" href="https://ssl.bbc.co.uk/">
    <link rel="dns-prefetch" href="http://sa.bbc.co.uk/">
    <link rel="dns-prefetch" href="http://ichef-1.bbci.co.uk/">
    <link rel="dns-prefetch" href="http://ichef.bbci.co.uk/">

    <meta name="x-country" content="do">
    <meta name="x-audience" content="International">
    <meta name="CPS_AUDIENCE" content="International">
    <meta name="CPS_CHANGEQUEUEID" content="106776575">
    <link rel="canonical" href="http://www.bbc.com/mundo">

                <meta property="og:title" content="Noticias - BBC Mundo" />
    <meta property="og:type" content="website" />
    <meta property="og:description" content="BBC Mundo le presenta una selección de contenidos y acontecimientos más importantes de la actualidad. Las últimas noticias e información en materia internacional, sobre América Latina, tecnología, ciencia, salud, economía. Fotos y videos." />
    <meta property="og:site_name" content="BBC Mundo" />
    <meta property="og:locale" content="es_CO" />
    <meta property="article:author" content="https://www.facebook.com/bbcnews" />
    <meta property="article:section" content="Noticias" />
    <meta property="og:url" content="http://www.bbc.com/mundo" />
    <meta property="og:image" content="http://www.bbc.co.uk/news/special/2015/newsspec_11063/mundo_1024x576.png" />

    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:site" content="@bbcmundo">
    <meta name="twitter:title" content="Noticias - BBC Mundo">
    <meta name="twitter:description" content="BBC Mundo le presenta una selección de contenidos y acontecimientos más importantes de la actualidad. Las últimas noticias e información en materia internacional, sobre América Latina, tecnología, ciencia, salud, economía. Fotos y videos.">
    <meta name="twitter:creator" content="@bbcmundo">
    <meta name="twitter:image:src" content="http://www.bbc.co.uk/news/special/2015/newsspec_11063/mundo_1024x576.png">
    <meta name="twitter:image:alt" content="BBC Mundo" />
    <meta name="twitter:domain" content="www.bbc.com">

    <script type="application/ld+json">
    {"@context":"http:\/\/schema.org","@type":"WebPage","url":"http:\/\/www.bbc.com\/mundo","publisher":{"@type":"Organization","name":"BBC Mundo","logo":{"@type":"ImageObject","url":"http:\/\/www.bbc.co.uk\/news\/special\/2015\/newsspec_11063\/mundo_1024x576.png"}},"description":"BBC Mundo le presenta una selecci\u00f3n de contenidos y acontecimientos m\u00e1s importantes de la actualidad. Las \u00faltimas noticias e informaci\u00f3n en materia internacional, sobre Am\u00e9rica Latina, tecnolog\u00eda, ciencia, salud, econom\u00eda. Fotos y videos.","name":"Noticias - BBC Mundo"}
    </script>


                <meta property='fb:pages' content='81395234664'>
                    
    <meta name="apple-mobile-web-app-title" content="BBC News">
    <link rel="apple-touch-icon-precomposed" sizes="57x57"    href="http://static.bbci.co.uk/news/1.206.01880/apple-touch-icon-57x57-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72"    href="http://static.bbci.co.uk/news/1.206.01880/apple-touch-icon-72x72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114"  href="http://static.bbci.co.uk/news/1.206.01880/apple-touch-icon-114x114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="144x144"  href="http://static.bbci.co.uk/news/1.206.01880/apple-touch-icon.png">
    <link rel="apple-touch-icon" href="http://static.bbci.co.uk/news/1.206.01880/apple-touch-icon.png">
    <meta name="application-name" content="BBC News">
    <meta name="msapplication-TileImage" content="http://static.bbci.co.uk/news/1.206.01880/windows-eight-icon-144x144.png">
    <meta name="msapplication-TileColor" content="#bb1919">
    <meta http-equiv="cleartype" content="on">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="robots" content="NOODP,NOYDIR" />
        <script type="text/javascript">var _sf_startpt=(new Date()).getTime()</script>


    <script>
        (function() {
            if (navigator.userAgent.match(/IEMobile\/10\.0/)) {
                var msViewportStyle = document.createElement("style");
                msViewportStyle.appendChild(
                    document.createTextNode("@-ms-viewport{width:auto!important}")
                );
                document.getElementsByTagName("head")[0].appendChild(msViewportStyle);
            }
        })();
    </script>
    
    <script>window.fig = window.fig || {}; window.fig.async = true;</script>

    <meta property="fb:app_id" content="1609039196070050" />

           <meta name="viewport" content="width=device-width, initial-scale=1.0" />  <meta property="fb:admins" content="100004154058350" />    
<!--[if (gt IE 8) | (IEMobile)]><!-->
<link rel="stylesheet" href="http://static.bbci.co.uk/frameworks/barlesque/3.21.26/orb/4/style/orb.min.css">
<!--<![endif]-->

<!--[if (lt IE 9) & (!IEMobile)]>
<link rel="stylesheet" href="http://static.bbci.co.uk/frameworks/barlesque/3.21.26/orb/4/style/orb-ie.min.css">
<![endif]-->

  <!--orb.ws.require.lib--> <script class="js-require-lib" src="http://static.bbci.co.uk/frameworks/requirejs/lib.js"></script> <script type="text/javascript">  bbcRequireMap = {"jquery-1":"http://static.bbci.co.uk/frameworks/jquery/0.4.1/sharedmodules/jquery-1.7.2", "jquery-1.4":"http://static.bbci.co.uk/frameworks/jquery/0.4.1/sharedmodules/jquery-1.4", "jquery-1.9":"http://static.bbci.co.uk/frameworks/jquery/0.4.1/sharedmodules/jquery-1.9.1", "jquery-1.12":"http://static.bbci.co.uk/frameworks/jquery/0.4.1/sharedmodules/jquery-1.12.0.min", "jquery-2.2":"http://static.bbci.co.uk/frameworks/jquery/0.4.1/sharedmodules/jquery-2.2.0.min", "istats-1":"//nav.files.bbci.co.uk/nav-analytics/0.1.0-43/js/istats-1", "swfobject-2":"http://static.bbci.co.uk/frameworks/swfobject/0.1.10/sharedmodules/swfobject-2", "demi-1":"http://static.bbci.co.uk/frameworks/demi/0.10.1/sharedmodules/demi-1", "gelui-1":"http://static.bbci.co.uk/frameworks/gelui/0.9.13/sharedmodules/gelui-1", "cssp!gelui-1/overlay":"http://static.bbci.co.uk/frameworks/gelui/0.9.13/sharedmodules/gelui-1/overlay.css", "relay-1":"http://static.bbci.co.uk/frameworks/relay/0.2.6/sharedmodules/relay-1", "clock-1":"http://static.bbci.co.uk/frameworks/clock/0.1.9/sharedmodules/clock-1", "canvas-clock-1":"http://static.bbci.co.uk/frameworks/clock/0.1.9/sharedmodules/canvas-clock-1", "cssp!clock-1":"http://static.bbci.co.uk/frameworks/clock/0.1.9/sharedmodules/clock-1.css", "jssignals-1":"http://static.bbci.co.uk/frameworks/jssignals/0.3.6/modules/jssignals-1", "jcarousel-1":"http://static.bbci.co.uk/frameworks/jcarousel/0.1.10/modules/jcarousel-1", "bump-3":"//emp.bbci.co.uk/emp/bump-3/bump-3"}; require({ baseUrl: 'http://static.bbci.co.uk/', paths: bbcRequireMap, waitSeconds: 30 }); </script>   <script type="text/javascript">/*<![CDATA[*/ if (typeof bbccookies_flag === 'undefined') { bbccookies_flag = 'ON'; } showCTA_flag = true; cta_enabled = (showCTA_flag && (bbccookies_flag === 'ON')); (function(){var m="ckns_policy",q="Thu, 01 Jan 1970 00:00:00 GMT",i={ads:true,personalisation:true,performance:true,necessary:true};function c(u){if(c.cache[u]){return c.cache[u]}var t=u.split("/"),v=[""];do{v.unshift((t.join("/")||"/"));t.pop()}while(v[0]!=="/");c.cache[u]=v;return v}c.cache={};function a(u){if(a.cache[u]){return a.cache[u]}var v=u.split("."),t=[];while(v.length&&"|co.uk|com|".indexOf("|"+v.join(".")+"|")===-1){if(v.length){t.push(v.join("."))}v.shift()}c.cache[u]=t;return t}a.cache={};function s(t,y,u){var E=[""].concat(a(window.location.hostname)),B=c(window.location.pathname),D="",w,C;for(var x=0,A=E.length;x<A;x++){w=E[x];for(var v=0,z=B.length;v<z;v++){C=B[v];D=t+"="+y+";"+(w?"domain="+w+";":"")+(C?"path="+C+";":"")+(u?"expires="+u+";":"");bbccookies.set(D,true)}}}window.bbccookies={POLICY_REFRESH_DATE_MILLIS:new Date(2015,4,21,0,0,0,0).getTime(),POLICY_EXPIRY_COOKIENAME:"ckns_policy_exp",_setEverywhere:s,cookiesEnabled:function(){var t="ckns_testcookie"+Math.floor(Math.random()*100000);this.set(t+"=1");if(this.get().indexOf(t)>-1){e(t);return true}return false},get:function(){return document.cookie},getCrumb:function(t){if(!t){return null}return decodeURIComponent(document.cookie.replace(new RegExp("(?:(?:^|.*;)\\s*"+encodeURIComponent(t).replace(/[\-\.\+\*]/g,"\\$&")+"\\s*\\=\\s*([^;]*).*$)|^.*$"),"$1"))||null},policyRequiresRefresh:function(){var u=new Date();u.setHours(0);u.setMinutes(0);u.setSeconds(0);u.setMilliseconds(0);if(bbccookies.POLICY_REFRESH_DATE_MILLIS<=u.getTime()){var t=bbccookies.getCrumb(bbccookies.POLICY_EXPIRY_COOKIENAME);if(t){t=new Date(parseInt(t));t.setYear(t.getFullYear()-1);return bbccookies.POLICY_REFRESH_DATE_MILLIS>=t.getTime()}else{return true}}else{return false}},_setPolicy:function(t){return f.apply(this,arguments)},readPolicy:function(){return l.apply(this,arguments)},_deletePolicy:function(){s(m,"",q)},_isConfirmed:function(){return n()!==null},_acceptsAll:function(){var t=l();return t&&!(j(t).indexOf("0")>-1)},_getCookieName:function(){return b.apply(this,arguments)},_showPrompt:function(){var t=((!this._isConfirmed()||this.policyRequiresRefresh())&&window.cta_enabled&&this.cookiesEnabled()&&!window.bbccookies_disable);return(window.orb&&window.orb.fig)?t&&(window.orb.fig("no")||window.orb.fig("ck")):t},_getPolicy:this.readPolicy};function b(u){var t=(""+u).match(/^([^=]+)(?==)/);return(t&&t.length?t[0]:"")}function j(t){return""+(t.ads?1:0)+(t.personalisation?1:0)+(t.performance?1:0)}function f(x){if(typeof x==="undefined"){x=i}if(typeof arguments[0]==="string"){var u=arguments[0],w=arguments[1];if(u==="necessary"){w=true}x=l();x[u]=w}else{if(typeof arguments[0]==="object"){x.necessary=true}}var v=new Date();v.setYear(v.getFullYear()+1);bbccookies.set(m+"="+j(x)+";domain=bbc.co.uk;path=/;expires="+v.toUTCString()+";");bbccookies.set(m+"="+j(x)+";domain=bbc.com;path=/;expires="+v.toUTCString()+";");bbccookies.set(m+"="+j(x)+";domain=bbci.co.uk;path=/;expires="+v.toUTCString()+";");var t=new Date(v.getTime());t.setMonth(t.getMonth()+1);bbccookies.set(bbccookies.POLICY_EXPIRY_COOKIENAME+"="+v.getTime()+";domain=bbc.co.uk;path=/;expires="+t.toUTCString()+";");bbccookies.set(bbccookies.POLICY_EXPIRY_COOKIENAME+"="+v.getTime()+";domain=bbc.com;path=/;expires="+t.toUTCString()+";");bbccookies.set(bbccookies.POLICY_EXPIRY_COOKIENAME+"="+v.getTime()+";domain=bbci.co.uk;path=/;expires="+t.toUTCString()+";");return x}function o(t){if(t===null){return null}var u=t.split("");return{ads:!!+u[0],personalisation:!!+u[1],performance:!!+u[2],necessary:true}}function n(){var t=new RegExp("(?:^|; ?)"+m+"=(\\d\\d\\d)($|;)"),u=document.cookie.match(t);if(!u){return null}return u[1]}function l(t){var u=o(n());if(!u){u=i}if(t){return u[t]}else{return u}}function e(t){return document.cookie=t+"=;expires="+q+";"}var g=!(window.bbccookies_flag==="ON"&&!bbccookies._acceptsAll()&&!window.bbccookies_disable);var k={},d={"personalisation":"ckps_.+|X-AB-iplayer-.+|ACTVTYMKR|BBC_EXAMPLE_COOKIE|BBCIplayer|BBCiPlayerM|BBCIplayerSession|BBCMediaselector|BBCPostcoder|bbctravel|CGISESSID|ed|food-view|forceDesktop|h4|IMRID|locserv|MyLang|myloc|NTABS|ttduserPrefs|V5|WEATHER|BBCScienceDiscoveryPlaylist_.+|bitratePref|correctAnswerCount|genreCookie|highestQuestionScore|incorrectAnswerCount|longestStreak|MSCSProfile|programmes-oap-expanded|quickestAnswer|score|servicePanel|slowestAnswer|totalTimeForAllFormatted|v|BBCwords|score|correctAnswerCount|highestQuestionScore|hploc|BGUID|BBCWEACITY|mstouch|myway|BBCNewsCustomisation|cbbc_anim|cbeebies_snd|bbcsr_usersx|cbeebies_rd|BBC-Latest_Blogs|zh-enc|pref_loc|m|bbcEmp.+|recs-.+|_lvd2|_lvs2|tick|_fcap_CAM1|_rcc2","performance":"ckpf_.+|optimizely.*|BBCLiveStatsClick|id|_em_.+|cookies_enabled|mbox|mbox-admin|mc_.+|omniture_unique|s_.+|sc_.+|adpolicyAdDisplayFrequency|s1|ns_session|ns_cookietest|ns_ux|NO-SA|tr_pr1|gvsurvey|bbcsurvey|si_v|sa_labels|obuid|mm_.+|mmid|mmcore.+|mmpa.+","ads":"ckad_.+|rsi_segs|c","necessary":"ckns_.+|BBC-UID|blq\\.dPref|SSO2-UID|BBC-H2-User|rmRpDetectReal|bbcComSurvey|IDENTITY_ENV|IDENTITY|IDENTITY-HTTPS|IDENTITY_SESSION|BBCCOMMENTSMODULESESSID|bbcBump.+|IVOTE_VOTE_HISTORY|pulse|BBCPG|BBCPGstat|ecos\\.dt"};function r(){var x=document.cookie.replace(/; +/g,";").split(";"),u,v=[];for(var w=0,t=x.length;w<t;w++){u=x[w];v.push(bbccookies._getCookieName(u))}return v}function h(w){var v=JSON.stringify(w);if(typeof(k[v])!=="undefined"){return k[v]}var u="";for(var t in w){if(w.hasOwnProperty(t)&&d[t]){if(w[t]===true){u+=(u?"|":"")+d[t]}}}k[v]=new RegExp("^("+(u?u:".*")+")$","i");return k[v]}bbccookies.getPolicyExpiryDateTime=function(){return bbccookies.POLICY_EXPIRY_COOKIENAME};bbccookies.purge=function(){var u=bbccookies.readPolicy(),w=r(),x;for(var v=0,t=w.length;v<t;v++){if(!bbccookies.isAllowed(w[v],u)){x=new Date();x.setTime(0);x=x.toUTCString();s(w[v],"deleted",x)}}};function p(){if(g){return}bbccookies.purge();contentLoaded(window,bbccookies.purge);if(window.addEventListener){window.addEventListener("beforeunload",bbccookies.purge,false)}else{if(window.attachEvent){window.attachEvent("onbeforeunload",bbccookies.purge)}else{window.onbeforeunload=bbccookies.purge}}}bbccookies.set=function(u,t){if(g){return document.cookie=u}var v=bbccookies._getCookieName(u);if(t||bbccookies.isAllowed(v)){return document.cookie=u}return null};bbccookies.isAllowed=function(v){var u=bbccookies.readPolicy();var t=h(u);return t.test(v)};p()})();
/*!
 * contentloaded.js
 *
 * Author: Diego Perini (diego.perini at gmail.com)
 * Summary: cross-browser wrapper for DOMContentLoaded
 * Updated: 20101020
 * License: MIT
 * Version: 1.2
 *
 * URL:
 * http://javascript.nwbox.com/ContentLoaded/
 * http://javascript.nwbox.com/ContentLoaded/MIT-LICENSE
 *
 */
function contentLoaded(d,i){var c=false,h=true,k=d.document,j=k.documentElement,a=k.addEventListener,n=a?"addEventListener":"attachEvent",l=a?"removeEventListener":"detachEvent",b=a?"":"on",m=function(o){if(o.type==="readystatechange"&&k.readyState!="complete"){return}(o.type==="load"?d:k)[l](b+o.type,m,false);if(!c&&(c=true)){i.call(d,o.type||o)}},g=function(){try{j.doScroll("left")}catch(o){setTimeout(g,50);return}m("poll")};if(k.readyState==="complete"){i.call(d,"lazy")}else{if(!a&&j.doScroll){try{h=!d.frameElement}catch(f){}if(h){g()}}k[n](b+"DOMContentLoaded",m,false);k[n](b+"readystatechange",m,false);d[n](b+"load",m,false)}}if(typeof(require)==="function"&&!require.defined("orb/cookies")){define("orb/cookies",window.bbccookies)}; /*]]>*/</script> <script type="text/javascript">/*<![CDATA[*/
(function(){window.orb={};window.orb.figState={ad:0,ap:0,ck:1,eu:1,mb:0,tb:0,uk:1,df:1};window.orb.fig=function(a){return(arguments.length)?window.orb.figState[a]:window.orb.figState};window.orb.fig.device={};window.orb.fig.geo={};window.orb.fig.user={};window.orb.fig.isDefault=function(){return window.orb.fig("df")};window.orb.fig.device.isTablet=function(){return window.orb.fig("tb")};window.orb.fig.device.isMobile=function(){return window.orb.fig("mb")};window.orb.fig.geo.isUK=function(){return window.orb.fig("uk")};window.orb.fig.geo.isEU=function(){return window.orb.fig("eu")};window.fig=window.fig||{};window.fig.manager={include:function(e){e=e||window;var g=false;var j=e.document,k=j.cookie,i=k.match(/(?:^|; ?)ckns_orb_fig=([^;]+)/),h;if(i){i=this.deserialise(decodeURIComponent(RegExp.$1));this.setFig(e,i)}if(window.fig.async&&typeof JSON!="undefined"){var b=(document.cookie.match("(^|; )ckns_orb_cachedfig=([^;]*)")||0)[2];h=b?JSON.parse(b):null;if(h){this.setFig(e,h);g=true}}var a="https://fig.bbc.co.uk/frameworks/fig/1/fig.js";if(g){j.write('<script src="'+a+'" async><'+"/script>")}else{j.write('<script src="'+a+'"><'+"/script>")}},confirm:function(a){return true},setFig:function(a,b){(function(){a.orb=a.orb||{};a.orb.figState=b})()},deserialise:function(b){var a={};b.replace(/([a-z]{2}):([0-9]+)/g,function(){a[RegExp.$1]=+RegExp.$2});return a}}})();fig.manager.include();/*]]>*/</script>
<!-- Nav Analytics : 78 -->
<script type="text/javascript">window.bbcFlagpoles_istats="ON",require.config({paths:{"istats-1":"//nav.files.bbci.co.uk/nav-analytics/0.1.0-78/js/istats-1","megavolt-client":"//nav.files.bbci.co.uk/nav-analytics/0.1.0-78/js/megavolt-client"}}),require.defined("orb/cookies")||(window.bbccookies?define("orb/cookies",function(){return window.bbccookies}):define("orb/cookies",function(){return{isAllowed:function(e){return!1}}})),require(["megavolt-client","istats-1","orb/cookies"],function(e,t,o){if(o.isAllowed("s1")){e.setMegavoltUrl("https://mvt.api.bbc.com");t.addCollector({name:"default",url:"https://sa.bbc.co.uk/bbc/bbc/s",separator:"&"});var i="mundo.page";t.setCountername(i),window.istats_countername&&t.setCountername(window.istats_countername),t.addLabels("ml_name=webmodule&ml_version=78")}});</script>

<script type="text/javascript">/*<![CDATA[*/
    window.bbcFlagpoles_istats = 'ON';
    window.orb = window.orb || {};

    if (typeof bbccookies !== 'undefined' && bbccookies.isAllowed('s1')) {
        var istatsTrackingUrl = '//sa.bbc.co.uk/bbc/bbc/s?name=mundo.page&cps_asset_id=36258063&page_type=Index&section=%2Fmundo%2Ffront_page&first_pub=2016-05-10T11%3A00%3A20%2B00%3A00&last_editorial_update=2017-08-25T03%3A58%3A27%2B00%3A00&curie=327bd4c8-3bff-27bf-e050-380a4e805a61%2Fdesktop%2Fdomestic&for_nation=do&app_version=1.206.0&bbc_site=news-ws-mundo&pal_route=asset&app_type=responsive&language=es-005&pal_webapp=tabloid&prod_name=mundo&app_name=mundo';
        require(['istats-1'], function (istats) {
            var counterName = (window.istats_countername) ? window.istats_countername : istatsTrackingUrl.match(/[\?&]name=([^&]*)/i)[1];
            istats.setCountername(counterName);

            istats.addLabels('cps_asset_id=36258063&page_type=Index&section=%2Fmundo%2Ffront_page&first_pub=2016-05-10T11%3A00%3A20%2B00%3A00&last_editorial_update=2017-08-25T03%3A58%3A27%2B00%3A00&curie=327bd4c8-3bff-27bf-e050-380a4e805a61%2Fdesktop%2Fdomestic&for_nation=do&app_version=1.206.0&bbc_site=news-ws-mundo&pal_route=asset&app_type=responsive&language=es-005&pal_webapp=tabloid&prod_name=mundo&app_name=mundo');
            var c = (document.cookie.match(/\bckns_policy=(\d\d\d)/) || []).pop() || '';
            istats.addLabels({
                                        'blq_s': '4d',
                    'blq_r': '2.7',
                    'blq_v': 'worldservice',
                    'blq_e': 'pal',
                                        'bbc_mc': (c ? 'ad' + c.charAt(0) + 'ps' + c.charAt(1) + 'pf' + c.charAt(2) : 'not_set')
                }
            );
        });
    }
    /*]]>*/</script>
 <script type="text/javascript">/*<![CDATA[*/ (function(undefined){if(!window.bbc){window.bbc={}}var ROLLING_PERIOD_DAYS=30;window.bbc.Mandolin=function(id,segments,opts){var now=new Date().getTime(),storedItem,DEFAULT_START=now,DEFAULT_RATE=1,COOKIE_NAME="ckpf_mandolin";opts=opts||{};this._id=id;this._segmentSet=segments;this._store=new window.window.bbc.Mandolin.Storage(COOKIE_NAME);this._opts=opts;this._rate=(opts.rate!==undefined)?+opts.rate:DEFAULT_RATE;this._startTs=(opts.start!==undefined)?new Date(opts.start).getTime():new Date(DEFAULT_START).getTime();this._endTs=(opts.end!==undefined)?new Date(opts.end).getTime():daysFromNow(ROLLING_PERIOD_DAYS);this._signupEndTs=(opts.signupEnd!==undefined)?new Date(opts.signupEnd).getTime():this._endTs;this._segment=null;if(typeof id!=="string"){throw new Error("Invalid Argument: id must be defined and be a string")}if(Object.prototype.toString.call(segments)!=="[object Array]"){throw new Error("Invalid Argument: Segments are required.")}if(opts.rate!==undefined&&(opts.rate<0||opts.rate>1)){throw new Error("Invalid Argument: Rate must be between 0 and 1.")}if(this._startTs>this._endTs){throw new Error("Invalid Argument: end date must occur after start date.")}if(!(this._startTs<this._signupEndTs&&this._signupEndTs<=this._endTs)){throw new Error("Invalid Argument: SignupEnd must be between start and end date")}removeExpired.call(this,now);var overrides=window.bbccookies.get().match(/ckns_mandolin_setSegments=([^;]+)/);if(overrides!==null){eval("overrides = "+decodeURIComponent(RegExp.$1)+";");if(overrides[this._id]&&this._segmentSet.indexOf(overrides[this._id])==-1){throw new Error("Invalid Override: overridden segment should exist in segments array")}}if(overrides!==null&&overrides[this._id]){this._segment=overrides[this._id]}else{if((storedItem=this._store.getItem(this._id))){this._segment=storedItem.segment}else{if(this._startTs<=now&&now<this._signupEndTs&&now<=this._endTs&&this._store.isEnabled()===true){this._segment=pick(segments,this._rate);if(opts.end===undefined){this._store.setItem(this._id,{segment:this._segment})}else{this._store.setItem(this._id,{segment:this._segment,end:this._endTs})}log.call(this,"mandolin_segment")}}}log.call(this,"mandolin_view")};window.bbc.Mandolin.prototype.getSegment=function(){return this._segment};function log(actionType,params){var that=this;require(["istats-1"],function(istats){istats.log(actionType,that._id+":"+that._segment,params?params:{})})}function removeExpired(expires){var items=this._store.getItems(),expiresInt=+expires;for(var key in items){if(items[key].end!==undefined&&+items[key].end<expiresInt){this._store.removeItem(key)}}}function getLastExpirationDate(data){var winner=0,rollingExpire=daysFromNow(ROLLING_PERIOD_DAYS);for(var key in data){if(data[key].end===undefined&&rollingExpire>winner){winner=rollingExpire}else{if(+data[key].end>winner){winner=+data[key].end}}}return(winner)?new Date(winner):new Date(rollingExpire)}window.bbc.Mandolin.prototype.log=function(params){log.call(this,"mandolin_log",params)};window.bbc.Mandolin.prototype.convert=function(params){log.call(this,"mandolin_convert",params);this.convert=function(){}};function daysFromNow(n){var endDate;endDate=new Date().getTime()+(n*60*60*24)*1000;return endDate}function pick(segments,rate){var picked,min=0,max=segments.length-1;if(typeof rate==="number"&&Math.random()>rate){return null}do{picked=Math.floor(Math.random()*(max-min+1))+min}while(picked>max);return segments[picked]}window.bbc.Mandolin.Storage=function(name){validateCookieName(name);this._cookieName=name;this._isEnabled=(bbccookies.isAllowed(this._cookieName)===true&&bbccookies.cookiesEnabled()===true)};window.bbc.Mandolin.Storage.prototype.setItem=function(key,value){var storeData=this.getItems();storeData[key]=value;this.save(storeData);return value};window.bbc.Mandolin.Storage.prototype.isEnabled=function(){return this._isEnabled};window.bbc.Mandolin.Storage.prototype.getItem=function(key){var storeData=this.getItems();return storeData[key]};window.bbc.Mandolin.Storage.prototype.removeItem=function(key){var storeData=this.getItems();delete storeData[key];this.save(storeData)};window.bbc.Mandolin.Storage.prototype.getItems=function(){return deserialise(this.readCookie(this._cookieName)||"")};window.bbc.Mandolin.Storage.prototype.save=function(data){window.bbccookies.set(this._cookieName+"="+encodeURIComponent(serialise(data))+"; expires="+getLastExpirationDate(data).toUTCString()+";")};window.bbc.Mandolin.Storage.prototype.readCookie=function(name){var nameEq=name+"=",ca=window.bbccookies.get().split("; "),i,c;validateCookieName(name);for(i=0;i<ca.length;i++){c=ca[i];if(c.indexOf(nameEq)===0){return decodeURIComponent(c.substring(nameEq.length,c.length))}}return null};function serialise(o){var str="";for(var p in o){if(o.hasOwnProperty(p)){str+='"'+p+'"'+":"+(typeof o[p]==="object"?(o[p]===null?"null":"{"+serialise(o[p])+"}"):'"'+o[p].toString()+'"')+","}}return str.replace(/,\}/g,"}").replace(/,$/g,"")}function deserialise(str){var o;str="{"+str+"}";if(!validateSerialisation(str)){throw"Invalid input provided for deserialisation."}eval("o = "+str);return o}var validateSerialisation=(function(){var OBJECT_TOKEN="<Object>",ESCAPED_CHAR='"\\n\\r\\u2028\\u2029\\u000A\\u000D\\u005C',ALLOWED_CHAR="([^"+ESCAPED_CHAR+"]|\\\\["+ESCAPED_CHAR+"])",KEY='"'+ALLOWED_CHAR+'+"',VALUE='(null|"'+ALLOWED_CHAR+'*"|'+OBJECT_TOKEN+")",KEY_VALUE=KEY+":"+VALUE,KEY_VALUE_SEQUENCE="("+KEY_VALUE+",)*"+KEY_VALUE,OBJECT_LITERAL="({}|{"+KEY_VALUE_SEQUENCE+"})",objectPattern=new RegExp(OBJECT_LITERAL,"g");return function(str){if(str.indexOf(OBJECT_TOKEN)!==-1){return false}while(str.match(objectPattern)){str=str.replace(objectPattern,OBJECT_TOKEN)}return str===OBJECT_TOKEN}})();function validateCookieName(name){if(name.match(/ ,;/)){throw"Illegal name provided, must be valid in browser cookie."}}})(); /*]]>*/</script>  <script type="text/javascript">  document.documentElement.className += (document.documentElement.className? ' ' : '') + 'orb-js';  fig.manager.confirm(); </script> <script src="http://static.bbci.co.uk/frameworks/barlesque/3.21.26/orb/4/script/orb/api.min.js"></script> <script src="http://static.bbci.co.uk/frameworks/barlesque/3.21.26/orb/4/script/orb/font.min.js"></script> <script type="text/javascript"> var blq = { environment: function() { return 'live'; } } </script>   <script type="text/javascript"> /*<![CDATA[*/ function oqsSurveyManager(w, flag) { if (flag !== 'OFF' && (w.orb.fig("no") || w.orb.fig("uk"))) { w.document.write('<script type="text/javascript" src="http://static.bbci.co.uk/frameworks/barlesque/3.21.26/orb/4/script/vendor/edr.min.js"><'+'/script>'); } } oqsSurveyManager(window, 'ON'); /*]]>*/ </script>             <!-- BBCDOTCOM template: responsive webservice  -->
        <!-- BBCDOTCOM head --><script type="text/javascript"> /*<![CDATA[*/ var _sf_startpt = (new Date()).getTime(); /*]]>*/ </script><style type="text/css">.bbccom_display_none{display:none;}</style><script type="text/javascript"> /*<![CDATA[*/ var bbcdotcomConfig, googletag = googletag || {}; googletag.cmd = googletag.cmd || []; var bbcdotcom = false; (function(){ if(typeof require !== 'undefined') { require({ paths:{ "bbcdotcom":"http://static.bbci.co.uk/bbcdotcom/1.63.0/script" } }); } })(); /*]]>*/ </script><script type="text/javascript"> /*<![CDATA[*/ var bbcdotcom = { adverts: { keyValues: { set: function() {} } }, advert: { write: function () {}, show: function () {}, isActive: function () { return false; }, layout: function() { return { reset: function() {} } } }, config: { init: function() {}, isActive: function() {}, setSections: function() {}, isAdsEnabled: function() {}, setAdsEnabled: function() {}, isAnalyticsEnabled: function() {}, setAnalyticsEnabled: function() {}, setAssetPrefix: function() {}, setVersion: function () {}, setJsPrefix: function() {}, setSwfPrefix: function() {}, setCssPrefix: function() {}, setConfig: function() {}, getAssetPrefix: function() {}, getJsPrefix: function () {}, getSwfPrefix: function () {}, getCssPrefix: function () {} }, survey: { init: function(){ return false; } }, data: {}, init: function() {}, objects: function(str) { return false; }, locale: { set: function() {}, get: function() {} }, setAdKeyValue: function() {}, utils: { addEvent: function() {}, addHtmlTagClass: function() {}, log: function () {} }, addLoadEvent: function() {} }; /*]]>*/ </script><script type="text/javascript"> /*<![CDATA[*/ (function(){ if (typeof orb !== 'undefined' && typeof orb.fig === 'function') { if (orb.fig('ad') && orb.fig('uk') == 0) { bbcdotcom.data = { ads: (orb.fig('ad') ? 1 : 0), stats: (orb.fig('uk') == 0 ? 1 : 0), statsProvider: orb.fig('ap') }; } } else { document.write('<script type="text/javascript" src="'+('https:' == document.location.protocol ? 'https://www.bbc.com' : 'http://tps.bbc.com')+'/wwscripts/data">\x3C/script>'); } })(); /*]]>*/ </script><script type="text/javascript"> /*<![CDATA[*/ (function(){ if (typeof orb === 'undefined' || typeof orb.fig !== 'function') { bbcdotcom.data = { ads: bbcdotcom.data.a, stats: bbcdotcom.data.b, statsProvider: bbcdotcom.data.c }; } if (bbcdotcom.data.ads == 1) { document.write('<script type="text/javascript" src="'+('https:' == document.location.protocol ? 'https://www.bbc.co.uk' : 'http://www.bbc.co.uk')+'/wwscripts/flag">\x3C/script>'); } })(); /*]]>*/ </script><script type="text/javascript"> /*<![CDATA[*/ (function(){ if (window.bbcdotcom && (typeof bbcdotcom.flag == 'undefined' || (typeof bbcdotcom.data.ads !== 'undefined' && bbcdotcom.flag.a != 1))) { bbcdotcom.data.ads = 0; } if (/[?|&]ads/.test(window.location.href) || /(^|; )ads=on; /.test(document.cookie) || /; ads=on(; |$)/.test(document.cookie)) { bbcdotcom.data.ads = 1; bbcdotcom.data.stats = 1; } if (window.bbcdotcom && (bbcdotcom.data.ads == 1 || bbcdotcom.data.stats == 1)) { bbcdotcom.assetPrefix = "http://static.bbci.co.uk/bbcdotcom/1.63.0/"; if (/(sandbox|int)(.dev)*.bbc.co*/.test(window.location.href) || /[?|&]ads-debug/.test(window.location.href) || document.cookie.indexOf('ads-debug=') !== -1) { document.write('<script type="text/javascript" src="http://static.bbci.co.uk/bbcdotcom/1.63.0/script/dist/bbcdotcom.dev.js">\x3C/script>'); } else { document.write('<script type="text/javascript" src="http://static.bbci.co.uk/bbcdotcom/1.63.0/script/dist/bbcdotcom.js">\x3C/script>'); } } })(); /*]]>*/ </script><script type="text/javascript"> if (window.bbcdotcom && bbcdotcom.data.stats == 1) { document.write('<link rel="dns-prefetch" href="//secure-us.imrworldwide.com/">'); document.write('<link rel="dns-prefetch" href="//me-cdn.effectivemeasure.net/">'); document.write('<link rel="dns-prefetch" href="//ssc.api.bbc.com/">'); } if (window.bbcdotcom && bbcdotcom.data.ads == 1) { document.write('<link rel="dns-prefetch" href="//www.googletagservices.com/">'); } </script><script type="text/javascript"> /*<![CDATA[*/ (function(){ if (window.bbcdotcom && (bbcdotcom.data.ads == 1 || bbcdotcom.data.stats == 1)) { bbcdotcomConfig = {"adFormat":"standard","adKeyword":"","adMode":"smart","adsEnabled":true,"appAnalyticsSections":"mundo","asyncEnabled":true,"disableInitialLoad":false,"advertInfoPageUrl":"\/mundo\/institucional\/2012\/06\/000000_ayuda_sobre_publicidad","advertisementText":"Publicidad","analyticsEnabled":false,"appName":"tabloid","assetPrefix":"http:\/\/static.bbci.co.uk\/bbcdotcom\/1.63.0\/","customAdParams":[],"customStatsParams":[],"headline":"","id":"36258063","inAssociationWithText":"En asociaci\u00f3n con","keywords":"","language":"","orbTransitional":false,"outbrainEnabled":true,"adsenseEnabled":true,"adsportappEnabled":true,"palEnv":"live","productName":"","sections":[],"comScoreEnabled":false,"comscoreSite":"bbc","comscoreID":"19293874","comscorePageName":"","slots":"","sponsoredByText":"Patrocinado por","adsByGoogleText":"Avisos de Google","summary":"","type":"INDEX","features":{"testfeature":{"name":"testfeature","envs":["sandbox","int","test"],"on":true,"options":{},"override":null},"lxadverts":{"name":"lxadverts","envs":[],"on":true,"options":{},"override":null}},"staticBase":"\/bbcdotcom","staticHost":"http:\/\/static.bbci.co.uk","staticVersion":"1.63.0","staticPrefix":"http:\/\/static.bbci.co.uk\/bbcdotcom\/1.63.0","dataHttp":"tps.bbc.com","dataHttps":"www.bbc.com","flagHttp":"www.bbc.co.uk","flagHttps":"www.bbc.co.uk","analyticsHttp":"sa.bbc.com","analyticsHttps":"ssa.bbc.com"}; bbcdotcom.config.init(bbcdotcomConfig, bbcdotcom.data, window.location, window.document); bbcdotcom.config.setAssetPrefix("http://static.bbci.co.uk/bbcdotcom/1.63.0/"); bbcdotcom.config.setVersion("1.63.0"); document.write('<!--[if IE 7]><script type="text/javascript">bbcdotcom.config.setIE7(true);\x3C/script><![endif]-->'); document.write('<!--[if IE 8]><script type="text/javascript">bbcdotcom.config.setIE8(true);\x3C/script><![endif]-->'); document.write('<!--[if IE 9]><script type="text/javascript">bbcdotcom.config.setIE9(true);\x3C/script><![endif]-->'); if (/[?|&]ex-dp/.test(window.location.href) || document.cookie.indexOf('ex-dp=') !== -1) { bbcdotcom.utils.addHtmlTagClass('bbcdotcom-ex-dp'); } } })(); /*]]>*/ </script><script type="text/javascript"> /*<![CDATA[*/ (function() { window.bbcdotcom.head = true; }()); /*]]>*/ </script>             <!--Searchbox:132-->  <script type="text/javascript">
  // Globally available search context
  window.SEARCHBOX={"variant":"worldservice","locale":"es-005","navSearchboxStaticPrefix":"//nav.files.bbci.co.uk/searchbox/1.0.0-132","searchboxAppStaticPrefix":"//search.files.bbci.co.uk/searchbox-app/1.0.16","searchFormHtml":"<div tabindex=\"-1\" data-reactid=\".2fvssx2jgg\" data-react-checksum=\"1923032532\"><div data-reactid=\".2fvssx2jgg.0\"><section class=\"se-searchbox-panel\" data-reactid=\".2fvssx2jgg.0.0\"><div class=\"se-g-wrap\" data-reactid=\".2fvssx2jgg.0.0.0\"><div class=\"se-g-layout\" data-reactid=\".2fvssx2jgg.0.0.0.0\"><div class=\"se-g-layout__item se-searchbox-title\" aria-hidden=\"true\" data-reactid=\".2fvssx2jgg.0.0.0.0.0\">search</div><div class=\"se-g-layout__item se-searchbox\" data-reactid=\".2fvssx2jgg.0.0.0.0.1\"><form accept-charset=\"utf-8\" id=\"searchboxDrawerForm\" method=\"get\" action=\"//search.bbc.co.uk/search\" data-reactid=\".2fvssx2jgg.0.0.0.0.1.0\"><label class=\"se-searchbox__input\" for=\"se-searchbox-input-field\" data-reactid=\".2fvssx2jgg.0.0.0.0.1.0.0\"><span class=\"se-sr-only\" data-reactid=\".2fvssx2jgg.0.0.0.0.1.0.0.0\">Search Term</span><input name=\"q\" type=\"text\" value=\"\" id=\"se-searchbox-input-field\" class=\"se-searchbox__input__field\" maxlength=\"512\" autocomplete=\"off\" autocorrect=\"off\" autocapitalize=\"off\" spellcheck=\"false\" tabindex=\"0\" data-reactid=\".2fvssx2jgg.0.0.0.0.1.0.0.1\"/></label><input type=\"hidden\" name=\"scope\" value=\"\" data-reactid=\".2fvssx2jgg.0.0.0.0.1.0.2\"/><button type=\"submit\" class=\"se-searchbox__submit\" tabindex=\"0\" data-reactid=\".2fvssx2jgg.0.0.0.0.1.0.3\">Search</button><button type=\"button\" class=\"se-searchbox__clear se-searchbox__clear--visible\" tabindex=\"0\" data-reactid=\".2fvssx2jgg.0.0.0.0.1.0.4\">Close</button></form></div></div></div></section><div aria-live=\"polite\" aria-atomic=\"true\" class=\"se-suggestions-container\" data-reactid=\".2fvssx2jgg.0.1\"><section class=\"se-g-wrap\" data-reactid=\".2fvssx2jgg.0.1.0\"></section></div></div></div>","searchScopePlaceholder":"<input type=\"hidden\" name=\"scope\" id=\"orb-search-scope\" value=\"mundo\">","searchScopeParam":"?scope=mundo","searchScopeTemplate":"mundo","searchPlaceholderWrapperStart":"","searchPlaceholderWrapperEnd":""};
  window.SEARCHBOX.suppress = false;
  window.SEARCHBOX.searchScope = SEARCHBOX.searchScopeTemplate.split('-')[0];
</script>
<link rel="stylesheet" href="//nav.files.bbci.co.uk/searchbox/1.0.0-132/css/main.css">
<!--[if IE 8]>
  <script type="text/javascript" src="//nav.files.bbci.co.uk/searchbox/1.0.0-132/script/html5shiv.min.js"></script>
  <script type="text/javascript">window['searchboxIEVersion'] = 8;</script>
  <link rel="stylesheet" href="//nav.files.bbci.co.uk/searchbox/1.0.0-132/css/ie8.css">
<![endif]-->
<!--[if IE 9]>
  <script type="text/javascript">window['searchboxIEVersion'] = 9;</script>
<![endif]-->
  <!--NavID:0.2.0-143--> <link rel="stylesheet" href="//static.bbc.co.uk/id/0.37.24/style/id-cta.css" /> <link rel="stylesheet" href="//static.bbc.co.uk/id/0.37.24/style/id-cta-v5.css" /> <!--[if IE 8]><link href="//static.bbc.co.uk/id/0.37.24/style/ie8.css" rel="stylesheet"/> <![endif]--> <script type="text/javascript"> /* <![CDATA[ */ var map = {};  if (typeof(map['jssignals-1']) == 'undefined') { map['jssignals-1'] = 'https://static.bbc.co.uk/frameworks/jssignals/0.3.6/modules/jssignals-1'; }  require({paths: map}); /* ]]> */ </script>   <script src="//static.bbc.co.uk/id/0.37.24/modules/idcta/dist/idcta-1.min.js"></script>  <script type="text/javascript"> (function () { if (!window.require) { throw new Error('idcta: could not find require module'); } if(typeof(map) == 'undefined') { var map = {}; } if(!!document.createElementNS && !!document.createElementNS('http://www.w3.org/2000/svg', "svg").createSVGRect) { document.documentElement.className += ' id-svg'; } var ptrt = RegExp("[\\?&]ptrt=([^&#]*)").exec(document.location.href); var ENDPOINT_URL = '//' + ((window.location.protocol == "https:") ? ('ssl.bbc.co.uk').replace("www.", "ssl.") : ('ssl.bbc.co.uk').replace("ssl.", "www.")); var ENDPOINT_CONFIG = ('/idcta/config?callback&amp;locale=es-005&ptrt=' + encodeURI((ptrt ? ptrt[1] : document.location.href))).replace(/\&amp;/g, '&'); var ENDPOINT_TRANSLATIONS = '/idcta/translations?callback&locale=es-005'; map['idapp-1'] = '//static.bbc.co.uk/idapp/0.72.58/modules/idapp/idapp-1'; map['idcta'] = '//static.bbc.co.uk/id/0.37.24/modules/idcta'; map['idcta/config'] = [ENDPOINT_URL + ENDPOINT_CONFIG, '//static.bbc.co.uk/id/0.37.24/modules/idcta/fallbackConfig']; map['idcta/translations'] = [ENDPOINT_URL + ENDPOINT_TRANSLATIONS, '//static.bbc.co.uk/id/0.37.24/modules/idcta/fallbackTranslations']; require({paths: map}); /* * Temporary code * To be removed when old id-statusbar-config is no longer supported */ define('id-statusbar-config', ['idcta/id-config'], function(conf) { return conf; }); define('idcta/id-statusbar-config', ['idcta/id-config'], function(conf) { return conf; }); })(); </script>

             
                    
        <link type="text/css" rel="stylesheet" href="http://static.bbci.co.uk/news/1.206.01880/stylesheets/services/mundo/core.css">
    <!--[if lt IE 9]>
        <link type="text/css" rel="stylesheet" href="http://static.bbci.co.uk/news/1.206.01880/stylesheets/services/mundo/old-ie.css">
        <script src="http://static.bbci.co.uk/news/1.206.01880/js/vendor/html5shiv/html5shiv.js"></script>
    <![endif]-->
 <script id="news-loader"> if (document.getElementById("responsive-news")) { window.bbcNewsResponsive = true; } var isIE = (function() { var undef, v = 3, div = document.createElement('div'), all = div.getElementsByTagName('i'); while ( div.innerHTML = '<!--[if gt IE ' + (++v) + ']><i></i><![endif]-->', all[0] ); return v > 4 ? v : undef; }()); var modernDevice = 'querySelector' in document && 'localStorage' in window && 'addEventListener' in window, forceCore = document.cookie.indexOf('ckps_force_core') !== -1; window.cutsTheMustard = modernDevice && !forceCore; if (window.cutsTheMustard) { document.documentElement.className += ' ctm'; var insertPoint = document.getElementById('news-loader'), config = {"asset":{"asset_id":"36258063","asset_uri":"\/mundo\/front_page","original_asset_uri":null,"first_created":{"date":"2016-05-10 11:00:20","timezone_type":3,"timezone":"UTC"},"last_updated":{"date":"2017-08-25 03:58:27","timezone_type":3,"timezone":"UTC"},"options":{"allowAdvertising":true},"section":{"name":"Noticias","id":"102454","uri":"\/mundo\/front_page","urlIdentifier":"\/mundo\/front_page"},"language":"es","edition":"International","audience":"domestic","iStats_counter_name":"mundo.page","type":"IDX","curie":"asset:327bd4c8-3bff-27bf-e050-380a4e805a61\/desktop\/domestic"},"smpBrand":null,"staticHost":"http:\/\/static.bbci.co.uk","environment":"live","locatorVersion":"dev","pathPrefix":"\/mundo","staticPrefix":"http:\/\/static.bbci.co.uk\/news\/1.206.01880","jsPath":"http:\/\/static.bbci.co.uk\/news\/1.206.01880\/js","cssPath":"http:\/\/static.bbci.co.uk\/news\/1.206.01880\/stylesheets\/services\/mundo","cssPostfix":"","dynamic":null,"features":{"localnews":true,"video":true,"liveeventcomponent":true,"mediaassetpage":true,"gallery":true,"rollingnews":true,"sportstories":true,"radiopromo":true,"fromothernewssites":true,"locallive":true,"weather":true},"features2":{"svg_brand":true,"chartbeat":true,"breaking_news":true,"most_popular":true,"most_popular_tabs":true,"routing":true,"igor_device_redirect":false,"rolling_news":true,"orb":true,"nav":true,"timezone":true,"audio":true,"top_stories_promo":true,"features_and_analysis":true,"pulse_survey":false,"adverts":true,"adverts_async":true,"adexpert":true,"config_based_layout":true,"live_v2_stream":true,"share_tools":true,"extracted_share_tools":true,"follow_us":true,"open_graph":true,"comments":true,"comments_enhanced":true,"archive_fallback":true,"contact_form":true,"ws_newsletter":true,"enable_audio_on_stories":true,"preroll_ads_on_maps":true,"story_single_column_layout":true,"mpulse":false,"media_indexes":true,"ldp_indexes":true,"media_player":true,"comscore_analytics":true,"recent_assets_indexes":true,"ldp_tag_augmentation":true,"rio2016_medals":true,"story_sticky_player":true,"amp_link":true,"meta_verification":true,"embedephant-social-embeds":true,"interactive-social-embeds":true,"social-embeds":true},"configuration":{"showtimestamp":"1","showweather":"","showsport":"1","showolympics":"1","showfeaturemain":"1","candyplatform":"EnhancedMobile","showwatchlisten":"","showspecialreports":"1","videotopiccandyid":"temas\/video","showvideofeedsections":"","showstorytopstories":"","showstoryfeaturesandanalysis":"1","showstorymostpopular":"1","showgallery":"1","cms":"topcat"},"pollingHost":"https:\/\/polling.bbc.co.uk","service":"mundo","locale":"es","locatorHost":null,"locatorFlagPole":true,"local":{"allowLocationLookup":true},"isWorldService":true,"isChannelPage":false,"languageVariant":"","commentsHost":"https:\/\/www.bbc.co.uk","search":null,"comscoreAnalytics":{"virtual_site":"news-ws-mundo"}}; config.configuration['get'] = function (key) { return this[key.toLowerCase()]; };  var bootstrapUI=function(){var e=function(){if(navigator.userAgent.match(/(Android (2.0|2.1))|(Nokia)|(OSRE\/)|(Opera (Mini|Mobi))|(w(eb)?OSBrowser)|(UCWEB)|(Windows Phone)|(XBLWP)|(ZuneWP)/))return!1;if(navigator.userAgent.match(/MSIE 10.0/))return!0;var e,t=document,n=t.head||t.getElementsByTagName("head")[0],r=t.createElement("style"),s=t.implementation||{hasFeature:function(){return!1}};r.type="text/css",n.insertBefore(r,n.firstChild),e=r.sheet||r.styleSheet;var i=s.hasFeature("CSS2","")?function(t){if(!e||!t)return!1;var n=!1;try{e.insertRule(t,0),n=!/unknown/i.test(e.cssRules[0].cssText),e.deleteRule(e.cssRules.length-1)}catch(r){}return n}:function(t){return e&&t?(e.cssText=t,0!==e.cssText.length&&!/unknown/i.test(e.cssText)&&0===e.cssText.replace(/\r+|\n+/g,"").indexOf(t.split(" ")[0])):!1};return i('@font-face{ font-family:"font";src:"font.ttf"; }')}();e&&(document.getElementsByTagName("html")[0].className+=" ff"),function(){var e=document.documentElement.style;("flexBasis"in e||"WebkitFlexBasis"in e||"msFlexBasis"in e)&&(document.documentElement.className+=" flex")}();var t,n,r,s,i,a={},o=function(){var e=document.documentElement.clientWidth,n=window.innerWidth,r=n>1.5*e;t=r?e:n},u=function(e){var t=document.createElement("link");t.setAttribute("rel","stylesheet"),t.setAttribute("type","text/css"),t.setAttribute("href",n+e+r+".css"),t.setAttribute("media",i[e]),s.parentNode.insertBefore(t,s),delete i[e]},c=function(e,n,r){n&&!r&&t>=n&&u(e),r&&!n&&r>=t&&u(e),n&&r&&t>=n&&r>=t&&u(e)},l=function(e){if(a[e])return a[e];var t=e.match(/\(min\-width:[\s]*([\s]*[0-9\.]+)(px|em)[\s]*\)/),n=e.match(/\(max\-width:[\s]*([\s]*[0-9\.]+)(px|em)[\s]*\)/),r=t&&parseFloat(t[1])||null,s=n&&parseFloat(n[1])||null;return a[e]=[r,s],a[e]},f=function(){var e=0;for(var t in i)e++;return e},m=function(){f()||window.removeEventListener("resize",d,!1);for(var e in i){var t=i[e],n=l(t);c(e,n[0],n[1])}},d=function(){o(),m()},h=function(e,t){i=e,n=t.path+("/"!==t.path.substr(-1)?"/":""),r=t.postfix,s=t.insertBefore,o(),m(),window.addEventListener("resize",d,!1)};return{stylesheetLoaderInit:h}}(); var stylesheets = {"compact":"(max-width: 599px)","tablet":"(min-width: 600px)","wide":"(min-width: 1008px)"}; bootstrapUI.stylesheetLoaderInit(stylesheets, { path: 'http://static.bbci.co.uk/news/1.206.01880/stylesheets/services/mundo', postfix: '', insertBefore: insertPoint }); var loadRequire = function(){ var js_paths = {"jquery-1.9":"vendor\/jquery-1\/jquery","jquery-1":"http:\/\/static.bbci.co.uk\/frameworks\/jquery\/0.4.1\/sharedmodules\/jquery-1.7.2","demi-1":"http:\/\/static.bbci.co.uk\/frameworks\/demi\/0.10.1\/sharedmodules\/demi-1","swfobject-2":"http:\/\/static.bbci.co.uk\/frameworks\/swfobject\/0.1.10\/sharedmodules\/swfobject-2","jquery":"vendor\/jquery-2\/jquery.min","domReady":"vendor\/require\/domReady","translation":"module\/translations\/es","bump-3":"\/\/emp.bbci.co.uk\/emp\/bump-3\/bump-3"};  js_paths.navigation = 'module/nav/navManager';  requirejs.config({ baseUrl: 'http://static.bbci.co.uk/news/1.206.01880/js', map: { 'vendor/locator': { 'module/bootstrap': 'vendor/locator/bootstrap', 'locator/stats': 'vendor/locator/stats', 'locator/locatorView': 'vendor/locator/locatorView' } }, paths: js_paths, waitSeconds: 30 }); define('config', function () { return config; });             require(["compiled\/all"], function() {
      require(['domReady'], function (domReady) { domReady(function () { require(["module\/dotcom\/handlerAdapter","module\/stats\/statsSubscriberAdapter","module\/alternativeJsStrategy\/controller","module\/iconLoaderAdapter","module\/polyfill\/location.origin","module\/indexTitleAdaptor","module\/navigation\/handlerAdaptor","module\/noTouchDetectionForCss","module\/components\/commentCountAdapter","module\/components\/fauxBlockLink","module\/components\/responsiveImage","module\/components\/timestampAdaptor","module\/radioPlayerLink","module\/comscoreAdapter"], function() {  require(["module\/strategiserAdaptor"]);  }); }); });              });
     };  loadRequire();  } else { var l = document.createElement('link'); l.href = 'http://static.bbci.co.uk/news/1.206.01880/icons/generated/icons.fallback.css'; l.rel = 'stylesheet'; document.getElementsByTagName('head')[0].appendChild(l); } </script>  <script type="text/javascript"> /*<![CDATA[*/ bbcdotcom.init({adsToDisplay:['leaderboard', 'mpu', 'native', 'mpu_bottom', 'adsense']}); /*]]>*/ </script>      <noscript><link href="http://static.bbci.co.uk/news/1.206.01880/icons/generated/icons.fallback.css" rel="stylesheet"></noscript>

                
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=1">

                    
    </head>
<!--[if IE]><body id="asset-type-idx" class="ie device--feature"><![endif]-->
<!--[if !IE]>--><body id="asset-type-idx" class="device--feature"><!--<![endif]-->
    <div class="direction" >

            <div data-batch-load-url="/mundo/pattern-library-batch?components%5Bcomp-most-popular%5D%5BassetId%5D=36258063&components%5Bcomp-most-popular%5D%5Bbatch_uses_alt_js%5D=1&components%5Bcomp-most-popular%5D%5Bloading_strategy%5D=batch_load&components%5Bcomp-most-popular%5D%5Bdevice_groups%5D=group4&components%5Bcomp-follow-us%5D%5BassetId%5D=36258063&components%5Bcomp-follow-us%5D%5Bbatch_uses_alt_js%5D=1&components%5Bcomp-follow-us%5D%5Bloading_strategy%5D=batch_load&components%5Bcomp-follow-us%5D%5B_requestPath%5D=%2Fmundo"></div>
    
             <!-- BBCDOTCOM bodyFirst --><div id="bbccom_interstitial_ad" class="bbccom_display_none"></div><div id="bbccom_interstitial" class="bbccom_display_none"><script type="text/javascript"> /*<![CDATA[*/ (function() { if (window.bbcdotcom && bbcdotcom.config.isActive('ads')) { googletag.cmd.push(function() { googletag.display('bbccom_interstitial'); }); } }()); /*]]>*/ </script></div><div id="bbccom_wallpaper_ad" class="bbccom_display_none"></div><div id="bbccom_wallpaper" class="bbccom_display_none"><script type="text/javascript"> /*<![CDATA[*/ (function() { var wallpaper; if (window.bbcdotcom && bbcdotcom.config.isActive('ads')) { if (bbcdotcom.config.isAsync()) { googletag.cmd.push(function() { googletag.display('bbccom_wallpaper'); }); } else if (typeof googletag !== "undefined" && typeof googletag.display === "function") { googletag.display("wallpaper"); } wallpaper = bbcdotcom.adverts.adRegister.getAd('wallpaper'); } }()); /*]]>*/ </script></div><script type="text/javascript"> /*<![CDATA[*/ (function() { if (window.bbcdotcom && bbcdotcom.config.isActive('ads')) { document.write(unescape('%3Cscript id="gnlAdsEnabled" class="bbccom_display_none"%3E%3C/script%3E')); } if (window.bbcdotcom && bbcdotcom.config.isActive('analytics')) { document.write(unescape('%3Cscript id="gnlAnalyticsEnabled" class="bbccom_display_none"%3E%3C/script%3E')); } }()); /*]]>*/ </script><script type="text/javascript"> /*<![CDATA[*/ (function() { window.bbcdotcom.bodyFirst = true; }()); /*]]>*/ </script> <div id="blq-global"> <div id="blq-pre-mast">  </div> </div>  <script type="text/html" id="blq-bbccookies-tmpl"><![CDATA[ <section> <div id="bbccookies" class="bbccookies-banner orb-banner-wrapper bbccookies-d"> <div id="bbccookies-prompt" class="orb-banner b-g-p b-r b-f"> <h2 class="orb-banner-title"> Cookies on the BBC website </h2> <p class="orb-banner-content" dir="ltr"> The BBC has updated its cookie policy. We use cookies to ensure that we give you the best experience on our website. This includes cookies from third party social media websites if you visit a page which contains embedded content from social media. Such third party cookies may track your use of the BBC website.<span class="bbccookies-international-message"> We and our partners also use cookies to ensure we show you advertising that is relevant to you.</span> If you continue without changing your settings, we'll assume that you are happy to receive all cookies on the BBC website. However, you can change your cookie settings at any time. </p> <ul class="orb-banner-options"> <li id="bbccookies-continue"> <button type="button" id="bbccookies-continue-button">Continue</button> </li> <li id="bbccookies-settings"> <a href="/privacy/cookies/managing/cookie-settings.html">Change settings</a> </li> <li id="bbccookies-more"><a href="/privacy/cookies/bbc">Find out more</a></li></ul> </div> </div> </section> ]]></script> <script type="text/javascript">/*<![CDATA[*/ (function(){if(bbccookies._showPrompt()){var g=document,b=g.getElementById("blq-pre-mast"),e=g.getElementById("blq-bbccookies-tmpl"),a,f;if(b&&g.createElement){a=g.createElement("div");f=e.innerHTML;f=f.replace("<"+"![CDATA[","").replace("]]"+">","");a.innerHTML=f;b.appendChild(a);blqCookieContinueButton=g.getElementById("bbccookies-continue-button");blqCookieContinueButton.onclick=function(){a.parentNode.removeChild(a);return false};bbccookies._setPolicy(bbccookies.readPolicy())}var c=g.getElementById("bbccookies");if(c&&!window.orb.fig("uk")){c.className=c.className.replace(/\bbbccookies-d\b/,"");c.className=c.className+(" bbccookies-w")}}})(); /*]]>*/</script>   <noscript><p style="position: absolute; top: -999em"><img src="https://sa.bbc.co.uk/bbc/bbc/s?name=mundo.page&amp;ml_name&#x3D;webmodule&amp;ml_version&#x3D;78&amp;blq_js_enabled=0&blq_s=4d&blq_r=2.7&blq_v=worldservice&blq_e=pal&cps_asset_id=36258063&page_type=Index&section=%2Fmundo%2Ffront_page&first_pub=2016-05-10T11%3A00%3A20%2B00%3A00&last_editorial_update=2017-08-25T03%3A58%3A27%2B00%3A00&curie=327bd4c8-3bff-27bf-e050-380a4e805a61%2Fdesktop%2Fdomestic&for_nation=do&app_version=1.206.0&bbc_site=news-ws-mundo&pal_route=asset&app_type=responsive&language=es-005&pal_webapp=tabloid&prod_name=mundo&app_name=mundo" height="1" width="1" alt=""></p></noscript>  <!-- Begin iStats 20100118 (UX-CMC 1.1009.3) --> <script type="text/javascript">/*<![CDATA[*/ if (typeof bbccookies !== 'undefined' && bbccookies.isAllowed('s1')) { (function () { require(['istats-1'], function (istats) { istatsTrackingUrl = istats.getDefaultURL(); if (istats.isEnabled() && bbcFlagpoles_istats === 'ON') { sitestat(istatsTrackingUrl); } else { window.ns_pixelUrl = istatsTrackingUrl; /* used by Flash library to track */ } function sitestat(n) { var j = document, f = j.location, b = ""; if (j.cookie.indexOf("st_ux=") != -1) { var k = j.cookie.split(";"); var e = "st_ux", h = document.domain, a = "/"; if (typeof ns_ != "undefined" && typeof ns_.ux != "undefined") { e = ns_.ux.cName || e; h = ns_.ux.cDomain || h; a = ns_.ux.cPath || a } for (var g = 0, f = k.length; g < f; g++) { var m = k[g].indexOf("st_ux="); if (m != -1) { b = "&" + decodeURI(k[g].substring(m + 6)) } } bbccookies.set(e + "=; expires=" + new Date(new Date().getTime() - 60).toGMTString() + "; path=" + a + "; domain=" + h); } window.ns_pixelUrl = n;  } }); })(); } else { window.istats = {enabled: false}; } /*]]>*/</script> <!-- End iStats (UX-CMC) -->  
 <!--[if (gt IE 8) | (IEMobile)]><!--> <header id="orb-banner" role="banner"> <!--<![endif]--> <!--[if (lt IE 9) & (!IEMobile)]> <![if (IE 8)]> <header id="orb-banner" role="banner" class="orb-old-ie orb-ie8"> <![endif]> <![if (IE 7)]> <header id="orb-banner" role="banner" class="orb-old-ie orb-ie7"> <![endif]> <![if (IE 6)]> <header id="orb-banner" role="banner" class="orb-old-ie orb-ie6"> <![endif]> <![endif]--> <div id="orb-header"  class="orb-nav-pri orb-nav-pri-white b-header--white--black orb-nav-empty"  data-max-w="0"  data-max-d="0"  > <div class="orb-nav-pri-container b-r b-g-p"> <div class="orb-nav-section orb-nav-blocks"> <a href="/"> <img  src="http://static.bbci.co.uk/frameworks/barlesque/3.21.26/orb/4/img/bbc-blocks-dark.png" width="84" height="24" alt="BBC" /> </a> </div> <section> <div class="orb-skip-links"> <h2>Vínculos sobre accesibilidad</h2> <ul>  <li><a href="#page">Ir al contenido</a></li>  <li><a id="orb-accessibility-help" href="/accessibility/">Accessibility Help</a></li> </ul> </div> </section>  <div id="mybbc-wrapper" class="orb-nav-section orb-nav-id orb-nav-focus"> <div id="idcta-statusbar" class="orb-nav-section orb-nav-focus"> <a id="idcta-link" href="https://account.bbc.com/account?lang=es-005&ptrt=http%3A%2F%2Fwww.bbc.com%2Fmundo"> <span id="idcta-username">BBC iD</span> </a> </div>  <script type="text/javascript"> require(['idcta/statusbar'], function(statusbar) { new statusbar.Statusbar({"id":"idcta-statusbar","locale":"es-005","publiclyCacheable":true}); }); </script>

 </div>  <nav role="navigation" class="orb-nav"> <div class="orb-nav-section orb-nav-links orb-nav-focus" id="orb-nav-links"> <h2>Navegación en la BBC</h2> <ul>    <li  class="orb-nav-news orb-d"  > <a href="/news/">News</a> </li>    <li  class="orb-nav-newsdotcom orb-w"  > <a href="http://www.bbc.com/news/">News</a> </li>    <li  class="orb-nav-sport"  > <a href="/sport/">Sport</a> </li>    <li  class="orb-nav-weather"  > <a href="/weather/">Weather</a> </li>    <li  class="orb-nav-radio"  > <a href="/worldserviceradio/">Radio</a> </li>    <li  class="orb-nav-arts orb-d"  > <a href="/arts/">Arts</a> </li>    <li id="orb-nav-more"><a href="#orb-footer" data-alt="Más">Menú<span class="orb-icon orb-icon-arrow"></span></a></li> </ul> </div> </nav>   <div class="orb-nav-section orb-nav-search"> <a class="orb-search__button" href="http://search.bbc.co.uk/search?scope&#x3D;mundo" title="Buscar en la BBC">Buscar</a>

<form class="b-f" id="orb-search-form" role="search" method="get"
      action="//search.bbc.co.uk/search" accept-charset="utf-8">
    <div>
        <input type="hidden" name="scope" id="orb-search-scope" value="mundo">
        <label for="orb-search-q">Buscar en la BBC</label>
            <input
                id="orb-search-q"
                type="text"
                autocomplete="off"
                autocorrect="off"
                autocapitalize="off"
                spellcheck="false"
                name="q"
                placeholder="Buscar"
            >
            <button id="orb-search-button" class="orb-search__button">Buscar en la BBC</button>
            <input type="hidden" name="suggid" id="orb-search-suggid"/>
    </div>
</form>


 </div>  </div> <div id="orb-panels"  class="orb-ws-panels"  > <script type="text/template" id="orb-panel-template"><![CDATA[ <div id="orb-panel-<%= panelname %>" class="orb-panel" aria-labelledby="orb-nav-<%= panelname %>"> <div class="orb-panel-content b-g-p b-r"> <%= panelcontent %> </div> </div> ]]></script> </div> </div> </header> <!-- Styling hook for shared modules only --> <div id="orb-modules">             
    <div id="site-container">

                <div class="site-brand site-brand--height" role="banner" aria-label="Mundo">
                        <div class="site-brand-inner site-brand-inner--height">
                <div class="navigation navigation--primary">
                    <a href="/mundo" id="brand">
            <svg class="brand__svg" aria-label="BBC Mundo" width="104" height="25">
            <title>BBC Mundo</title>
            <image xlink:href="http://static.bbci.co.uk/news/1.206.01880/img/brand/generated/mundo-light.svg" src="http://static.bbci.co.uk/news/1.206.01880/img/brand/generated/mundo-light.png" width="100%" height="100%"/>
        </svg>
        </a>
                                        <h2 class="navigation__heading off-screen">Mundo navigation</h2>
                    <a href="#core-navigation" class="navigation__section navigation__section--core" data-event="header">
                        <span class="off-screen">Secciones</span>
                    </a>
                                    </div>
            </div>
                        

<div class="navigation navigation--wide">
    <ul class="navigation-wide-list" role="navigation" aria-label="Mundo" data-panel-id="js-navigation-panel-primary">
                    <li>
                <a href="/mundo" class="navigation-wide-list__link">
                    <span>Noticias</span>
                </a>
                            </li>
                    <li>
                <a href="/mundo/america_latina" class="navigation-wide-list__link">
                    <span>América Latina</span>
                </a>
                            </li>
                    <li>
                <a href="/mundo/internacional" class="navigation-wide-list__link">
                    <span>Internacional</span>
                </a>
                            </li>
                    <li>
                <a href="/mundo/topics/ca170ae3-99c1-48db-9b67-2866f85e7342" class="navigation-wide-list__link">
                    <span>Economía</span>
                </a>
                            </li>
                    <li>
                <a href="/mundo/topics/31684f19-84d6-41f6-b033-7ae08098572a" class="navigation-wide-list__link">
                    <span>Tecnología</span>
                </a>
                            </li>
                    <li>
                <a href="/mundo/topics/0f469e6a-d4a6-46f2-b727-2bd039cb6b53" class="navigation-wide-list__link">
                    <span>Ciencia</span>
                </a>
                            </li>
                    <li>
                <a href="/mundo/topics/c4794229-7f87-43ce-ac0a-6cfcd6d3cef2" class="navigation-wide-list__link">
                    <span>Salud</span>
                </a>
                            </li>
                    <li>
                <a href="/mundo/topics/6a73afa3-ea6b-45c1-80bb-49060b99f864" class="navigation-wide-list__link">
                    <span>Cultura</span>
                </a>
                            </li>
                    <li>
                <a href="/mundo/topics/4063f80f-cccc-44c8-9449-5ca44e4c8592" class="navigation-wide-list__link">
                    <span>Deportes</span>
                </a>
                            </li>
                    <li>
                <a href="/mundo/media/video" class="navigation-wide-list__link">
                    <span>Video</span>
                </a>
                            </li>
                    <li>
                <a href="/mundo/media/photogalleries" class="navigation-wide-list__link">
                    <span>Fotos</span>
                </a>
                            </li>
                    <li>
                <a href="/mundo/noticias-36795069" class="navigation-wide-list__link navigation-wide-list__link--last">
                    <span>Hay Festival</span>
                </a>
                            </li>
            </ul>
</div>

                    </div>
            
    
<div id="bbccom_leaderboard_1_2_3_4" class="bbccom_slot "  aria-hidden="true">
    <div class="bbccom_advert">
        <script type="text/javascript">
            /*<![CDATA[*/
            (function() {
                if (window.bbcdotcom && bbcdotcom.adverts && bbcdotcom.adverts.slotAsync) {
                    bbcdotcom.adverts.slotAsync('leaderboard', [1,2,3,4]);
                }
            })();
            /*]]>*/
        </script>
    </div>
</div>

    
                
         <div id="page" class="configurable index " data-story-id="front_page"> <div id="breaking-news-banner-focus-target" tabindex="-1"></div>                         <div class="page__head">
                                                                            <div class="index-tabs__container">
    <ul id="index-tabs" class="tabs">
        <li class="open top-stories-tab" data-event="topstories">
            <a href="/mundo">Principales noticias</a>
        </li>
        <li class=" top-stories-tab" data-event="mostread">
            <a href="/mundo/popular/read">Lo más visto</a>
        </li>
    </ul>
</div>
                                                                        </div>
             <div role="main"> <div class="container-width-only">       <h1 class="index-title index-title--redundant index-title--front-page" id="comp-index-title" data-index-title-meta="{&quot;id&quot;:&quot;comp-index-title&quot;,&quot;type&quot;:&quot;index-title&quot;,&quot;handler&quot;:&quot;indexTitle&quot;,&quot;deviceGroups&quot;:null,&quot;opts&quot;:{&quot;alwaysVisible&quot;:false,&quot;onFrontPage&quot;:true},&quot;template&quot;:&quot;index-title&quot;}">BBC Mundo Noticias</h1>
 
<div id="bbccom_sponsor_section_1_2_3_4" class="bbccom_slot "  aria-hidden="true">
    <div class="bbccom_advert">
        <script type="text/javascript">
            /*<![CDATA[*/
            (function() {
                if (window.bbcdotcom && bbcdotcom.adverts && bbcdotcom.adverts.slotAsync) {
                    bbcdotcom.adverts.slotAsync('sponsor_section', [1,2,3,4]);
                }
            })();
            /*]]>*/
        </script>
    </div>
</div>
   </div>      <div class="container">       <div class="container--primary-and-secondary-columns column-clearfix">                         <div class="column--primary">
                                                                            

    <div id="comp-top-story-1" class="distinct-component-group container-buzzard">
        
            <h2 class="group-title off-screen ">
    
    Principales noticias
</h2>
<div class="buzzard faux-block-link">
    <div class="buzzard-item" data-entityid="container-top-stories#1">
        <a href="/mundo/noticias-internacional-41030680" class="title-link">
            
            <h3 class="title-link__title">
                
                <span class="title-link__title-text">Qué es la Séptima Flota, la fuerza de guerra naval más grande de EE.UU., y qué hay detrás de los misteriosos accidentes que ha sufrido en los últimos meses</span>
            </h3>
        </a>            <div class="buzzard__image">
                <div class="responsive-image responsive-image--16by9">
                    
                    <img src="https://ichef.bbci.co.uk/news/200/cpsprodpb/A789/production/_97498824_gettyimages-97793105.jpg" class="js-image-replace" alt="El Blue Ridge" width="976" height="549" />
                    
                </div>
            </div>
        <div class="buzzard__body">
                <p class="buzzard__summary">Sus barcos, equipados con tecnología de última generación, han sufrido cuatro choques en el último año. ¿Cómo la flota más grande de EE.UU., la que controla una de las zonas más estratégicas del mundo, se volvió la menos segura de toda la Armada?</p>
            <div class="buzzard__info-list">
                <ul class="mini-info-list">
                    <li class="mini-info-list__item"><div class="date date--v2" data-seconds="1503577934" data-datetime="24 agosto 2017">24 agosto 2017</div></li>
                </ul>
            </div>
        </div>
        <div class="buzzard__links-list">
            <h4 class="off-screen"></h4>
            <ul class="links-list__list">
                <li class="links-list__item"><a href="/mundo/noticias-internacional-40995800" class="links-list__link"> Desaparecidos 10 tripulantes de un destructor lanzamisiles de Estados Unidos que colisionó con un buque petrolero</a></li>
            </ul>
        </div>
        <a href="/mundo/noticias-internacional-41030680" class="faux-block-link__overlay-link" tabindex="-1" aria-hidden="true"> Qué es la Séptima Flota, la fuerza de guerra naval más grande de EE.UU., y qué hay detrás de los misteriosos accidentes que ha sufrido en los últimos meses</a>
    </div>
</div>

        
    </div>

                                                                                            

    <div id="comp-top-story-2" class="distinct-component-group container-dove">
        
            <div class="dove">
        <div class="dove-item faux-block-link" >
            <div class="dove-item__image">
                <div class="responsive-image responsive-image--16by9">
                    
                        <div class="js-delayed-image-load" data-src="https://ichef-1.bbci.co.uk/news/200/cpsprodpb/10F4/production/_97504340_0000.jpg" data-width="976" data-height="549" data-alt="Kim Jong-un inspects a military facility in North Korea"></div>
                        <!--[if lt IE 9]>
                        <img src="https://ichef-1.bbci.co.uk/news/200/cpsprodpb/10F4/production/_97504340_0000.jpg" class="js-image-replace" alt="Kim Jong-un inspects a military facility in North Korea" width="976" height="549" />
                        <![endif]-->
                    
                </div>
            </div>

            <div class="dove-item__body">
                <a href="/mundo/noticias-internacional-41043859" class="title-link">
                    
                    <h3 class="title-link__title">
                        
                        <span class="title-link__title-text">Los detalles de misiles balísticos &quot;secretos&quot; que Corea del Norte reveló &quot;accidentalmente&quot; en una foto</span>
                    </h3>
                </a>                    <p class="dove-item__summary">En una foto de una visita de Kim Jong-un a una academia militar se observan detalles sobre su programa nuclear. Son dos misiles de combustible sólido que, hasta ahora, no han sido probados. Sin embargo, para los especialistas, la gran preocupación no es el armamento que Corea del Norte muestra, sino el que oculta.</p>

                <div class="dove-item__info-list">

                    <ul class="mini-info-list">
                        <li class="mini-info-list__item"><div class="date date--v2" data-seconds="1503597762" data-datetime="24 agosto 2017">24 agosto 2017</div></li>
                    </ul>
                </div>
            </div>

            <div class="dove-item__links-list">
                <h4 class="off-screen"></h4>
                <ul class="links-list__list">
                    <li class="links-list__item"><a href="/mundo/noticias-internacional-40936660" class="links-list__link"> 5 claves para entender lo que realmente busca Corea del Norte con su programa nuclear y su desafío a Estados Unidos</a></li>
                </ul>
            </div>
            <a href="/mundo/noticias-internacional-41043859" class="faux-block-link__overlay-link" tabindex="-1" aria-hidden="true"> Los detalles de misiles balísticos &quot;secretos&quot; que Corea del Norte reveló &quot;accidentalmente&quot; en una foto</a>
        </div>
        <div class="dove-item faux-block-link" >
            <div class="dove-item__image">
                <div class="responsive-image responsive-image--16by9">
                    
                        <div class="js-delayed-image-load" data-src="https://ichef.bbci.co.uk/news/200/cpsprodpb/9B98/production/_97523893_hi041225370.jpg" data-width="976" data-height="549" data-alt="Mark James Asay"></div>
                        <!--[if lt IE 9]>
                        <img src="https://ichef.bbci.co.uk/news/200/cpsprodpb/9B98/production/_97523893_hi041225370.jpg" class="js-image-replace" alt="Mark James Asay" width="976" height="549" />
                        <![endif]-->
                    
                </div>
            </div>

            <div class="dove-item__body">
                <a href="/mundo/noticias-internacional-41044819" class="title-link">
                    
                    <h3 class="title-link__title">
                        
                        <span class="title-link__title-text">La inyección letal experimental y otras dos cosas que hacen inusual la ejecución de un supremacista blanco en Florida</span>
                    </h3>
                </a>                    <p class="dove-item__summary">Aunque más de 1.400 personas fueron ejecutadas en Estados Unidos desde 1976, la de Mark James Asay, antiguo miembro de un grupo supremacista blanco tatuado con una esvástica, supone un punto de inflexión en la historia de la pena capital en el país. Te contamos por qué.</p>

                <div class="dove-item__info-list">

                    <ul class="mini-info-list">
                        <li class="mini-info-list__item"><div class="date date--v2" data-seconds="1503614704" data-datetime="24 agosto 2017">24 agosto 2017</div></li>
                    </ul>
                </div>
            </div>

            <div class="dove-item__links-list">
                <h4 class="off-screen"></h4>
                <ul class="links-list__list">
                    <li class="links-list__item"><a href="http://www.bbc.com/mundo/noticias/2014/07/140725_eeuu_pena_muerte_metodos_en" class="links-list__link"> EE.UU.: ¿existen maneras compasivas de aplicar la pena de muerte?</a></li>
                </ul>
            </div>
            <a href="/mundo/noticias-internacional-41044819" class="faux-block-link__overlay-link" tabindex="-1" aria-hidden="true"> La inyección letal experimental y otras dos cosas que hacen inusual la ejecución de un supremacista blanco en Florida</a>
        </div>
        <div class="dove-item faux-block-link" >
            <div class="dove-item__image">
                <div class="responsive-image responsive-image--16by9">
                    
                        <div class="js-delayed-image-load" data-src="https://ichef.bbci.co.uk/news/200/cpsprodpb/11D2A/production/_97520037_gettyimages-540095924.jpg" data-width="976" data-height="549" data-alt="Una pareja camina por un bosque"></div>
                        <!--[if lt IE 9]>
                        <img src="https://ichef.bbci.co.uk/news/200/cpsprodpb/11D2A/production/_97520037_gettyimages-540095924.jpg" class="js-image-replace" alt="Una pareja camina por un bosque" width="976" height="549" />
                        <![endif]-->
                    
                </div>
            </div>

            <div class="dove-item__body">
                <a href="/mundo/noticias-41038433" class="title-link">
                    
                    <h3 class="title-link__title">
                        
                        <span class="title-link__title-text">5 simples consejos para caminar más todos los días (y así mejorar tu salud)</span>
                    </h3>
                </a>                    <p class="dove-item__summary">Cambiar algunos hábitos de nuestra vida diaria puede ser más fácil de lo que crees y aporta enormes beneficios. Y caminar es una de las actividades más fáciles, populares y baratas. Te explicamos cómo realizar los 10 minutos de caminada rápida que podrían ayudarte a estar más sano.</p>

                <div class="dove-item__info-list">

                    <ul class="mini-info-list">
                        <li class="mini-info-list__item"><div class="date date--v2" data-seconds="1503585548" data-datetime="24 agosto 2017">24 agosto 2017</div></li>
                    </ul>
                </div>
            </div>

            <div class="dove-item__links-list">
                <h4 class="off-screen"></h4>
                <ul class="links-list__list">
                    <li class="links-list__item"><a href="/mundo/deportes-37777095" class="links-list__link"> Los mejores ejercicios para después de una lesión en las piernas</a></li>
                </ul>
            </div>
            <a href="/mundo/noticias-41038433" class="faux-block-link__overlay-link" tabindex="-1" aria-hidden="true"> 5 simples consejos para caminar más todos los días (y así mejorar tu salud)</a>
        </div>
</div>

        
    </div>

                                
<div id="bbccom_mpu_1_2_3" class="bbccom_slot mpu-ad"  aria-hidden="true">
    <div class="bbccom_advert">
        <script type="text/javascript">
            /*<![CDATA[*/
            (function() {
                if (window.bbcdotcom && bbcdotcom.adverts && bbcdotcom.adverts.slotAsync) {
                    bbcdotcom.adverts.slotAsync('mpu', [1,2,3]);
                }
            })();
            /*]]>*/
        </script>
    </div>
</div>
                                                            

    <div id="comp-also-in-news" class="distinct-component-group container-robin">
        
            <div class="robin sparrow-container">
        <div class="robin-item faux-block-link" >
                <div class="robin-item__image">
                    <div class="responsive-image responsive-image--16by9">
                        
                            <div class="js-delayed-image-load" data-src="https://ichef.bbci.co.uk/news/200/cpsprodpb/81DA/production/_97524233_cordobes.png" data-width="976" data-height="549" data-alt="Muhammad Yasin Ahram, en el video difundido por el autodenominado Estado Islámico"></div>
                            <!--[if lt IE 9]>
                            <img src="https://ichef.bbci.co.uk/news/200/cpsprodpb/81DA/production/_97524233_cordobes.png" class="js-image-replace" alt="Muhammad Yasin Ahram, en el video difundido por el autodenominado Estado Islámico" width="976" height="549" />
                            <![endif]-->
                        
                    </div>
                </div>
            <div class="robin-item__body">
                <a href="/mundo/noticias-internacional-41044739" class="title-link">
                    
                    <h3 class="title-link__title">
                        
                        <span class="title-link__title-text">Abu Lais &quot;el Cordobés&quot;, el joven yihadista andaluz que amenaza en video a España en nombre del autodenominado Estado Islámico</span>
                    </h3>
                </a>                <ul class="mini-info-list">
                    <li class="mini-info-list__item"><div class="date date--v2" data-seconds="1503616390" data-datetime="24 agosto 2017">24 agosto 2017</div></li>
                </ul>
            </div>
            <a href="/mundo/noticias-internacional-41044739" class="faux-block-link__overlay-link" tabindex="-1" aria-hidden="true"> Abu Lais &quot;el Cordobés&quot;, el joven yihadista andaluz que amenaza en video a España en nombre del autodenominado Estado Islámico</a>
        </div>
        <div class="robin-item faux-block-link" >
                <div class="robin-item__image">
                    <div class="responsive-image responsive-image--16by9">
                        
                            <div class="js-delayed-image-load" data-src="https://ichef-1.bbci.co.uk/news/200/cpsprodpb/3748/production/_97525141_d5df5b04-67be-4632-9934-239bdf1f787a.jpg" data-width="976" data-height="549" data-alt="Joe Arpaio y Donald Trump"></div>
                            <!--[if lt IE 9]>
                            <img src="https://ichef-1.bbci.co.uk/news/200/cpsprodpb/3748/production/_97525141_d5df5b04-67be-4632-9934-239bdf1f787a.jpg" class="js-image-replace" alt="Joe Arpaio y Donald Trump" width="976" height="549" />
                            <![endif]-->
                        
                    </div>
                </div>
            <div class="robin-item__body">
                <a href="/mundo/noticias-internacional-41045889" class="title-link">
                    
                    <h3 class="title-link__title">
                        
                        <span class="title-link__title-text">¿Donald Trump puede perdonar la condena al polémico exalguacil Joe Arpaio vía Twitter?</span>
                    </h3>
                </a>                <ul class="mini-info-list">
                    <li class="mini-info-list__item"><div class="date date--v2" data-seconds="1503632316" data-datetime="25 agosto 2017">25 agosto 2017</div></li>
                </ul>
            </div>
            <a href="/mundo/noticias-internacional-41045889" class="faux-block-link__overlay-link" tabindex="-1" aria-hidden="true"> ¿Donald Trump puede perdonar la condena al polémico exalguacil Joe Arpaio vía Twitter?</a>
        </div>
        <div class="robin-item faux-block-link" >
                <div class="robin-item__image">
                    <div class="responsive-image responsive-image--16by9">
                        
                            <div class="js-delayed-image-load" data-src="https://ichef-1.bbci.co.uk/news/200/cpsprodpb/17908/production/_97502569_busdelujo.jpg" data-width="976" data-height="549" data-alt="Autobús con cabinas para dormir durante el viaje"></div>
                            <!--[if lt IE 9]>
                            <img src="https://ichef-1.bbci.co.uk/news/200/cpsprodpb/17908/production/_97502569_busdelujo.jpg" class="js-image-replace" alt="Autobús con cabinas para dormir durante el viaje" width="976" height="549" />
                            <![endif]-->
                        
                    </div>
                </div>
            <div class="robin-item__body">
                <a href="/mundo/noticias-41032177" class="title-link">
                    
                    <h3 class="title-link__title">
                        
                        <span class="title-link__title-text">El lujoso autobús que es como un hotel rodante y pretende sustituir los vuelos de media distancia en Estados Unidos</span>
                    </h3>
                </a>                <ul class="mini-info-list">
                    <li class="mini-info-list__item"><div class="date date--v2" data-seconds="1503583839" data-datetime="24 agosto 2017">24 agosto 2017</div></li>
                </ul>
            </div>
            <a href="/mundo/noticias-41032177" class="faux-block-link__overlay-link" tabindex="-1" aria-hidden="true"> El lujoso autobús que es como un hotel rodante y pretende sustituir los vuelos de media distancia en Estados Unidos</a>
        </div>
        <div class="robin-item faux-block-link" >
                <div class="robin-item__image">
                    <div class="responsive-image responsive-image--16by9">
                        
                            <div class="js-delayed-image-load" data-src="https://ichef.bbci.co.uk/news/200/cpsprodpb/4114/production/_97506661_3840.jpg" data-width="976" data-height="549" data-alt="Antares"></div>
                            <!--[if lt IE 9]>
                            <img src="https://ichef.bbci.co.uk/news/200/cpsprodpb/4114/production/_97506661_3840.jpg" class="js-image-replace" alt="Antares" width="976" height="549" />
                            <![endif]-->
                        
                    </div>
                </div>
            <div class="robin-item__body">
                <a href="/mundo/noticias-41037591" class="title-link">
                    
                    <h3 class="title-link__title">
                        
                        <span class="title-link__title-text">La impresionante imagen de Antares, la estrella agonizante que se está convirtiendo en supernova</span>
                    </h3>
                </a>                <ul class="mini-info-list">
                    <li class="mini-info-list__item"><div class="date date--v2" data-seconds="1503583873" data-datetime="24 agosto 2017">24 agosto 2017</div></li>
                </ul>
            </div>
            <a href="/mundo/noticias-41037591" class="faux-block-link__overlay-link" tabindex="-1" aria-hidden="true"> La impresionante imagen de Antares, la estrella agonizante que se está convirtiendo en supernova</a>
        </div>
</div>

        
    </div>

                                                                                            

    <div id="comp-av-carousel-1" class="distinct-component-group container-robin">
        
            <h2 class="group-title ">
    <a href="http://www.bbc.com/mundo/media/video" class="group-title__link">Videos</a>
    
</h2>
<div class="robin sparrow-container">
        <div class="robin-item faux-block-link" >
                <div class="robin-item__image">
                    <div class="responsive-image responsive-image--16by9">
                        <div class="responsive-image__inner-for-label"><!-- closed in responsive-image-end -->
                            <div class="js-delayed-image-load" data-src="https://ichef.bbci.co.uk/news/200/cpsprodpb/ED77/production/_97519706_p05d6xvl.jpg" data-width="976" data-height="549" data-alt="Un grupo de chicas indias que crecieron en el &quot;barrio rojo&quot; de Bombay llevan en escena sus historias en el Festival de teatro de Edimburgo, en Escocia."></div>
                            <!--[if lt IE 9]>
                            <img src="https://ichef.bbci.co.uk/news/200/cpsprodpb/ED77/production/_97519706_p05d6xvl.jpg" class="js-image-replace" alt="Un grupo de chicas indias que crecieron en el &quot;barrio rojo&quot; de Bombay llevan en escena sus historias en el Festival de teatro de Edimburgo, en Escocia." width="976" height="549" />
                            <![endif]-->
                            <div class="responsive-image__media-and-live-label" aria-hidden="true">
                                                             
                            
                                    <span class="badge-icon-only badge-icon-only--video-for-image"><span class="svg-icon svg-icon--video-dark"><span class="off-screen"> Video</span></span></span>
                            
                            
                              
                            
                            
                            <span class="badge-text-only badge-text-only--duration">2:22</span>
 
                            </div>
                        <!-- opened in responsive-image-start --></div>
                    </div>
                </div>
            <div class="robin-item__body">
                <a href="/mundo/media-41041293" class="title-link">
                    <span class="off-screen">Video 2:22</span>
                    <h3 class="title-link__title">
                        
                        <span class="title-link__title-text">&quot;Me violaron a los 10 años pero aprendí a perdonar&quot;: las historias de superación de las hijas de prostitutas del &quot;barrio rojo&quot; de Bombay</span>
                    </h3>
                </a>                <ul class="mini-info-list">
                    <li class="mini-info-list__item"><div class="date date--v2" data-seconds="1503586039" data-datetime="24 agosto 2017">24 agosto 2017</div></li>
                </ul>
            </div>
            <a href="/mundo/media-41041293" class="faux-block-link__overlay-link" tabindex="-1" aria-hidden="true"> &quot;Me violaron a los 10 años pero aprendí a perdonar&quot;: las historias de superación de las hijas de prostitutas del &quot;barrio rojo&quot; de Bombay</a>
        </div>
        <div class="robin-item faux-block-link" >
                <div class="robin-item__image">
                    <div class="responsive-image responsive-image--16by9">
                        <div class="responsive-image__inner-for-label"><!-- closed in responsive-image-end -->
                            <div class="js-delayed-image-load" data-src="https://ichef.bbci.co.uk/news/200/cpsprodpb/4427/production/_97474471_p05d0wp1.jpg" data-width="1024" data-height="576" data-alt="Olajumoke Orisaguna vendía pan en Lagos, la capital de Nigeria, hasta que un día pasando por la calle se encontró en una sesión de fotos para el rapero Tinie Tempah."></div>
                            <!--[if lt IE 9]>
                            <img src="https://ichef.bbci.co.uk/news/200/cpsprodpb/4427/production/_97474471_p05d0wp1.jpg" class="js-image-replace" alt="Olajumoke Orisaguna vendía pan en Lagos, la capital de Nigeria, hasta que un día pasando por la calle se encontró en una sesión de fotos para el rapero Tinie Tempah." width="1024" height="576" />
                            <![endif]-->
                            <div class="responsive-image__media-and-live-label" aria-hidden="true">
                                                             
                            
                                    <span class="badge-icon-only badge-icon-only--video-for-image"><span class="svg-icon svg-icon--video-dark"><span class="off-screen"> Video</span></span></span>
                            
                            
                              
                            
                            
                            <span class="badge-text-only badge-text-only--duration">1:26</span>
 
                            </div>
                        <!-- opened in responsive-image-start --></div>
                    </div>
                </div>
            <div class="robin-item__body">
                <a href="/mundo/media-41012238" class="title-link">
                    <span class="off-screen">Video 1:26</span>
                    <h3 class="title-link__title">
                        
                        <span class="title-link__title-text">La vendedora ambulante que se convirtió en modelo famosa al salir por casualidad en una foto con el rapero Tinie Tempah</span>
                    </h3>
                </a>                <ul class="mini-info-list">
                    <li class="mini-info-list__item"><div class="date date--v2" data-seconds="1503398987" data-datetime="22 agosto 2017">22 agosto 2017</div></li>
                </ul>
            </div>
            <a href="/mundo/media-41012238" class="faux-block-link__overlay-link" tabindex="-1" aria-hidden="true"> La vendedora ambulante que se convirtió en modelo famosa al salir por casualidad en una foto con el rapero Tinie Tempah</a>
        </div>
</div>

        
    </div>

                                                                                            

    <div id="comp-special-event-news-1" class="distinct-component-group container-budgie">
        
            <div class="budgie sparrow-container">
    <div class="budgie-item faux-block-link" >
            <div class="budgie__image">
                <div class="responsive-image responsive-image--16by9">
                    
                        <div class="js-delayed-image-load" data-src="https://ichef-1.bbci.co.uk/news/200/cpsprodpb/A117/production/_97493214_r.jpg" data-width="976" data-height="549" data-alt="Raqqa"></div>
                        <!--[if lt IE 9]>
                        <img src="https://ichef-1.bbci.co.uk/news/200/cpsprodpb/A117/production/_97493214_r.jpg" class="js-image-replace" alt="Raqqa" width="976" height="549" />
                        <![endif]-->
                    
                </div>
            </div>

        <div class="budgie__body">
            <a href="/mundo/noticias-internacional-41022937" class="title-link">
                
                <h3 class="title-link__title">
                    
                    <span class="title-link__title-text">“No puede haber un peor sitio en la Tierra que Raqqa”</span>
                </h3>
            </a>                <p class="budgie__summary">     </p>
            <div class="budgie__info">

                <ul class="mini-info-list">
                    <li class="mini-info-list__item"><div class="date date--v2" data-seconds="1503550913" data-datetime="24 agosto 2017">24 agosto 2017</div></li>
                </ul>
            </div>
        </div>

        <a href="/mundo/noticias-internacional-41022937" class="faux-block-link__overlay-link" tabindex="-1" aria-hidden="true"> “No puede haber un peor sitio en la Tierra que Raqqa”</a>
    </div>
</div>

        
    </div>

                                                                                            

    <div id="comp-special-features-1" class="distinct-component-group container-skylark skylark-no-padding">
        
            <h2 class="group-title ">
    
    Destacamos
</h2>
  <div class="skylark faux-block-link">
    <div class="skylark-item" >
            <div class="skylark__image">
                <div class="responsive-image responsive-image--16by9">
                    
                        <div class="js-delayed-image-load" data-src="https://ichef-1.bbci.co.uk/news/200/cpsprodpb/05DC/production/_97500510_gettyimages-835086044.jpg" data-width="976" data-height="549" data-alt="Una agente de los Mossos d'Esquadra, junto a bombonas de butano almacenadas"></div>
                        <!--[if lt IE 9]>
                        <img src="https://ichef-1.bbci.co.uk/news/200/cpsprodpb/05DC/production/_97500510_gettyimages-835086044.jpg" class="js-image-replace" alt="Una agente de los Mossos d'Esquadra, junto a bombonas de butano almacenadas" width="976" height="549" />
                        <![endif]-->
                    
                </div>
            </div>
        <a href="/mundo/noticias-internacional-41031915" class="title-link">
            
            <h3 class="title-link__title">
                
                <span class="title-link__title-text">Qué es la &quot;madre de Satán&quot;, el mortífero explosivo casero con el que los yihadistas querían atentar contra importantes monumentos de Barcelona</span>
            </h3>
        </a>        <div class="skylark__body">
                <p class="skylark__summary">  </p>
            <div class="skylark__info-list">
                <ul class="mini-info-list">
                    <li class="mini-info-list__item"><div class="date date--v2" data-seconds="1503519833" data-datetime="23 agosto 2017">23 agosto 2017</div></li>
                </ul>
            </div>
        </div>
        <a href="/mundo/noticias-internacional-41031915" class="faux-block-link__overlay-link" tabindex="-1" aria-hidden="true"> Qué es la &quot;madre de Satán&quot;, el mortífero explosivo casero con el que los yihadistas querían atentar contra importantes monumentos de Barcelona</a>
    </div>
  </div>

        
    </div>

                                                                                            

    <div id="comp-special-event-vj-overflow" class="distinct-component-group container-budgie">
        
            <div class="budgie sparrow-container">
    <div class="budgie-item faux-block-link" >
            <div class="budgie__image">
                <div class="responsive-image responsive-image--16by9">
                    
                        <div class="js-delayed-image-load" data-src="https://ichef.bbci.co.uk/news/200/cpsprodpb/90F6/production/_97501173_mediaitem97501169.jpg" data-width="640" data-height="360" data-alt="Harvey"></div>
                        <!--[if lt IE 9]>
                        <img src="https://ichef.bbci.co.uk/news/200/cpsprodpb/90F6/production/_97501173_mediaitem97501169.jpg" class="js-image-replace" alt="Harvey" width="640" height="360" />
                        <![endif]-->
                    
                </div>
            </div>

        <div class="budgie__body">
            <a href="/mundo/noticias-internacional-41043349" class="title-link">
                
                <h3 class="title-link__title">
                    
                    <span class="title-link__title-text">Alerta en Texas ante la llegada de Harvey que se espera toque tierra como un huracán capaz de provocar muertes e inundaciones devastadoras</span>
                </h3>
            </a>                <p class="budgie__summary">  </p>
            <div class="budgie__info">

                <ul class="mini-info-list">
                    <li class="mini-info-list__item"><div class="date date--v2" data-seconds="1503619887" data-datetime="25 agosto 2017">25 agosto 2017</div></li>
                </ul>
            </div>
        </div>

        <a href="/mundo/noticias-internacional-41043349" class="faux-block-link__overlay-link" tabindex="-1" aria-hidden="true"> Alerta en Texas ante la llegada de Harvey que se espera toque tierra como un huracán capaz de provocar muertes e inundaciones devastadoras</a>
    </div>
    <div class="budgie-item faux-block-link" >
            <div class="budgie__image">
                <div class="responsive-image responsive-image--16by9">
                    
                        <div class="js-delayed-image-load" data-src="https://ichef.bbci.co.uk/news/200/cpsprodpb/17868/production/_97506369_gettyimages-837964410.jpg" data-width="976" data-height="549" data-alt="Galaxy Note 8"></div>
                        <!--[if lt IE 9]>
                        <img src="https://ichef.bbci.co.uk/news/200/cpsprodpb/17868/production/_97506369_gettyimages-837964410.jpg" class="js-image-replace" alt="Galaxy Note 8" width="976" height="549" />
                        <![endif]-->
                    
                </div>
            </div>

        <div class="budgie__body">
            <a href="/mundo/noticias-41037171" class="title-link">
                
                <h3 class="title-link__title">
                    
                    <span class="title-link__title-text">Cómo es Galaxy Note 8, el teléfono con el que Samsung espera hacer olvidar el mayor fiasco de su historia</span>
                </h3>
            </a>                <p class="budgie__summary">    </p>
            <div class="budgie__info">

                <ul class="mini-info-list">
                    <li class="mini-info-list__item"><div class="date date--v2" data-seconds="1503576813" data-datetime="24 agosto 2017">24 agosto 2017</div></li>
                </ul>
            </div>
        </div>

        <a href="/mundo/noticias-41037171" class="faux-block-link__overlay-link" tabindex="-1" aria-hidden="true"> Cómo es Galaxy Note 8, el teléfono con el que Samsung espera hacer olvidar el mayor fiasco de su historia</a>
    </div>
    <div class="budgie-item faux-block-link" >
            <div class="budgie__image">
                <div class="responsive-image responsive-image--16by9">
                    
                        <div class="js-delayed-image-load" data-src="https://ichef.bbci.co.uk/news/200/cpsprodpb/2A8B/production/_97519801_de27.jpg" data-width="976" data-height="549" data-alt="Mavis Wanczyk"></div>
                        <!--[if lt IE 9]>
                        <img src="https://ichef.bbci.co.uk/news/200/cpsprodpb/2A8B/production/_97519801_de27.jpg" class="js-image-replace" alt="Mavis Wanczyk" width="976" height="549" />
                        <![endif]-->
                    
                </div>
            </div>

        <div class="budgie__body">
            <a href="/mundo/noticias-41034771" class="title-link">
                
                <h3 class="title-link__title">
                    
                    <span class="title-link__title-text">Esta es Mavis Wanczyk, la mujer que ganó US$758 millones en la Powerball, el mayor premio individual en la historia de la lotería en EE.UU.</span>
                </h3>
            </a>                <p class="budgie__summary">  </p>
            <div class="budgie__info">

                <ul class="mini-info-list">
                    <li class="mini-info-list__item"><div class="date date--v2" data-seconds="1503600489" data-datetime="24 agosto 2017">24 agosto 2017</div></li>
                </ul>
            </div>
        </div>

        <a href="/mundo/noticias-41034771" class="faux-block-link__overlay-link" tabindex="-1" aria-hidden="true"> Esta es Mavis Wanczyk, la mujer que ganó US$758 millones en la Powerball, el mayor premio individual en la historia de la lotería en EE.UU.</a>
    </div>
    <div class="budgie-item faux-block-link" >
            <div class="budgie__image">
                <div class="responsive-image responsive-image--16by9">
                    
                        <div class="js-delayed-image-load" data-src="https://ichef-1.bbci.co.uk/news/200/cpsprodpb/473F/production/_97493281_gettyimages-161610011.jpg" data-width="976" data-height="549" data-alt="Japoneses celebrando"></div>
                        <!--[if lt IE 9]>
                        <img src="https://ichef-1.bbci.co.uk/news/200/cpsprodpb/473F/production/_97493281_gettyimages-161610011.jpg" class="js-image-replace" alt="Japoneses celebrando" width="976" height="549" />
                        <![endif]-->
                    
                </div>
            </div>

        <div class="budgie__body">
            <a href="/mundo/vert-cap-40964286" class="title-link">
                
                <h3 class="title-link__title">
                    
                    <span class="title-link__title-text">Ikigai: la palabra japonesa que puede tener la clave de la felicidad en la vida y en el trabajo</span>
                </h3>
            </a>                <p class="budgie__summary">  </p>
            <div class="budgie__info">

                <ul class="mini-info-list">
                    <li class="mini-info-list__item"><div class="date date--v2" data-seconds="1503501771" data-datetime="23 agosto 2017">23 agosto 2017</div></li>
                </ul>
            </div>
        </div>

        <a href="/mundo/vert-cap-40964286" class="faux-block-link__overlay-link" tabindex="-1" aria-hidden="true"> Ikigai: la palabra japonesa que puede tener la clave de la felicidad en la vida y en el trabajo</a>
    </div>
    <div class="budgie-item faux-block-link" >
            <div class="budgie__image">
                <div class="responsive-image responsive-image--16by9">
                    
                        <div class="js-delayed-image-load" data-src="https://ichef.bbci.co.uk/news/200/cpsprodpb/3590/production/_97521731_ff5c5639-1468-4e66-9cbd-dde8e5fdbe37.jpg" data-width="976" data-height="549" data-alt="La copa de la Champions League"></div>
                        <!--[if lt IE 9]>
                        <img src="https://ichef.bbci.co.uk/news/200/cpsprodpb/3590/production/_97521731_ff5c5639-1468-4e66-9cbd-dde8e5fdbe37.jpg" class="js-image-replace" alt="La copa de la Champions League" width="976" height="549" />
                        <![endif]-->
                    
                </div>
            </div>

        <div class="budgie__body">
            <a href="/mundo/deportes-41042698" class="title-link">
                
                <h3 class="title-link__title">
                    
                    <span class="title-link__title-text">Barcelona-Juventus / Real Madrid-Dortmund: así quedaron los grupos y partidos de la Champions League 2017/2018</span>
                </h3>
            </a>                <p class="budgie__summary">  </p>
            <div class="budgie__info">

                <ul class="mini-info-list">
                    <li class="mini-info-list__item"><div class="date date--v2" data-seconds="1503594220" data-datetime="24 agosto 2017">24 agosto 2017</div></li>
                </ul>
            </div>
        </div>

        <a href="/mundo/deportes-41042698" class="faux-block-link__overlay-link" tabindex="-1" aria-hidden="true"> Barcelona-Juventus / Real Madrid-Dortmund: así quedaron los grupos y partidos de la Champions League 2017/2018</a>
    </div>
</div>

        
    </div>

                                                                                            

    <div id="comp-digest" class="distinct-component-group container-pukeko">
        
            <h2 class="group-title ">
    
    
</h2>
<div class="pukeko pukeko--0">
        <div class="pukeko-item pukeko-item--stacked pukeko-item--light faux-block-link" >
            <div class="pukeko-item__inner">
                    <div class="pukeko-item__image">
                        <div class="responsive-image responsive-image--16by9">
                            
                                <div class="js-delayed-image-load" data-src="https://ichef.bbci.co.uk/news/200/cpsprodpb/6D12/production/_97522972_ed8c2adc-8389-4ee3-8239-fd89b835940b.jpg" data-width="976" data-height="549" data-alt="Oficina de Conatel"></div>
                                <!--[if lt IE 9]>
                                <img src="https://ichef.bbci.co.uk/news/200/cpsprodpb/6D12/production/_97522972_ed8c2adc-8389-4ee3-8239-fd89b835940b.jpg" class="js-image-replace" alt="Oficina de Conatel" width="976" height="549" />
                                <![endif]-->
                            
                        </div>
                    </div>
                <div class="pukeko-item__body">
                        <span class="off-screen"> </span>
                            <a href="/mundo/america_latina" class="pukeko-item__section">América Latina</a>
                    <a href="/mundo/noticias-america-latina-41045242" class="title-link">
                        
                        <h3 class="title-link__title">
                            
                            <span class="title-link__title-text">El gobierno de Venezuela prohíbe la señal de las colombianas Caracol Televisión y RCN &quot;por llamados al magnicidio&quot;</span>
                        </h3>
                    </a>
                    <a href="/mundo/noticias-america-latina-41045242" class="faux-block-link__overlay-link" tabindex="-1" aria-hidden="true"> El gobierno de Venezuela prohíbe la señal de las colombianas Caracol Televisión y RCN &quot;por llamados al magnicidio&quot;</a>
                    <p class="pukeko-item__summary">La Comisión Nacional de Telecomunicaciones (Conatel), el organismo público que regula las telecomunicaciones, ordenó la salida de los servicios de cable de Caracol TV y RCN alegando que colaboraron a difundir un mensaje que &quot;incitaba al magnicidio&quot; del presidente Nicolás Maduro. Para Juan Manuel Santos, las autoridades venezolanas actúan &quot;cada vez más como una dictadura&quot;.</p>
                </div>
            </div>
        </div>
        <div class="pukeko-item pukeko-item--stacked pukeko-item--light faux-block-link" >
            <div class="pukeko-item__inner">
                    <div class="pukeko-item__image">
                        <div class="responsive-image responsive-image--16by9">
                            
                                <div class="js-delayed-image-load" data-src="https://ichef-1.bbci.co.uk/news/200/cpsprodpb/AC9E/production/_97509144_p01h12j2.jpg" data-width="976" data-height="549" data-alt="Valerie Plame Wilson"></div>
                                <!--[if lt IE 9]>
                                <img src="https://ichef-1.bbci.co.uk/news/200/cpsprodpb/AC9E/production/_97509144_p01h12j2.jpg" class="js-image-replace" alt="Valerie Plame Wilson" width="976" height="549" />
                                <![endif]-->
                            
                        </div>
                    </div>
                <div class="pukeko-item__body">
                        <span class="off-screen"> </span>
                            <a href="/mundo/internacional" class="pukeko-item__section">Internacional</a>
                    <a href="/mundo/noticias-41037179" class="title-link">
                        
                        <h3 class="title-link__title">
                            
                            <span class="title-link__title-text">Quién es la exagente de la CIA Valerie Plame Wilson y por qué quiere comprar Twitter</span>
                        </h3>
                    </a>
                    <a href="/mundo/noticias-41037179" class="faux-block-link__overlay-link" tabindex="-1" aria-hidden="true"> Quién es la exagente de la CIA Valerie Plame Wilson y por qué quiere comprar Twitter</a>
                    <p class="pukeko-item__summary">Trabajó para la agencia de espionaje de EE.UU. durante dos décadas pero en 2005 se vio obligada a renunciar. Ahora, la exoficial está de nuevo en el punto de mira del gobierno: quiere comprar &quot;el megáfono de Donald Trump&quot;. Y pretende hacerlo con el dinero de sus ciudadanos.</p>
                </div>
            </div>
        </div>
        <div class="pukeko-item pukeko-item--stacked pukeko-item--light faux-block-link" >
            <div class="pukeko-item__inner">
                    <div class="pukeko-item__image">
                        <div class="responsive-image responsive-image--16by9">
                            
                                <div class="js-delayed-image-load" data-src="https://ichef.bbci.co.uk/news/200/cpsprodpb/C3D8/production/_97263105_gettyimages-477745710.jpg" data-width="976" data-height="549" data-alt="Cubanas usan su celular en La Habana."></div>
                                <!--[if lt IE 9]>
                                <img src="https://ichef.bbci.co.uk/news/200/cpsprodpb/C3D8/production/_97263105_gettyimages-477745710.jpg" class="js-image-replace" alt="Cubanas usan su celular en La Habana." width="976" height="549" />
                                <![endif]-->
                            
                        </div>
                    </div>
                <div class="pukeko-item__body">
                        <span class="off-screen"> </span>
                            <a href="/mundo/topics/31684f19-84d6-41f6-b033-7ae08098572a" class="pukeko-item__section">Tecnología</a>
                    <a href="/mundo/noticias-america-latina-40868707" class="title-link">
                        
                        <h3 class="title-link__title">
                            
                            <span class="title-link__title-text">IMO, por qué esta poco conocida aplicación es un éxito masivo en Cuba</span>
                        </h3>
                    </a>
                    <a href="/mundo/noticias-america-latina-40868707" class="faux-block-link__overlay-link" tabindex="-1" aria-hidden="true"> IMO, por qué esta poco conocida aplicación es un éxito masivo en Cuba</a>
                    <p class="pukeko-item__summary">No es una exageración. Algunos cubanos lograron ver a sus familiares que viven fuera de la isla después de años gracias a una aplicación de videollamadas. IMO, que puede ocupar 100 veces menos espacio en el celular que Whatsapp, se convirtió desde hace unos años en una sensación en Cuba.</p>
                </div>
            </div>
        </div>
        <div class="pukeko-item pukeko-item--stacked pukeko-item--light faux-block-link" >
            <div class="pukeko-item__inner">
                    <div class="pukeko-item__image">
                        <div class="responsive-image responsive-image--16by9">
                            
                                <div class="js-delayed-image-load" data-src="https://ichef-1.bbci.co.uk/news/200/cpsprodpb/D16F/production/_97251635_mediaitem97251633.jpg" data-width="976" data-height="549" data-alt="Una niña con el brazo enyesado"></div>
                                <!--[if lt IE 9]>
                                <img src="https://ichef-1.bbci.co.uk/news/200/cpsprodpb/D16F/production/_97251635_mediaitem97251633.jpg" class="js-image-replace" alt="Una niña con el brazo enyesado" width="976" height="549" />
                                <![endif]-->
                            
                        </div>
                    </div>
                <div class="pukeko-item__body">
                        <span class="off-screen"> </span>
                            <a href="/mundo/topics/c4794229-7f87-43ce-ac0a-6cfcd6d3cef2" class="pukeko-item__section">Salud</a>
                    <a href="/mundo/vert-fut-40860931" class="title-link">
                        
                        <h3 class="title-link__title">
                            
                            <span class="title-link__title-text">¿Podría el vidrio ser el mejor material para reparar huesos rotos?</span>
                        </h3>
                    </a>
                    <a href="/mundo/vert-fut-40860931" class="faux-block-link__overlay-link" tabindex="-1" aria-hidden="true"> ¿Podría el vidrio ser el mejor material para reparar huesos rotos?</a>
                    <p class="pukeko-item__summary">Puede que no parezca un material obvio, pero doctores en Reino Unido están llegando a la conclusión de que podría ser ideal: puede doblarse, puede rebotar y hasta combatir las infecciones.</p>
                </div>
            </div>
        </div>
        <div class="pukeko-item pukeko-item--stacked pukeko-item--light faux-block-link" >
            <div class="pukeko-item__inner">
                    <div class="pukeko-item__image">
                        <div class="responsive-image responsive-image--16by9">
                            
                                <div class="js-delayed-image-load" data-src="https://ichef.bbci.co.uk/news/200/cpsprodpb/10626/production/_97501176_gettyimages-91246174.jpg" data-width="2048" data-height="1152" data-alt="Amazonía"></div>
                                <!--[if lt IE 9]>
                                <img src="https://ichef.bbci.co.uk/news/200/cpsprodpb/10626/production/_97501176_gettyimages-91246174.jpg" class="js-image-replace" alt="Amazonía" width="2048" height="1152" />
                                <![endif]-->
                            
                        </div>
                    </div>
                <div class="pukeko-item__body">
                        <span class="off-screen"> </span>
                            <a href="/mundo/topics/0f469e6a-d4a6-46f2-b727-2bd039cb6b53" class="pukeko-item__section">Ciencia</a>
                    <a href="/mundo/noticias-america-latina-41041775" class="title-link">
                        
                        <h3 class="title-link__title">
                            
                            <span class="title-link__title-text">&quot;Es el peor ataque a la Amazonía en casi medio siglo&quot;: la polémica apertura a la minería de una valiosa reserva natural de Brasil</span>
                        </h3>
                    </a>
                    <a href="/mundo/noticias-america-latina-41041775" class="faux-block-link__overlay-link" tabindex="-1" aria-hidden="true"> &quot;Es el peor ataque a la Amazonía en casi medio siglo&quot;: la polémica apertura a la minería de una valiosa reserva natural de Brasil</a>
                    <p class="pukeko-item__summary">El gobierno de brasileño liberó para la minería una reserva amazónica rica en oro y cobre, buscando atraer inversiones. Pero sus críticos advierten sobre el riesgo que la medida plantea para el ecosistema y poblaciones indígenas.</p>
                </div>
            </div>
        </div>
        <div class="pukeko-item pukeko-item--stacked pukeko-item--light faux-block-link" >
            <div class="pukeko-item__inner">
                    <div class="pukeko-item__image">
                        <div class="responsive-image responsive-image--16by9">
                            
                                <div class="js-delayed-image-load" data-src="https://ichef-1.bbci.co.uk/news/200/cpsprodpb/3897/production/_97478441_gettyimages-830687682.jpg" data-width="976" data-height="549" data-alt="Peter Madsen"></div>
                                <!--[if lt IE 9]>
                                <img src="https://ichef-1.bbci.co.uk/news/200/cpsprodpb/3897/production/_97478441_gettyimages-830687682.jpg" class="js-image-replace" alt="Peter Madsen" width="976" height="549" />
                                <![endif]-->
                            
                        </div>
                    </div>
                <div class="pukeko-item__body">
                        <span class="off-screen"> </span>
                            <a href="/mundo/topics/6a73afa3-ea6b-45c1-80bb-49060b99f864" class="pukeko-item__section">Sociedad y Cultura</a>
                    <a href="/mundo/noticias-internacional-41032097" class="title-link">
                        
                        <h3 class="title-link__title">
                            
                            <span class="title-link__title-text">Quién es Peter Madsen, el inventor al que acusarán del asesinato de Kim Wall, la periodista sueca cuyo torso apareció mutilado en Dinamarca</span>
                        </h3>
                    </a>
                    <a href="/mundo/noticias-internacional-41032097" class="faux-block-link__overlay-link" tabindex="-1" aria-hidden="true"> Quién es Peter Madsen, el inventor al que acusarán del asesinato de Kim Wall, la periodista sueca cuyo torso apareció mutilado en Dinamarca</a>
                    <p class="pukeko-item__summary">Peter Madsen es conocido en Dinamarca por la construcción de un submarino y sus proyectos para lanzar cohetes al espacio. Se encuentra detenido y la fiscalía danesa anunció que lo acusará del asesinato de la periodista sueca Kim Wall, quien estaba haciendo un reportaje sobre la vida del inventor.</p>
                </div>
            </div>
        </div>
        <div class="pukeko-item pukeko-item--stacked pukeko-item--light faux-block-link" >
            <div class="pukeko-item__inner">
                    <div class="pukeko-item__image">
                        <div class="responsive-image responsive-image--16by9">
                            
                                <div class="js-delayed-image-load" data-src="https://ichef-1.bbci.co.uk/news/200/cpsprodpb/B95E/production/_97445474_40984751.jpg" data-width="976" data-height="549" data-alt="Guadalajara es famosa por la música de los mariachis."></div>
                                <!--[if lt IE 9]>
                                <img src="https://ichef-1.bbci.co.uk/news/200/cpsprodpb/B95E/production/_97445474_40984751.jpg" class="js-image-replace" alt="Guadalajara es famosa por la música de los mariachis." width="976" height="549" />
                                <![endif]-->
                            
                        </div>
                    </div>
                <div class="pukeko-item__body">
                        <span class="off-screen"> </span>
                            <a href="/mundo/topics/ca170ae3-99c1-48db-9b67-2866f85e7342" class="pukeko-item__section">Economía</a>
                    <a href="/mundo/noticias-america-latina-40984751" class="title-link">
                        
                        <h3 class="title-link__title">
                            
                            <span class="title-link__title-text">¿Por qué Guadalajara es tan atractiva para el lavado de dinero del narcotráfico en México?</span>
                        </h3>
                    </a>
                    <a href="/mundo/noticias-america-latina-40984751" class="faux-block-link__overlay-link" tabindex="-1" aria-hidden="true"> ¿Por qué Guadalajara es tan atractiva para el lavado de dinero del narcotráfico en México?</a>
                    <p class="pukeko-item__summary">Guadalajara, en el occidente de México, es una de las ciudades preferidas por los carteles de narcotráfico para lavar su dinero. Hay razones económicas pero también una larga historia de convivencia con la sociedad.</p>
                </div>
            </div>
        </div>
        <div class="pukeko-item pukeko-item--stacked pukeko-item--light faux-block-link" >
            <div class="pukeko-item__inner">
                    <div class="pukeko-item__image">
                        <div class="responsive-image responsive-image--16by9">
                            
                                <div class="js-delayed-image-load" data-src="https://ichef.bbci.co.uk/news/200/cpsprodpb/7DB3/production/_97497123_interactive.jpg" data-width="976" data-height="549" data-alt="Gorilla"></div>
                                <!--[if lt IE 9]>
                                <img src="https://ichef.bbci.co.uk/news/200/cpsprodpb/7DB3/production/_97497123_interactive.jpg" class="js-image-replace" alt="Gorilla" width="976" height="549" />
                                <![endif]-->
                            
                        </div>
                    </div>
                <div class="pukeko-item__body">
                        <span class="off-screen"> </span>
                            <a href="/mundo/deportes" class="pukeko-item__section">Deportes</a>
                    <a href="/mundo/deportes-41027564" class="title-link">
                        
                        <h3 class="title-link__title">
                            
                            <span class="title-link__title-text">46 goles en tres días y campeón entre 7 millones: los impresionantes números de Spencer Ealing, el mejor jugador de FIFA 17 del mundo</span>
                        </h3>
                    </a>
                    <a href="/mundo/deportes-41027564" class="faux-block-link__overlay-link" tabindex="-1" aria-hidden="true"> 46 goles en tres días y campeón entre 7 millones: los impresionantes números de Spencer Ealing, el mejor jugador de FIFA 17 del mundo</a>
                    <p class="pukeko-item__summary">Spencer &quot;Gorilla&quot; Ealing, de Reino Unido, se coronó campeón del Mundial Interactivo de la FIFA que se disputó en Londres después de superar varias rondas de clasificación. El trofeo se lo entregó Rudd Gullit.</p>
                </div>
            </div>
        </div>
</div>

        
    </div>

                                                                                            

    <div id="comp-special-features-2" class="distinct-component-group container-skylark skylark-no-padding">
        
            <h2 class="group-title ">
    
    Destacamos
</h2>
  <div class="skylark faux-block-link">
    <div class="skylark-item" >
            <div class="skylark__image">
                <div class="responsive-image responsive-image--16by9">
                    
                        <div class="js-delayed-image-load" data-src="https://ichef.bbci.co.uk/news/200/cpsprodpb/36FE/production/_97487041_paramount.png" data-width="976" data-height="549" data-alt="Película ¿Y dónde está el piloto? (1980)"></div>
                        <!--[if lt IE 9]>
                        <img src="https://ichef.bbci.co.uk/news/200/cpsprodpb/36FE/production/_97487041_paramount.png" class="js-image-replace" alt="Película ¿Y dónde está el piloto? (1980)" width="976" height="549" />
                        <![endif]-->
                    
                </div>
            </div>
        <a href="/mundo/noticias-41017953" class="title-link">
            
            <h3 class="title-link__title">
                
                <span class="title-link__title-text">Estas son las 25 mejores comedias del cine de todos los tiempos para los críticos ¿Están tus favoritas?</span>
            </h3>
        </a>        <div class="skylark__body">
                <p class="skylark__summary">  </p>
            <div class="skylark__info-list">
                <ul class="mini-info-list">
                    <li class="mini-info-list__item"><div class="date date--v2" data-seconds="1503450645" data-datetime="23 agosto 2017">23 agosto 2017</div></li>
                </ul>
            </div>
        </div>
        <a href="/mundo/noticias-41017953" class="faux-block-link__overlay-link" tabindex="-1" aria-hidden="true"> Estas son las 25 mejores comedias del cine de todos los tiempos para los críticos ¿Están tus favoritas?</a>
    </div>
  </div>

        
    </div>

                                                                                            

    <div id="comp-learning-english-1" class="distinct-component-group container-budgie">
        
            <h2 class="group-title ">
    <a href="http://www.bbc.com/mundo/aprenda_ingles" class="group-title__link">Aprende inglés</a>
    
</h2>
<div class="budgie sparrow-container">
    <div class="budgie-item faux-block-link" >
            <div class="budgie__image">
                <div class="responsive-image responsive-image--16by9">
                    <div class="responsive-image__inner-for-label"><!-- closed in responsive-image-end -->
                        <div class="js-delayed-image-load" data-src="https://ichef-1.bbci.co.uk/news/200/cpsprodpb/DBE2/production/_97109265_p059wsyz.jpg" data-width="1024" data-height="575" data-alt="Ciudad"></div>
                        <!--[if lt IE 9]>
                        <img src="https://ichef-1.bbci.co.uk/news/200/cpsprodpb/DBE2/production/_97109265_p059wsyz.jpg" class="js-image-replace" alt="Ciudad" width="1024" height="575" />
                        <![endif]-->
                        <div class="responsive-image__media-and-live-label" aria-hidden="true">
                                                     
                        
                                <span class="badge-icon-only badge-icon-only--video-for-image"><span class="svg-icon svg-icon--video-dark"><span class="off-screen"> Video</span></span></span>
                        
                        
                          
                        
                        
                        <span class="badge-text-only badge-text-only--duration">3:55</span>
 
                        </div>
                    <!-- opened in responsive-image-start --></div>
                </div>
            </div>

        <div class="budgie__body">
            <a href="/mundo/aprenda-ingles-40751739" class="title-link">
                <span class="off-screen">Video 3:55</span>
                <h3 class="title-link__title">
                    
                    <span class="title-link__title-text">Combatiendo la división étnica en la educación</span>
                </h3>
            </a>                <p class="budgie__summary">En esta nueva serie, los periodistas de la BBC te ayudan a practicar inglés con los titulares de las noticias de la semana. Mira el video y aprende nuevo vocabulario.</p>
            <div class="budgie__info">

                <ul class="mini-info-list">
                    <li class="mini-info-list__item"><div class="date date--v2" data-seconds="1501778168" data-datetime="3 agosto 2017">3 agosto 2017</div></li>
                </ul>
            </div>
        </div>

        <a href="/mundo/aprenda-ingles-40751739" class="faux-block-link__overlay-link" tabindex="-1" aria-hidden="true"> Combatiendo la división étnica en la educación</a>
    </div>
</div>

        
    </div>

                                                                        </div>
                                     <div class="column--secondary">
                                                                            
<div class="features-and-analysis" id="comp-features-and-analysis" >
    <h2 class="features-and-analysis__title">
        
        Más noticias
    </h2>
    <div class="features-and-analysis__stories promo-unit-spacer">
        
        <div class="features-and-analysis__story"  data-entityid="features-and-analysis#1">
            <a href="/mundo/noticias-internacional-40959583" class="bold-image-promo">
                <div class="bold-image-promo__image">
                            <div class="responsive-image responsive-image--16by9">
                                
                                    <div class="js-delayed-image-load" data-src="https://ichef-1.bbci.co.uk/news/304/cpsprodpb/24C9/production/_97471490_4361753f-1e3c-436a-8984-f48a5009ae8b.jpg" data-width="976" data-height="549" data-alt="Suki en el salón de clases"></div>
                                    <!--[if lt IE 9]>
                                    <img src="https://ichef-1.bbci.co.uk/news/304/cpsprodpb/24C9/production/_97471490_4361753f-1e3c-436a-8984-f48a5009ae8b.jpg" class="js-image-replace" alt="Suki en el salón de clases" width="976" height="549" />
                                    <![endif]-->
                                
                            </div>
                </div>
                <h3 class="bold-image-promo__title">&quot;Viví todo el tiempo aterrorizada. La realidad es peor de lo que imaginas&quot;: la profesora que pasó seis meses encubierta en Corea del Norte</h3>
                
            </a>
        </div>
        
<div id="bbccom_mpu_4" class="bbccom_slot mpu-ad"  aria-hidden="true">
    <div class="bbccom_advert">
        <script type="text/javascript">
            /*<![CDATA[*/
            (function() {
                if (window.bbcdotcom && bbcdotcom.adverts && bbcdotcom.adverts.slotAsync) {
                    bbcdotcom.adverts.slotAsync('mpu', [4]);
                }
            })();
            /*]]>*/
        </script>
    </div>
</div>

        
        <div class="features-and-analysis__story"  data-entityid="features-and-analysis#2">
            <a href="/mundo/41020293" class="bold-image-promo">
                <div class="bold-image-promo__image">
                            <div class="responsive-image responsive-image--16by9">
                                
                                    <div class="js-delayed-image-load" data-src="https://ichef.bbci.co.uk/news/304/cpsprodpb/1629A/production/_97487709_1ab56aa6-8924-45f3-b539-f7845d9b3c8a.jpg" data-width="976" data-height="549" data-alt="Kim Wall"></div>
                                    <!--[if lt IE 9]>
                                    <img src="https://ichef.bbci.co.uk/news/304/cpsprodpb/1629A/production/_97487709_1ab56aa6-8924-45f3-b539-f7845d9b3c8a.jpg" class="js-image-replace" alt="Kim Wall" width="976" height="549" />
                                    <![endif]-->
                                
                            </div>
                </div>
                <h3 class="bold-image-promo__title">El torso mutilado hallado en el Báltico que confirma la muerte de la periodista Kim Wall, “el asesinato más espectacular en la historia de Dinamarca”</h3>
                
            </a>
        </div>
        
        
        <div class="features-and-analysis__story"  data-entityid="features-and-analysis#3">
            <a href="/mundo/noticias-internacional-41032768" class="bold-image-promo">
                <div class="bold-image-promo__image">
                            <div class="responsive-image responsive-image--16by9">
                                
                                    <div class="js-delayed-image-load" data-src="https://ichef.bbci.co.uk/news/304/cpsprodpb/76CA/production/_97501403_hi037042671.jpg" data-width="976" data-height="549" data-alt="Isabel dos Santos ataviada con una gorra con la bandera del MPLA"></div>
                                    <!--[if lt IE 9]>
                                    <img src="https://ichef.bbci.co.uk/news/304/cpsprodpb/76CA/production/_97501403_hi037042671.jpg" class="js-image-replace" alt="Isabel dos Santos ataviada con una gorra con la bandera del MPLA" width="976" height="549" />
                                    <![endif]-->
                                
                            </div>
                </div>
                <h3 class="bold-image-promo__title">Isabel dos Santos, la mujer más rica de África e hija del hombre que gobernó Angola durante 38 años</h3>
                
            </a>
        </div>
        
        
        <div class="features-and-analysis__story"  data-entityid="features-and-analysis#4">
            <a href="/mundo/noticias-america-latina-40971073" class="bold-image-promo">
                <div class="bold-image-promo__image">
                            <div class="responsive-image responsive-image--16by9">
                                
                                    <div class="js-delayed-image-load" data-src="https://ichef.bbci.co.uk/news/304/cpsprodpb/154C7/production/_97493278_gettyimages-621151936.jpg" data-width="976" data-height="549" data-alt="Protesta argentina"></div>
                                    <!--[if lt IE 9]>
                                    <img src="https://ichef.bbci.co.uk/news/304/cpsprodpb/154C7/production/_97493278_gettyimages-621151936.jpg" class="js-image-replace" alt="Protesta argentina" width="976" height="549" />
                                    <![endif]-->
                                
                            </div>
                </div>
                <h3 class="bold-image-promo__title">&quot;¡Esto es un quilombo!&quot;: por qué los argentinos protestan y se quejan tanto</h3>
                
            </a>
        </div>
        
        
        <div class="features-and-analysis__story"  data-entityid="features-and-analysis#5">
            <a href="/mundo/noticias-41024367" class="bold-image-promo">
                <div class="bold-image-promo__image">
                            <div class="responsive-image responsive-image--16by9">
                                
                                    <div class="js-delayed-image-load" data-src="https://ichef.bbci.co.uk/news/304/cpsprodpb/CED5/production/_97494925_roblox_pizzadelivery.jpg" data-width="976" data-height="549" data-alt="Roblox"></div>
                                    <!--[if lt IE 9]>
                                    <img src="https://ichef.bbci.co.uk/news/304/cpsprodpb/CED5/production/_97494925_roblox_pizzadelivery.jpg" class="js-image-replace" alt="Roblox" width="976" height="549" />
                                    <![endif]-->
                                
                            </div>
                </div>
                <h3 class="bold-image-promo__title">Roblox, la plataforma de juegos con la que algunos adolescentes están ganando millones de dólares</h3>
                
            </a>
        </div>
        
        
        <div class="features-and-analysis__story"  data-entityid="features-and-analysis#6">
            <a href="/mundo/noticias-40995806" class="bold-image-promo">
                <div class="bold-image-promo__image">
                            <div class="responsive-image responsive-image--16by9">
                                
                                    <div class="js-delayed-image-load" data-src="https://ichef.bbci.co.uk/news/304/cpsprodpb/1F5B/production/_97472080_flecha-sin.jpg" data-width="976" data-height="549" data-alt="Flecha señalando la Estación Espacial Internacional."></div>
                                    <!--[if lt IE 9]>
                                    <img src="https://ichef.bbci.co.uk/news/304/cpsprodpb/1F5B/production/_97472080_flecha-sin.jpg" class="js-image-replace" alt="Flecha señalando la Estación Espacial Internacional." width="976" height="549" />
                                    <![endif]-->
                                
                            </div>
                </div>
                <h3 class="bold-image-promo__title">4 hechos curiosos que sucedieron durante el eclipse solar</h3>
                
            </a>
        </div>
        
    </div>
</div>
                                
<div id="bbccom_mpu_4" class="bbccom_slot mpu-ad"  aria-hidden="true">
    <div class="bbccom_advert">
        <script type="text/javascript">
            /*<![CDATA[*/
            (function() {
                if (window.bbcdotcom && bbcdotcom.adverts && bbcdotcom.adverts.slotAsync) {
                    bbcdotcom.adverts.slotAsync('mpu', [4]);
                }
            })();
            /*]]>*/
        </script>
    </div>
</div>
                                                                    <div id=comp-most-popular
            class="hidden"
            >
        </div>                                                                                            

    <div id="comp-cojo-1" class="distinct-component-group container-coot group-title-with-background">
        
            <h2 class="group-title ">
    
    Academia BBC
</h2>
<ul class="coot">
        <li class="coot__image-item faux-block-link">
                <div class="coot__image-item-image">
                    <div class="responsive-image responsive-image--16by9">
                        
                            <div class="js-delayed-image-load" data-src="https://ichef.bbci.co.uk/news/200/cpsprodpb/22CA/production/_95160980_aca.jpg" data-width="976" data-height="549" data-alt="Periodistas de BBC Mundo"></div>
                            <!--[if lt IE 9]>
                            <img src="https://ichef.bbci.co.uk/news/200/cpsprodpb/22CA/production/_95160980_aca.jpg" class="js-image-replace" alt="Periodistas de BBC Mundo" width="976" height="549" />
                            <![endif]-->
                        
                    </div>
                </div>

            <a href="http://www.bbc.co.uk/academy/beta/es/" class="title-link">
                
                <span class="title-link__title">
                    
                    <span class="title-link__title-text">Información útil para hacer periodismo digital</span>
                </span>
            </a>

            <a href="http://www.bbc.co.uk/academy/beta/es/" class="faux-block-link__overlay-link" tabindex="-1" aria-hidden="true"> Información útil para hacer periodismo digital</a>
        </li>
</ul>

        
    </div>

                                                                                                    <div id=comp-follow-us
            class="hidden"
            >
        </div>                                                                                            

    <div id="comp-useful-links" class="distinct-component-group container-warbler">
        
            <h2 class="group-title ">
    <a href="http://www.bbc.com/mundo/institucional/2013/05/000000_partners_bbcmundo" class="group-title__link">Nuestros socios</a>
    
</h2>
<div class="warbler">
    <a href="http://www.bbc.com/mundo/institucional/2013/05/000000_partners_bbcmundo" class="warbler__link"  >
        
        <h3 class="warbler__link-heading">Socios comerciales de BBC Mundo</h3></a>
</div>

        
    </div>

                                
<div id="bbccom_adsense_1_2_3_4" class="bbccom_slot adsense-ad"  aria-hidden="true">
    <div class="bbccom_advert">
        <script type="text/javascript">
            /*<![CDATA[*/
            (function() {
                if (window.bbcdotcom && bbcdotcom.adverts && bbcdotcom.adverts.slotAsync) {
                    bbcdotcom.adverts.slotAsync('adsense', [1,2,3,4]);
                }
            })();
            /*]]>*/
        </script>
    </div>
</div>
                                        </div>
             </div>                          <div class="column--single-bottom">
                                                                            

    <div id="comp-picture-gallery-1" class="distinct-component-group container-parakeet">
        
            <h2 class="group-title ">
    <a href="http://www.bbc.com/mundo/media/photogalleries" class="group-title__link">En fotos</a>
    
</h2>
<div class="parakeet parakeet--5">
    <div class="parakeet-lead-item faux-block-link" >
            <div class="parakeet-lead-item__image">
                <div class="responsive-image responsive-image--16by9">
                    <div class="js-delayed-image-load" data-src="https://ichef.bbci.co.uk/news/200/cpsprodpb/18217/production/_97493889__97486389_petreuters2.jpg" data-width="976" data-height="549" data-alt="Perro"></div>
                        <!--[if lt IE 9]>
                        <img src="https://ichef.bbci.co.uk/news/200/cpsprodpb/18217/production/_97493889__97486389_petreuters2.jpg" class="js-image-replace" alt="Perro" width="976" height="549" />
                        <![endif]-->
                </div>            </div>

        <div class="parakeet-lead-item__body-container">
            <div class="parakeet-lead-item__body">
                <a href="/mundo/noticias-41024862" class="title-link">
                    
                    <h3 class="title-link__title">
                        <span class="icon-new icon-new--camera"></span>
                        <span class="title-link__title-text">Las extravagantes imágenes de perros y gatos en sesiones de acupuntura</span>
                    </h3>
                </a>                    <p class="parakeet-lead-item__summary">Esta terapia tradicional china está ganando cada vez más adeptos entre los dueños de mascotas, que aseguran que el método ayuda a los animales que sufren males y dolores crónicos.</p>
            </div>
        </div>

        <a href="/mundo/noticias-41024862" class="faux-block-link__overlay-link" tabindex="-1" aria-hidden="true"> Las extravagantes imágenes de perros y gatos en sesiones de acupuntura</a>
    </div>

    <div class="parakeet-item-container">
        <div class="parakeet-item faux-block-link" >
                <div class="parakeet-item__image">
                    <div class="responsive-image responsive-image--16by9">
                        
                            <div class="js-delayed-image-load" data-src="https://ichef-1.bbci.co.uk/news/200/cpsprodpb/441E/production/_97483471_9ad5b93d-1033-4965-a249-cff8f99f05c1.jpg" data-width="976" data-height="549" data-alt="Una imagen del eclipse solar se proyecta sobre una mano en Ensenada, Baja California, México, 21 de agosto de 2017"></div>
                            <!--[if lt IE 9]>
                            <img src="https://ichef-1.bbci.co.uk/news/200/cpsprodpb/441E/production/_97483471_9ad5b93d-1033-4965-a249-cff8f99f05c1.jpg" class="js-image-replace" alt="Una imagen del eclipse solar se proyecta sobre una mano en Ensenada, Baja California, México, 21 de agosto de 2017" width="976" height="549" />
                            <![endif]-->
                        
                    </div>
                </div>

            <div class="parakeet-item__body">
                <a href="/mundo/noticias-internacional-41004659" class="title-link">
                    
                    <h3 class="title-link__title">
                        
                        <span class="title-link__title-text">Las espectaculares imágenes que dejó el eclipse solar total que cruzó a Estados Unidos de extremo a extremo</span>
                    </h3>
                </a>                    <p class="parakeet-item__summary">  </p>
            </div>

            <a href="/mundo/noticias-internacional-41004659" class="faux-block-link__overlay-link" tabindex="-1" aria-hidden="true">   Las espectaculares imágenes que dejó el eclipse solar total que cruzó a Estados Unidos de extremo a extremo</a>
        </div>
        <div class="parakeet-item faux-block-link" >
                <div class="parakeet-item__image">
                    <div class="responsive-image responsive-image--16by9">
                        
                            <div class="js-delayed-image-load" data-src="https://ichef.bbci.co.uk/news/200/cpsprodpb/6500/production/_97465852_tatoo.jpg" data-width="976" data-height="549" data-alt="Gareth Hickenbottom-Marriott, con el tatuaje, y su hija Briar."></div>
                            <!--[if lt IE 9]>
                            <img src="https://ichef.bbci.co.uk/news/200/cpsprodpb/6500/production/_97465852_tatoo.jpg" class="js-image-replace" alt="Gareth Hickenbottom-Marriott, con el tatuaje, y su hija Briar." width="976" height="549" />
                            <![endif]-->
                        
                    </div>
                </div>

            <div class="parakeet-item__body">
                <a href="/mundo/noticias-41001349" class="title-link">
                    
                    <h3 class="title-link__title">
                        
                        <span class="title-link__title-text">El hombre que se tatuó un catéter en la cabeza para apoyar a su hija que padece una rara enfermedad</span>
                    </h3>
                </a>                    <p class="parakeet-item__summary"> </p>
            </div>

            <a href="/mundo/noticias-41001349" class="faux-block-link__overlay-link" tabindex="-1" aria-hidden="true">   El hombre que se tatuó un catéter en la cabeza para apoyar a su hija que padece una rara enfermedad</a>
        </div>
        <div class="parakeet-item faux-block-link" >
                <div class="parakeet-item__image">
                    <div class="responsive-image responsive-image--16by9">
                        <div class="responsive-image__inner-for-label"><!-- closed in responsive-image-end -->
                            <div class="js-delayed-image-load" data-src="https://ichef-1.bbci.co.uk/news/200/cpsprodpb/745F/production/_97419792_1072037.jpg" data-width="976" data-height="549" data-alt="A shadow of a balloon"></div>
                            <!--[if lt IE 9]>
                            <img src="https://ichef-1.bbci.co.uk/news/200/cpsprodpb/745F/production/_97419792_1072037.jpg" class="js-image-replace" alt="A shadow of a balloon" width="976" height="549" />
                            <![endif]-->
                            <div class="responsive-image__label" aria-hidden="true">
                                        
                                        <span class="icon-new icon-new--camera"><span class="off-screen"> Fotos</span></span>
                                        
                                        
                            </div>
                        <!-- opened in responsive-image-start --></div>
                    </div>
                </div>

            <div class="parakeet-item__body">
                <a href="/mundo/noticias-40979415" class="title-link">
                    <span class="off-screen">Fotos</span>
                    <h3 class="title-link__title">
                        
                        <span class="title-link__title-text">Nosotros proponemos el tema, tú mandas las fotos</span>
                    </h3>
                </a>                    <p class="parakeet-item__summary"> </p>
            </div>

            <a href="/mundo/noticias-40979415" class="faux-block-link__overlay-link" tabindex="-1" aria-hidden="true">   Nosotros proponemos el tema, tú mandas las fotos</a>
        </div>
        <div class="parakeet-item faux-block-link" >
                <div class="parakeet-item__image">
                    <div class="responsive-image responsive-image--16by9">
                        
                            <div class="js-delayed-image-load" data-src="https://ichef-1.bbci.co.uk/news/200/cpsprodpb/1414E/production/_97445228_gettyimages-156331376.jpg" data-width="976" data-height="549" data-alt="eclipse"></div>
                            <!--[if lt IE 9]>
                            <img src="https://ichef-1.bbci.co.uk/news/200/cpsprodpb/1414E/production/_97445228_gettyimages-156331376.jpg" class="js-image-replace" alt="eclipse" width="976" height="549" />
                            <![endif]-->
                        
                    </div>
                </div>

            <div class="parakeet-item__body">
                <a href="/mundo/noticias-40984491" class="title-link">
                    
                    <h3 class="title-link__title">
                        
                        <span class="title-link__title-text">Las primeras y raras fotografías de un eclipse total de sol de 1854 conservadas como un tesoro en EE.UU.</span>
                    </h3>
                </a>                    <p class="parakeet-item__summary"> </p>
            </div>

            <a href="/mundo/noticias-40984491" class="faux-block-link__overlay-link" tabindex="-1" aria-hidden="true">   Las primeras y raras fotografías de un eclipse total de sol de 1854 conservadas como un tesoro en EE.UU.</a>
        </div>
    </div>
</div>

        
    </div>

                                                                        </div>
                </div> </div>      </div> 
   

<div id="core-navigation" class="navigation--footer">
    <h2 class="navigation--footer__heading">Mundo navigation</h2>

    
    <nav id="navigation--bottom" class="navigation navigation--bottom " role="navigation" aria-label="Mundo">
                    <span class="navigation-core-title">Secciones</span>
                <ul class="navigation--bottom__toplevel">
                        <li class="">
                    <a href="/mundo" class="">
                        <span>Noticias</span>
                    </a>
                                                        </li>
                            <li class="">
                    <a href="/mundo/america_latina" class="">
                        <span>América Latina</span>
                    </a>
                                                        </li>
                            <li class="">
                    <a href="/mundo/internacional" class="">
                        <span>Internacional</span>
                    </a>
                                                        </li>
                            <li class="">
                    <a href="/mundo/topics/ca170ae3-99c1-48db-9b67-2866f85e7342" class="">
                        <span>Economía</span>
                    </a>
                                                        </li>
                            <li class="">
                    <a href="/mundo/topics/31684f19-84d6-41f6-b033-7ae08098572a" class="">
                        <span>Tecnología</span>
                    </a>
                                                        </li>
                            <li class="">
                    <a href="/mundo/topics/0f469e6a-d4a6-46f2-b727-2bd039cb6b53" class="">
                        <span>Ciencia</span>
                    </a>
                                                        </li>
                            <li class="">
                    <a href="/mundo/topics/c4794229-7f87-43ce-ac0a-6cfcd6d3cef2" class="">
                        <span>Salud</span>
                    </a>
                                                        </li>
                            <li class="">
                    <a href="/mundo/topics/6a73afa3-ea6b-45c1-80bb-49060b99f864" class="">
                        <span>Cultura</span>
                    </a>
                                                        </li>
                            <li class="">
                    <a href="/mundo/topics/4063f80f-cccc-44c8-9449-5ca44e4c8592" class="">
                        <span>Deportes</span>
                    </a>
                                                        </li>
                            <li class="">
                    <a href="/mundo/media/video" class="">
                        <span>Video</span>
                    </a>
                                                        </li>
                            <li class="">
                    <a href="/mundo/media/photogalleries" class="">
                        <span>Fotos</span>
                    </a>
                                                        </li>
                            <li class="">
                    <a href="/mundo/noticias-36795069" class="">
                        <span>Hay Festival</span>
                    </a>
                                                        </li>
                    </ul>
    </nav>
</div>
     </div><!-- closes #site-container -->      </div> <div id="orb-footer"  class="orb-footer orb-footer-grey b-footer--grey--white" >  <aside role="complementary"> <div id="orb-aside" class="orb-nav-sec b-r b-g-p"> <div class="orb-footer-inner" role="navigation"> <h2 class="orb-footer-lead">Navegación en la BBC</h2> <div class="orb-footer-primary-links"> <ul>    <li  class="orb-nav-news orb-d"  > <a href="/news/">News</a> </li>    <li  class="orb-nav-newsdotcom orb-w"  > <a href="http://www.bbc.com/news/">News</a> </li>    <li  class="orb-nav-sport"  > <a href="/sport/">Sport</a> </li>    <li  class="orb-nav-weather"  > <a href="/weather/">Weather</a> </li>    <li  class="orb-nav-radio"  > <a href="/worldserviceradio/">Radio</a> </li>    <li  class="orb-nav-arts orb-d"  > <a href="/arts/">Arts</a> </li>    </ul> </div> </div> </div> </aside> <footer role="contentinfo"> <div id="orb-contentinfo" class="orb-nav-sec b-r b-g-p"> <div class="orb-footer-inner"> <ul>        <li  > <a href="/mundo/institucional-36400005">Condiciones de uso</a> </li>    <li  > <a href="/mundo/institucional-36400007">Acerca de la BBC</a> </li>    <li  > <a href="/mundo/institucional-36400009">Cláusula de Privacidad</a> </li>    <li  > <a href="http://www.bbc.co.uk/privacy/cookies/managing/cookie-settings.html">Cookies</a> </li>    <li  > <a href="/accessibility/">Accessibility Help</a> </li>    <li  > <a href="/guidance/">Parental Guidance</a> </li>    <li  > <a href="/mundo/institucional-36400011">Escriba a BBC Mundo</a> </li>    <li  class=" orb-w"  > <a href="/mundo/institucional-36400821">Anuncie con nosotros</a> </li>    <li  class=" orb-w"  > <a href="/mundo/institucional-36400821">Opciones para los anuncios</a> </li>    </ul> <small> <span class="orb-hilight">Copyright &copy; 2017 BBC.</span> El contenido de las páginas externas no es responsabilidad de la BBC. <a href="/mundo/institucional/2011/03/000000_vinculos_gel.shtml" class="orb-hilight">Lea más de nuestra política al respecto.</a> </small> </div> </div> </footer> </div>     <!-- BBCDOTCOM bodyLast --><div class="bbccom_display_none"><script type="text/javascript"> /*<![CDATA[*/ /** * ASYNC waits to make any gpt requests until the bottom of the page */ if ( window.bbcdotcom && bbcdotcom.data && bbcdotcom.data.ads && bbcdotcom.data.ads == 1 && bbcdotcom.config && bbcdotcom.config.isAsync && bbcdotcom.config.isAsync() ) { (function () { var gads = document.createElement('script'); gads.async = true; gads.type = 'text/javascript'; var useSSL = 'https:' == document.location.protocol; gads.src = (useSSL ? 'https:' : 'http:') + '//www.googletagservices.com/tag/js/gpt.js'; var node = document.getElementsByTagName('script')[0]; node.parentNode.insertBefore(gads, node); })(); } /*]]>*/ </script><script type="text/javascript"> /*<![CDATA[*/ if (window.bbcdotcom && bbcdotcom.data && bbcdotcom.data.stats && bbcdotcom.data.stats === 1 && bbcdotcom.utils && window.location.pathname === '/' && window.bbccookies && bbccookies.readPolicy('performance') ) { var wwhpEdition = bbcdotcom.utils.getMetaPropertyContent('wwhp-edition'); var _sf_async_config={}; /** CONFIGURATION START **/ _sf_async_config.uid = 50924; _sf_async_config.domain = "bbc.co.uk"; _sf_async_config.title = "Homepage"+(wwhpEdition !== '' ? ' - '+wwhpEdition : ''); _sf_async_config.sections = "Homepage"+(wwhpEdition !== '' ? ', Homepage - '+wwhpEdition : ''); _sf_async_config.region = wwhpEdition; _sf_async_config.path = "/"+(wwhpEdition !== '' ? '?'+wwhpEdition : ''); /** CONFIGURATION END **/ (function(){ function loadChartbeat() { window._sf_endpt=(new Date()).getTime(); var e = document.createElement("script"); e.setAttribute("language", "javascript"); e.setAttribute("type", "text/javascript"); e.setAttribute('src', '//static.chartbeat.com/js/chartbeat.js'); document.body.appendChild(e); } var oldonload = window.onload; window.onload = (typeof window.onload != "function") ? loadChartbeat : function() { oldonload(); loadChartbeat(); }; })(); } /*]]>*/ </script><script type="text/javascript"> /*<![CDATA[*/ (function() { window.bbcdotcom.bodyLast = true; }()); /*]]>*/ </script></div><!-- BBCDOTCOM all code in page -->  <script type="text/javascript" id="orb-js-script" data-assetpath="http://static.bbci.co.uk/frameworks/barlesque/3.21.26/orb/4/" src="http://static.bbci.co.uk/frameworks/barlesque/3.21.26/orb/4/script/orb.min.js"></script>   

 <script type="text/javascript"> if (typeof require !== 'undefined') { require(['istats-1'], function(istats){ istats.track('external', { region: document.getElementsByTagName('body')[0] }); istats.track('download', { region: document.getElementsByTagName('body')[0] }); }); } </script>   <script type="text/javascript">
  if (window.SEARCHBOX.suppress === false && window.SEARCHBOX.locale && /^en-?.*?/.test(window.SEARCHBOX.locale)) {
    require.config({
      paths: {
        "search/searchbox": window.SEARCHBOX.searchboxAppStaticPrefix,
        "disco-layer": "//nav.files.bbci.co.uk/discovery-layer/0.0.1-45.8235a67/app"
      }
    });

    require(['search/searchbox/searchboxDrawer'], function (SearchboxDrawer) {
      SearchboxDrawer.run(window.SEARCHBOX);
    });


  }

</script>             <script type="text/javascript">require(["megavolt-client","istats-1","orb/cookies"],function(t,e,i){function o(){return"true"===l&&a&&t&&"function"==typeof t.getMVTIStatsLabels}function n(){!c&&o()?setTimeout(function(){e.invoke()},"1000"):e.invoke()}var s=navigator.userAgent.toLowerCase(),a=!(s.indexOf("msie")>-1)||parseInt(s.split("msie")[1],10)>10,c=!1,l="true";if(i.isAllowed("s1"))try{if(o()&&t.getMVTIStatsLabels(function(t){e.addLabels(t),c=!0}),!require.s.contexts._.config.paths.idcta)return void n();require(["idcta/idcta-1"],function(t){t&&"function"==typeof t.getIStatsLabels&&e.addLabels(t.getIStatsLabels()),n()},function(t){throw t})}catch(t){console&&"function"==typeof console.log&&console.log("an exception occurred while adding idcta labels to istats, invoking istats without them",t),n()}});</script>  </div><!-- closes .direction -->  <script> window.old_onload = window.onload; window.onload = function() { if(window.old_onload) { window.old_onload(); } window.loaded = true; }; </script> <!-- Chartbeat Web Analytics code - start -->
<script type="text/javascript">
    /** CONFIGURATION START **/
    var _sf_async_config = {};
    
    _sf_async_config.uid = "50924";
    _sf_async_config.domain = "mundo.bbc.co.uk";
    _sf_async_config.sections = "Mundo, Mundo - noticias, Mundo - IDX, Mundo - noticias - IDX";
    <!-- if page is an index, add the edition to the path -->
    _sf_async_config.path = "bbc.co.uk/mundo";
    
        _sf_async_config.title = "BBC Mundo - Noticias - domestic";
        (function() {
        var noCookies = true;
        var cookiePrefix = '_chartbeat';
        if ("object" === typeof bbccookies && typeof bbccookies.readPolicy == 'function') {
            noCookies = !bbccookies.readPolicy().performance;
        }
        if (noCookies && document.cookie.indexOf(cookiePrefix) !== -1) {
            //Find and remove cookies whose names begin with '_chartbeat'
            var cookieSplit = document.cookie.split(';');
            var cookieLength = cookieSplit.length;
            while (cookieLength--) {
                var cookie = cookieSplit[cookieLength].replace(/^\s+|\s+$/g, '');
                var cookieName = cookie.split('=')[0];

                if (cookieName.indexOf(cookiePrefix) === 0) {
                    document.cookie = cookieName + '=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/;';
                }
            }
        }
        _sf_async_config.noCookies = noCookies;
    }());

    /** CONFIGURATION END **/
    (function(){
        function loadChartbeat() {
            window._sf_endpt=(new Date()).getTime();
            var e = document.createElement("script");
            e.setAttribute("language", "javascript");
            e.setAttribute("type", "text/javascript");
            e.setAttribute('src', '//static.chartbeat.com/js/chartbeat.js');
            document.body.appendChild(e);
        }
        var oldonload = window.onload;
        window.onload = (typeof window.onload != "function") ?
            loadChartbeat : function() { oldonload(); loadChartbeat(); };
    }());
</script>
<!-- Chartbeat Web Analytics code - end -->
   <!--Non-JS-->
<noscript>
    <img src="http://ssc.api.bbc.com/?c2=19999701&amp;ns_type=view&amp;ns_site=bbc&amp;c1=2&amp;b_vs_un=ws&amp;b_imp_src=ws&amp;b_imp_ver=1.0.0.0&amp;name=mundo&amp;b_vs_ls=mundo&amp;b_synd_partner=bbc%7Crd%7Cgroup0&amp;b_site_section=102454&amp;b_page_type=IDX%7Cna&amp;c8=Noticias+-+BBC+Mundo&amp;b_app_type=web&amp;b_app_name=news%7Cweb&amp;b_article_id=36258063&amp;b_article_date=1462878020&amp;b_article_update=1503633507&amp;b_ad_enabled=1&amp;c7=http%3A%2F%2Fwww.bbc.com%2Fmundo&amp;b_c7=%2Fmundo&amp;ns_c=utf-8&amp;bbc_site=news-ws-mundo&amp;b_code_ver=bbc_nonjs&amp;b_breaking_flag=0&amp;b_syndication_flag=0" alt="" class="comscore-tracking-nonjs" style="display: none;" />
</noscript>

<!--JS-->
<script>
    if ('object' === typeof bbccookies && bbccookies.cookiesEnabled() && bbccookies.readPolicy('performance')) {
        if (!window.cutsTheMustard) {
            var url = "http://ssc.api.bbc.com/?c2=19999701&ns_type=view&ns_site=bbc&c1=2&b_vs_un=ws&b_imp_src=ws&b_imp_ver=1.0.0.0&name=mundo&b_vs_ls=mundo&b_synd_partner=bbc%7Crd%7Cgroup0&b_site_section=102454&b_page_type=IDX%7Cna&c8=Noticias+-+BBC+Mundo&b_app_type=web&b_app_name=news%7Cweb&b_article_id=36258063&b_article_date=1462878020&b_article_update=1503633507&b_ad_enabled=1&c7=http%3A%2F%2Fwww.bbc.com%2Fmundo&b_c7=%2Fmundo&ns_c=utf-8&bbc_site=news-ws-mundo&b_code_ver=bbc_nonjs&b_breaking_flag=0&b_syndication_flag=0"
            img = document.createElement('img');
            img.src = url.replace("bbc_nonjs", "bbc_nonctm");
            img.className = 'comscore-tracking-nonjs';
            img.setAttribute('style', 'display: none;');
            document.body.appendChild(img);
        }
            payload = document.createElement('div');
            payload.id = "comscore-payload";
            payload.setAttribute('style', 'display: none;');
            payload.setAttribute('data-payload', '{"c2":19999701,"ns_type":"view","ns_site":"bbc","c1":"2","b_vs_un":"ws","b_imp_src":"ws","b_imp_ver":"1.0.0.0","name":"mundo","b_vs_ls":"mundo","b_synd_partner":"bbc|rd|group0","b_site_section":"102454","b_page_type":"IDX|na","c8":"Noticias - BBC Mundo","b_app_type":"web","b_app_name":"news|web","b_article_id":"36258063","b_article_date":1462878020,"b_article_update":1503633507,"b_ad_enabled":true,"c7":"http:\/\/www.bbc.com\/mundo","b_c7":"\/mundo","ns_c":"utf-8","bbc_site":"news-ws-mundo","b_code_ver":"bbc_nonjs","b_breaking_flag":0,"b_syndication_flag":0}');
            document.body.appendChild(payload);
    }
</script>   </body> </html> 











