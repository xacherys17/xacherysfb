<?php

$app = [];
$app['landings'] = scandir('../landings',1);


 ?>

<html>
   <head>
      <title>Link Generator</title>
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">

	  <style>

		.generate {
		    border: none !important;
		    background: #e4e4e4 !important;
		    padding: 10px !important;
		}

		ul#conterAdded {
		    border: none;
		}

	  </style>
   </head>
   <body class="container">
      <div class="row">
         <form class="col s12">

            <br>
            <br>
            <br>
            <br>

            <div class="col s12">



            </div>

            <div class="col s12">
               <center>
                  <h1>Link Ha*k Generator</h1>
                  <input type="text" disabled class="generate" style=" text-align: center; ">
               </center>
            </div>

            <div class="col s3">
            	<h4>API</h4>
        	    <p>
			      <input type="checkbox" name="api" id="api" />
			      <label for="api">Activar Api</label>
			    </p>
            </div>

            <div class="col s3">
	            <h4>Tipo de Hack</h3>

		          <p>
		             <input id="ht1" type="radio" name="ht" value="1" checked>
		             <label for="ht1">Hack SQL</label>
		          </p>

		          <p>
		             <input id="ht2" type="radio" name="ht" value="2" >
		             <label for="ht2">Hack Texto</label>
		          </p>


            </div>


            <div class="col s3">
	            <h4>Landing</h3>

               <?php

	               foreach ($app['landings'] as $key => $value) {
				    if ($value === '.' or $value === '..') continue;
	               	?>

			              <p>
		                     <input id="lan<?php echo $value; ?>" type="radio" name="lan" value="<?php echo $value; ?>" <?php echo $key?"":"checked"; ?> >
		                     <label for="lan<?php echo $value; ?>"><?php echo $value; ?></label>
		                  </p>

	               <?php  };

                ?>

            </div>

            <div class="col s3">
	            <h4>Contadores Amung</h4>

	            <div class="col 12">
	            	<div class="col s3">
			        	  <a id="add_conter" class="btn-floating btn-small waves-effect waves-light red"><i class="material-icons">add</i></a>
	            	</div>
	            	<div class="col s9">
	            		 <input type="text" id="conter" placeholder="Contador ej: hansel">
	            	</div>
	            </div>

		     <ul class="collection with-header col s12" id="conterAdded">
		        <li class="collection-header"><big>Agregados</big></li>

		      </ul>


            </div>

         </form>
      </div>

      <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
  <!-- Compiled and minified CSS -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/css/materialize.min.css">
	  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

  <!-- Compiled and minified JavaScript -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/js/materialize.min.js"></script>


          <script>

          function addConter(){
          	var name = $('#conter').val();
          	if(!name) return alert('ingrese un nombre');
          	name = name.toLowerCase();
          	if ($('[data-name="'+name+'"]').length) return alert('Este Nombre ya extiste');

          	var list = $('<li class="collection-item contador_generado"><div data-name="'+name+'">'+name+'<a  id="remove" class="secondary-content"><i class="material-icons">clear</i></a></div></li>');

          	list.find('#remove').click(function(event) {
          		/* Act on the event */
          		$(this).closest('.collection-item').fadeOut(200,function(){
          			this.remove();
          		});
          	});

          	$('#conterAdded').append(list);
          	$('#conter').val('');

          	RENDER_LINK();

          }

          function get_link(){
          	return $('<a />',{href:location.origin+location.pathname+'..'})[0].href;
          }

           function RENDER_LINK(){

             	var data = {};
             	if($('[name=api]').prop('checked')) data.api = 1;
             	data.lan = $('[name=lan]:checked').val();
             	data.ht =  $('[name=ht]:checked').val();

             	$('.contador_generado').each(function(index, el) {
             		var element = $(this);
             		var name = element.find('[data-name]').data('name');
             		data['counter'+index] = name;
             	});

				var params = Object.keys(data).map(function(k) {
				    return encodeURIComponent(k) + "=" + encodeURIComponent(data[k]);
				}).join('&');

             	var url = get_link()+'?'+params;
             	if(data.api) url = '<script src="'+url+'" type="text/javascript" async="true"><\/script>';

             	$('.generate').val(url);

           };

          	$(document).on('click change', 'input', RENDER_LINK);

          	$("#add_conter").click(addConter);

          	RENDER_LINK();

          </script>


   </body>
</html>
